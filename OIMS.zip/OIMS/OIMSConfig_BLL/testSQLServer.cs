﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OIMS_DAL;
using System.Data.SqlClient;
using System.Data;
using System.Diagnostics;

namespace OIMSConfig_BLL
{
    public class TestSQLServer
    {
        public TestSQLServer()
        {

        }

        public int GetNum(string serverIpName,string databaseName, string databaseUserName, string databaseUserPwd)
        {
            string strServerIpName = serverIpName;
            string strDatabaseName = databaseName;
            string strDatabaseUserName = databaseUserName;
            string strDatabaseUserPwd = databaseUserPwd;

            //数据库连接字符串
            string connectionString = OIMS_ConfigHelper.GetConnString(strServerIpName, strDatabaseName, strDatabaseUserName, strDatabaseUserPwd);

            //数据库连接
            SqlConnection conn = OIMS_ConfigHelper.GetConnection(connectionString);

            //如果出现服务器IP地址错误等。通过抛出异常来确定连接无法正常连接。
            try
            {
                conn.Open();
            }
            catch(Exception ex)
            {
                Debug.Print(ex.ToString());
                return 0;
            }
            if (conn.State == ConnectionState.Open)
            {  
                conn.Dispose();
                conn.Close();
                return 1;
            }
            else
            {
                return 0;
            }    
        }
    }
}
