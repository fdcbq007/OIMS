﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using OIMS_BLL;
using OIMS_DAL;

namespace OIMS
{
    public partial class Login : Form
    {
        public Login()
        { 
            InitializeComponent();
            
        }

        public string message = "";

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            //全局变量记录用户ID
            //LoginUserHelper.LoginUserId = txtUserId.Text.Trim();
            //LoginUserHelper.LoginComapny = cmbCompany.Text.Trim();
            string LoginUserPass = txtPwd.Text.Trim();
            
            //判断用户输入的用户ID和密码是
            if (LoginBLL.IsValidataInput(txtUserId.Text.Trim(), LoginUserPass) == true)
            {
                if (LoginBLL.IsValidataUserId(txtUserId.Text.Trim(), LoginUserPass, ref message))
                {
                    if (cmbCompany.SelectedIndex == 1)
                    {
                        LoginHeadOffice loginHO = new LoginHeadOffice();
                        this.Hide();
                        loginHO.ShowDialog();
                        this.Close();
                    }
                    else if (cmbCompany.SelectedIndex == 2)
                    {
                        LoginBranchOffice loginBO = new LoginBranchOffice();
                        this.Hide();
                        loginBO.ShowDialog();
                        this.Close();
                    }

                }
                else
                {
                    MessageBox.Show(message, "登陆提示", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
            }    
        }

        private void BtnQuit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("您确定要退出吗？", "操作提示", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (result == DialogResult.OK)
            {
                Application.Exit();
            }
        }

        private void Login_Shown(object sender, EventArgs e)
        {
            //光标焦点默认在输入账号上
            cmbCompany.Focus();
            
        }

        private void TxtUserId_KeyPress(object sender, KeyPressEventArgs e)
        {


            string x ="";
            if (e.KeyChar == '\r')
            {
                
                x = LoginBLL.ReturnUserName(txtUserId.Text.Trim(), ref message);
                LoginUserHelper.LoginUserId = txtUserId.Text.Trim();
                txtUserName.ReadOnly = true;
                //txtUserName.Text = LoginBLL.ReturnUserName(LoginUserHelper.LoginUserId, ref message);

                //判断用户ID是否输入，如果未输入，则提示并光标仍聚焦在用户ID输入框


                if (string.IsNullOrWhiteSpace(txtUserId.Text.Trim()))
                {
                    MessageBox.Show("未输入用户ID，请重新输入");
                    txtUserId.Focus();
                    return;
                }
                if (message == x)
                {
                    MessageBox.Show(message, "用户名获取提示", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    txtUserId.Focus();            
                }
                else
                {
                    txtUserName.ReadOnly = true;
                    txtUserName.Text = LoginBLL.ReturnUserName(txtUserId.Text.Trim(), ref message);
                    LoginUserHelper.LoginUserId = txtUserId.Text.Trim();
                    LoginUserHelper.LoginComapny = cmbCompany.Text.Trim();
                    LoginUserHelper.LoginUserName = txtUserName.Text.Trim();

                    txtPwd.Focus();
                }

            }
        }

        private void TxtPwd_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Return)
            {
                BtnLogin_Click(null,null);
            }
        }

        private void CmbCompany_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtUserId.Focus();
            }
        }
    }
}
