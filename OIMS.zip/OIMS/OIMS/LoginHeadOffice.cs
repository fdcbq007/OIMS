﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OIMS_HOSM;
using OIMS_DAL;

namespace OIMS
{
    public partial class LoginHeadOffice : Form
    {
        public LoginHeadOffice()
        {
            InitializeComponent();
            tsslLoginUserName.Text = "用户名：" + LoginUserHelper.LoginUserName;
            tsslLoginUserId.Text = "用户ID：" + LoginUserHelper.LoginUserId;
        }

        private void BtnSsystemManage_Click(object sender, EventArgs e)
        {
            XTGL sm = new XTGL();
            sm.ShowDialog();
        }
    }
}
