﻿namespace OIMS
{
    partial class LoginBranchOffice
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button6 = new System.Windows.Forms.Button();
            this.btnSsystemManage = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnFrameOfMirror = new System.Windows.Forms.Button();
            this.ssrUserInformation = new System.Windows.Forms.StatusStrip();
            this.tsslCompany = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsslLoginUserId = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsslLoginUserName = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel1.SuspendLayout();
            this.ssrUserInformation.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.btnSsystemManage);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.btnFrameOfMirror);
            this.panel1.Location = new System.Drawing.Point(185, 175);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(611, 377);
            this.panel1.TabIndex = 0;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.button6.Location = new System.Drawing.Point(29, 147);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 67);
            this.button6.TabIndex = 9;
            this.button6.Text = "button6";
            this.button6.UseVisualStyleBackColor = false;
            // 
            // btnSsystemManage
            // 
            this.btnSsystemManage.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnSsystemManage.Location = new System.Drawing.Point(144, 147);
            this.btnSsystemManage.Name = "btnSsystemManage";
            this.btnSsystemManage.Size = new System.Drawing.Size(75, 67);
            this.btnSsystemManage.TabIndex = 8;
            this.btnSsystemManage.Text = "系统管理";
            this.btnSsystemManage.UseVisualStyleBackColor = false;
            this.btnSsystemManage.Click += new System.EventHandler(this.BtnSsystemManage_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.button5.Location = new System.Drawing.Point(496, 22);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 67);
            this.button5.TabIndex = 4;
            this.button5.Text = "button5";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.button4.Location = new System.Drawing.Point(380, 22);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 67);
            this.button4.TabIndex = 3;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.button3.Location = new System.Drawing.Point(260, 22);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 67);
            this.button3.TabIndex = 2;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.button2.Location = new System.Drawing.Point(144, 22);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 67);
            this.button2.TabIndex = 1;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // btnFrameOfMirror
            // 
            this.btnFrameOfMirror.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnFrameOfMirror.BackgroundImage = global::OIMS.Properties.Resources.iopenworks;
            this.btnFrameOfMirror.Location = new System.Drawing.Point(29, 22);
            this.btnFrameOfMirror.Name = "btnFrameOfMirror";
            this.btnFrameOfMirror.Size = new System.Drawing.Size(75, 67);
            this.btnFrameOfMirror.TabIndex = 0;
            this.btnFrameOfMirror.Text = "框架镜前台";
            this.btnFrameOfMirror.UseVisualStyleBackColor = false;
            this.btnFrameOfMirror.Click += new System.EventHandler(this.BtnFrameOfMirror_Click);
            // 
            // ssrUserInformation
            // 
            this.ssrUserInformation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ssrUserInformation.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsslCompany,
            this.tsslLoginUserId,
            this.tsslLoginUserName});
            this.ssrUserInformation.Location = new System.Drawing.Point(0, 555);
            this.ssrUserInformation.Name = "ssrUserInformation";
            this.ssrUserInformation.Size = new System.Drawing.Size(796, 26);
            this.ssrUserInformation.TabIndex = 1;
            this.ssrUserInformation.Text = "用户信息显示";
            // 
            // tsslCompany
            // 
            this.tsslCompany.BackColor = System.Drawing.Color.Red;
            this.tsslCompany.BorderSides = ((System.Windows.Forms.ToolStripStatusLabelBorderSides)((((System.Windows.Forms.ToolStripStatusLabelBorderSides.Left | System.Windows.Forms.ToolStripStatusLabelBorderSides.Top) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Right) 
            | System.Windows.Forms.ToolStripStatusLabelBorderSides.Bottom)));
            this.tsslCompany.BorderStyle = System.Windows.Forms.Border3DStyle.Sunken;
            this.tsslCompany.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsslCompany.ForeColor = System.Drawing.Color.White;
            this.tsslCompany.MergeIndex = 0;
            this.tsslCompany.Name = "tsslCompany";
            this.tsslCompany.Size = new System.Drawing.Size(86, 21);
            this.tsslCompany.Text = "tsslCompany";
            // 
            // tsslLoginUserId
            // 
            this.tsslLoginUserId.MergeIndex = 2;
            this.tsslLoginUserId.Name = "tsslLoginUserId";
            this.tsslLoginUserId.Size = new System.Drawing.Size(98, 21);
            this.tsslLoginUserId.Text = "tsslLoginUserId";
            // 
            // tsslLoginUserName
            // 
            this.tsslLoginUserName.MergeIndex = 1;
            this.tsslLoginUserName.Name = "tsslLoginUserName";
            this.tsslLoginUserName.Size = new System.Drawing.Size(121, 21);
            this.tsslLoginUserName.Text = "tsslLoginUserName";
            // 
            // LoginBranchOffice
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(796, 581);
            this.Controls.Add(this.ssrUserInformation);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.HelpButton = true;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "LoginBranchOffice";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "分店";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.LoginBranchOffice_FormClosed);
            this.panel1.ResumeLayout(false);
            this.ssrUserInformation.ResumeLayout(false);
            this.ssrUserInformation.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button btnSsystemManage;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnFrameOfMirror;
        private System.Windows.Forms.StatusStrip ssrUserInformation;
        private System.Windows.Forms.ToolStripStatusLabel tsslLoginUserName;
        private System.Windows.Forms.ToolStripStatusLabel tsslLoginUserId;
        private System.Windows.Forms.ToolStripStatusLabel tsslCompany;
    }
}