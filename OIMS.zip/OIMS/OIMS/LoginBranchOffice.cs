﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OIMS_HOSM;
using OIMS_DAL;
using OIMS_FOM;

namespace OIMS
{
    public partial class LoginBranchOffice : Form
    {
        public LoginBranchOffice()
        {
            InitializeComponent();
            tsslLoginUserName.Text = "用户名：" + LoginUserHelper.LoginUserName;
            tsslLoginUserId.Text = "用户ID：" + LoginUserHelper.LoginUserId;
            tsslCompany.Text = "公司：" + LoginUserHelper.LoginComapny;
        }

        private void BtnFrameOfMirror_Click(object sender, EventArgs e)
        {
            FrameOfMirror fom = new FrameOfMirror();
            fom.ShowDialog();
        }

        private void BtnSsystemManage_Click(object sender, EventArgs e)
        {

        }

        //点x的时候将所有的程序都一并退出结束。FormClosed事件
        private void LoginBranchOffice_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}
