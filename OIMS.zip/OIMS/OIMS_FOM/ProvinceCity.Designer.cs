﻿namespace OIMS_FOM
{
    partial class ProvinceCity
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpProvinceCity = new System.Windows.Forms.GroupBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtProvince = new System.Windows.Forms.TextBox();
            this.lblCity = new System.Windows.Forms.Label();
            this.llbProvince = new System.Windows.Forms.Label();
            this.bntConfirm = new System.Windows.Forms.Button();
            this.btnQuit = new System.Windows.Forms.Button();
            this.grpProvinceCity.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpProvinceCity
            // 
            this.grpProvinceCity.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.grpProvinceCity.Controls.Add(this.txtCity);
            this.grpProvinceCity.Controls.Add(this.txtProvince);
            this.grpProvinceCity.Controls.Add(this.lblCity);
            this.grpProvinceCity.Controls.Add(this.llbProvince);
            this.grpProvinceCity.Location = new System.Drawing.Point(12, 12);
            this.grpProvinceCity.Name = "grpProvinceCity";
            this.grpProvinceCity.Size = new System.Drawing.Size(259, 88);
            this.grpProvinceCity.TabIndex = 0;
            this.grpProvinceCity.TabStop = false;
            this.grpProvinceCity.Text = "默认省份城市设置";
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(66, 53);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(133, 21);
            this.txtCity.TabIndex = 3;
            // 
            // txtProvince
            // 
            this.txtProvince.Location = new System.Drawing.Point(66, 24);
            this.txtProvince.Name = "txtProvince";
            this.txtProvince.Size = new System.Drawing.Size(133, 21);
            this.txtProvince.TabIndex = 2;
            this.txtProvince.TextChanged += new System.EventHandler(this.txtProvince_TextChanged);
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Location = new System.Drawing.Point(19, 57);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(41, 12);
            this.lblCity.TabIndex = 1;
            this.lblCity.Text = "城市：";
            // 
            // llbProvince
            // 
            this.llbProvince.AutoSize = true;
            this.llbProvince.Location = new System.Drawing.Point(19, 28);
            this.llbProvince.Name = "llbProvince";
            this.llbProvince.Size = new System.Drawing.Size(41, 12);
            this.llbProvince.TabIndex = 0;
            this.llbProvince.Text = "省份：";
            // 
            // bntConfirm
            // 
            this.bntConfirm.Location = new System.Drawing.Point(100, 115);
            this.bntConfirm.Name = "bntConfirm";
            this.bntConfirm.Size = new System.Drawing.Size(63, 23);
            this.bntConfirm.TabIndex = 1;
            this.bntConfirm.Text = "确定";
            this.bntConfirm.UseVisualStyleBackColor = true;
            this.bntConfirm.Click += new System.EventHandler(this.bntConfirm_Click);
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(182, 115);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(63, 23);
            this.btnQuit.TabIndex = 2;
            this.btnQuit.Text = "退出";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // ProvinceCity
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(283, 151);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.bntConfirm);
            this.Controls.Add(this.grpProvinceCity);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ProvinceCity";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "默认省份城市设置";
            this.grpProvinceCity.ResumeLayout(false);
            this.grpProvinceCity.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpProvinceCity;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.TextBox txtProvince;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.Label llbProvince;
        private System.Windows.Forms.Button bntConfirm;
        private System.Windows.Forms.Button btnQuit;
    }
}