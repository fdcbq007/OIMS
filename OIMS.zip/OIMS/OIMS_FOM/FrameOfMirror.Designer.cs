﻿namespace OIMS_FOM
{
    partial class FrameOfMirror
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrameOfMirror));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiEnableQueueController = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiProvinceCity = new System.Windows.Forms.ToolStripMenuItem();
            this.岗位设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.人事管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.验光师设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.客户机管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiWYZYHZ = new System.Windows.Forms.ToolStripMenuItem();
            this.系统维护ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.吉图数据ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.集团数据下载ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbQueueController = new System.Windows.Forms.ToolStripButton();
            this.tsbCustomerInformation = new System.Windows.Forms.ToolStripButton();
            this.menuStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.系统维护ToolStripMenuItem,
            this.吉图数据ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1111, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiEnableQueueController,
            this.tsmiProvinceCity,
            this.岗位设置ToolStripMenuItem,
            this.人事管理ToolStripMenuItem,
            this.验光师设置ToolStripMenuItem,
            this.客户机管理ToolStripMenuItem,
            this.tsmiWYZYHZ});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(68, 21);
            this.toolStripMenuItem1.Text = "基本管理";
            // 
            // tsmiEnableQueueController
            // 
            this.tsmiEnableQueueController.Name = "tsmiEnableQueueController";
            this.tsmiEnableQueueController.Size = new System.Drawing.Size(177, 22);
            this.tsmiEnableQueueController.Text = "启用排队控制器";
            this.tsmiEnableQueueController.Click += new System.EventHandler(this.TsmiUserManage_Click);
            // 
            // tsmiProvinceCity
            // 
            this.tsmiProvinceCity.Name = "tsmiProvinceCity";
            this.tsmiProvinceCity.Size = new System.Drawing.Size(177, 22);
            this.tsmiProvinceCity.Text = "默认省份/城市设置";
            this.tsmiProvinceCity.Click += new System.EventHandler(this.TsmiProvinceCity_Click);
            // 
            // 岗位设置ToolStripMenuItem
            // 
            this.岗位设置ToolStripMenuItem.Name = "岗位设置ToolStripMenuItem";
            this.岗位设置ToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.岗位设置ToolStripMenuItem.Text = "岗位设置";
            // 
            // 人事管理ToolStripMenuItem
            // 
            this.人事管理ToolStripMenuItem.Name = "人事管理ToolStripMenuItem";
            this.人事管理ToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.人事管理ToolStripMenuItem.Text = "用户资料管理";
            // 
            // 验光师设置ToolStripMenuItem
            // 
            this.验光师设置ToolStripMenuItem.Name = "验光师设置ToolStripMenuItem";
            this.验光师设置ToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.验光师设置ToolStripMenuItem.Text = "验光室设置";
            // 
            // 客户机管理ToolStripMenuItem
            // 
            this.客户机管理ToolStripMenuItem.Name = "客户机管理ToolStripMenuItem";
            this.客户机管理ToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.客户机管理ToolStripMenuItem.Text = "客户机管理";
            // 
            // tsmiWYZYHZ
            // 
            this.tsmiWYZYHZ.Name = "tsmiWYZYHZ";
            this.tsmiWYZYHZ.Size = new System.Drawing.Size(177, 22);
            this.tsmiWYZYHZ.Text = "温医住院汇总";
            this.tsmiWYZYHZ.Click += new System.EventHandler(this.TsmiWYZYHZ_Click);
            // 
            // 系统维护ToolStripMenuItem
            // 
            this.系统维护ToolStripMenuItem.Name = "系统维护ToolStripMenuItem";
            this.系统维护ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.系统维护ToolStripMenuItem.Text = "系统维护";
            // 
            // 吉图数据ToolStripMenuItem
            // 
            this.吉图数据ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.集团数据下载ToolStripMenuItem});
            this.吉图数据ToolStripMenuItem.Name = "吉图数据ToolStripMenuItem";
            this.吉图数据ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.吉图数据ToolStripMenuItem.Text = "数据下载";
            // 
            // 集团数据下载ToolStripMenuItem
            // 
            this.集团数据下载ToolStripMenuItem.Name = "集团数据下载ToolStripMenuItem";
            this.集团数据下载ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.集团数据下载ToolStripMenuItem.Text = "集团数据下载";
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbQueueController,
            this.tsbCustomerInformation});
            this.toolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.Flow;
            this.toolStrip1.Location = new System.Drawing.Point(0, 25);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1111, 77);
            this.toolStrip1.TabIndex = 2;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbQueueController
            // 
            this.tsbQueueController.AutoSize = false;
            this.tsbQueueController.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tsbQueueController.BackgroundImage")));
            this.tsbQueueController.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbQueueController.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.tsbQueueController.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbQueueController.Name = "tsbQueueController";
            this.tsbQueueController.Size = new System.Drawing.Size(131, 74);
            this.tsbQueueController.Text = "排队控制器";
            this.tsbQueueController.Click += new System.EventHandler(this.TsbQueueController_Click);
            // 
            // tsbCustomerInformation
            // 
            this.tsbCustomerInformation.AutoSize = false;
            this.tsbCustomerInformation.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tsbCustomerInformation.BackgroundImage")));
            this.tsbCustomerInformation.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbCustomerInformation.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCustomerInformation.Name = "tsbCustomerInformation";
            this.tsbCustomerInformation.Size = new System.Drawing.Size(131, 74);
            this.tsbCustomerInformation.Text = "客户信息";
            this.tsbCustomerInformation.Click += new System.EventHandler(this.TsbCustomerInformation_Click);
            // 
            // FrameOfMirror
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1111, 668);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.Cursor = System.Windows.Forms.Cursors.SizeAll;
            this.HelpButton = true;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FrameOfMirror";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "框架镜前台";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 系统维护ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 吉图数据ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsmiEnableQueueController;
        private System.Windows.Forms.ToolStripMenuItem tsmiProvinceCity;
        private System.Windows.Forms.ToolStripMenuItem 岗位设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 人事管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 验光师设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 客户机管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 集团数据下载ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsmiWYZYHZ;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbQueueController;
        private System.Windows.Forms.ToolStripButton tsbCustomerInformation;
    }
}