﻿namespace OIMS_FOM
{
    partial class CustomerInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpCustomerInfQuery = new System.Windows.Forms.GroupBox();
            this.txtVisitingCardNumber = new System.Windows.Forms.TextBox();
            this.txtTelphone = new System.Windows.Forms.TextBox();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.lblVisitingCardNumber = new System.Windows.Forms.Label();
            this.lblTelphone = new System.Windows.Forms.Label();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.btnQuit = new System.Windows.Forms.Button();
            this.btnQuery = new System.Windows.Forms.Button();
            this.grpCustomerInfQuery.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpCustomerInfQuery
            // 
            this.grpCustomerInfQuery.Controls.Add(this.txtVisitingCardNumber);
            this.grpCustomerInfQuery.Controls.Add(this.txtTelphone);
            this.grpCustomerInfQuery.Controls.Add(this.txtCustomerName);
            this.grpCustomerInfQuery.Controls.Add(this.lblVisitingCardNumber);
            this.grpCustomerInfQuery.Controls.Add(this.lblTelphone);
            this.grpCustomerInfQuery.Controls.Add(this.lblCustomerName);
            this.grpCustomerInfQuery.Location = new System.Drawing.Point(12, 12);
            this.grpCustomerInfQuery.Name = "grpCustomerInfQuery";
            this.grpCustomerInfQuery.Size = new System.Drawing.Size(323, 150);
            this.grpCustomerInfQuery.TabIndex = 0;
            this.grpCustomerInfQuery.TabStop = false;
            this.grpCustomerInfQuery.Text = "客户资料查询";
            // 
            // txtVisitingCardNumber
            // 
            this.txtVisitingCardNumber.BackColor = System.Drawing.SystemColors.Control;
            this.txtVisitingCardNumber.Location = new System.Drawing.Point(97, 95);
            this.txtVisitingCardNumber.Name = "txtVisitingCardNumber";
            this.txtVisitingCardNumber.Size = new System.Drawing.Size(199, 21);
            this.txtVisitingCardNumber.TabIndex = 5;
            // 
            // txtTelphone
            // 
            this.txtTelphone.BackColor = System.Drawing.SystemColors.Control;
            this.txtTelphone.Location = new System.Drawing.Point(97, 58);
            this.txtTelphone.Name = "txtTelphone";
            this.txtTelphone.Size = new System.Drawing.Size(199, 21);
            this.txtTelphone.TabIndex = 4;
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.BackColor = System.Drawing.SystemColors.Control;
            this.txtCustomerName.Location = new System.Drawing.Point(97, 22);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(199, 21);
            this.txtCustomerName.TabIndex = 3;
            // 
            // lblVisitingCardNumber
            // 
            this.lblVisitingCardNumber.AutoSize = true;
            this.lblVisitingCardNumber.Location = new System.Drawing.Point(26, 99);
            this.lblVisitingCardNumber.Name = "lblVisitingCardNumber";
            this.lblVisitingCardNumber.Size = new System.Drawing.Size(65, 12);
            this.lblVisitingCardNumber.TabIndex = 2;
            this.lblVisitingCardNumber.Text = "就诊卡号：";
            // 
            // lblTelphone
            // 
            this.lblTelphone.AutoSize = true;
            this.lblTelphone.Location = new System.Drawing.Point(50, 62);
            this.lblTelphone.Name = "lblTelphone";
            this.lblTelphone.Size = new System.Drawing.Size(41, 12);
            this.lblTelphone.TabIndex = 1;
            this.lblTelphone.Text = "电话：";
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Location = new System.Drawing.Point(50, 26);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(41, 12);
            this.lblCustomerName.TabIndex = 0;
            this.lblCustomerName.Text = "姓名：";
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(222, 178);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(65, 23);
            this.btnQuit.TabIndex = 13;
            this.btnQuit.Text = "退出";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.BtnQuit_Click);
            // 
            // btnQuery
            // 
            this.btnQuery.Location = new System.Drawing.Point(130, 178);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(65, 23);
            this.btnQuery.TabIndex = 12;
            this.btnQuery.Text = "查询";
            this.btnQuery.UseVisualStyleBackColor = true;
            this.btnQuery.Click += new System.EventHandler(this.BtnQuery_Click);
            // 
            // CustomerInformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(357, 207);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.btnQuery);
            this.Controls.Add(this.grpCustomerInfQuery);
            this.Name = "CustomerInformation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "客户资料查询";
            this.grpCustomerInfQuery.ResumeLayout(false);
            this.grpCustomerInfQuery.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpCustomerInfQuery;
        private System.Windows.Forms.TextBox txtVisitingCardNumber;
        private System.Windows.Forms.TextBox txtTelphone;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.Label lblVisitingCardNumber;
        private System.Windows.Forms.Label lblTelphone;
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.Button btnQuit;
        private System.Windows.Forms.Button btnQuery;
    }
}