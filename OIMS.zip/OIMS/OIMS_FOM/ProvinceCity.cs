﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OIMS_FOM_BLL;

namespace OIMS_FOM
{
    public partial class ProvinceCity : Form
    {
        public ProvinceCity()
        {
            InitializeComponent();
            ProvinceCityBLL.FomProvince = txtProvince.Text.Trim();
            ProvinceCityBLL.FomCity = txtCity.Text.Trim();
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void bntConfirm_Click(object sender, EventArgs e)
        {
            ProvinceCityBLL.FomProvince = txtProvince.Text.Trim();
            ProvinceCityBLL.FomCity = txtCity.Text.Trim();
            txtProvince.Text = ProvinceCityBLL.FomProvince;
            txtCity.Text = ProvinceCityBLL.FomCity;
        }

        private void txtProvince_TextChanged(object sender, EventArgs e)
        {
            ProvinceCityBLL.FomProvince = txtProvince.Text.Trim();
            ProvinceCityBLL.FomCity = txtCity.Text.Trim();
            txtProvince.Text = ProvinceCityBLL.FomProvince;
            txtCity.Text = ProvinceCityBLL.FomCity;
        }
    }
}
