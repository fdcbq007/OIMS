﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OIMS_FOM
{
    public partial class QueueController : Form
    {
        public QueueController()
        {
            InitializeComponent();
        }

        private void TsbNewRefractionList_Click(object sender, EventArgs e)
        {
            NewRefractionList nel = new NewRefractionList();
            nel.Show();
        }
    }
}
