﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OIMS_FOM
{
    public partial class FrameOfMirror : Form
    {
        public FrameOfMirror()
        {
            InitializeComponent();
        }

        private T OpenUniqueMDIChildWindow<T>(Form mdiParent) where T : Form, new()
        {
            foreach (Form childrenForm in mdiParent.MdiChildren)
            {
                if (!childrenForm.GetType().Equals(typeof(T)))
                {
                    childrenForm.Close();
                }
                else
                {
                    childrenForm.Activate();
                    return childrenForm as T;
                }
            }
            //T newForm = new T();
            //newForm.MdiParent = mdiParent;
            ////newForm.FormBorderStyle = FormBorderStyle.None;
            ////newForm.WindowState = FormWindowState.Maximized;
            ////newForm.MaximizeBox = false;
            ////newForm.MinimizeBox = false;

            //newForm.StartPosition = FormStartPosition.CenterScreen;
            //newForm.Show();
            //return newForm;

            T newForm = new T
            {
                MdiParent = mdiParent,
                StartPosition = FormStartPosition.WindowsDefaultLocation
            };
            newForm.Show();
            return newForm;
        }
        private void TsmiUserManage_Click(object sender, EventArgs e)
        {
            //OpenUniqueMDIChildWindow<QueueController>(this);
            foreach (Form childrenForm in this.MdiChildren)
            {
                if (childrenForm.Name == "QueueController")
                {
                    childrenForm.Visible = true;
                    childrenForm.Activate();
                    return;
                }

            }
            QueueController qc = new QueueController();
            qc.MdiParent = this;
            qc.Show();
        }

        private void TsmiWYZYHZ_Click(object sender, EventArgs e)
        {
            
        }

        private void TsbQueueController_Click(object sender, EventArgs e)
        {
            //QueueController qc = new QueueController();
            //qc.TopLevel = false;
            ////然后像添加普通控件一样加入到panel的controls里面就好
            //pnlFrameOfMirror.Controls.Add(qc);
            //qc.Show();
            //OpenUniqueMDIChildWindow<QueueController>(this);
            foreach (Form childrenForm in this.MdiChildren)
            {
                if (childrenForm.Name == "QueueController")
                {
                    childrenForm.Visible = true;
                    childrenForm.Activate();
                    return;
                }

            }
            QueueController qc = new QueueController();
            qc.MdiParent = this;
            qc.Show();
        }

        private void TsmiProvinceCity_Click(object sender, EventArgs e)
        {
            //使用MDI父容器，将子容器在父容器中显示（ProvinceCity是子容器，FrameOfMirror是父容器）
            //ProvinceCity pc = new ProvinceCity();
            //pc.MdiParent = this;
            //pc.Show();

            //ProvinceCity pc = new ProvinceCity();
            //pc.ShowDialog();
            //OpenUniqueMDIChildWindow<ProvinceCity>(this);
            foreach(Form childrenForm in this.MdiChildren)
            {
                if (childrenForm.Name == "QueueController")
                {
                    childrenForm.Visible = true;
                    childrenForm.Activate();
                    return;
                }

            }
            ProvinceCity pc = new ProvinceCity();
            pc.MdiParent = this;
            pc.Show();
        }

        private void TsbCustomerInformation_Click(object sender, EventArgs e)
        {
            //使用MDI父容器，将子容器在父容器中显示（CustomerInformation是子容器，FrameOfMirror是父容器）
            //CustomerInformation ci = new CustomerInformation();
            //ci.ShowDialog();
            OpenUniqueMDIChildWindow<CustomerInformation>(this);

        }

        public void Display()
        {

        }
    }
}