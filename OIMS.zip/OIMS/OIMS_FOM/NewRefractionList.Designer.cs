﻿namespace OIMS_FOM
{
    partial class NewRefractionList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpCustomerInformation = new System.Windows.Forms.GroupBox();
            this.cmbEye = new System.Windows.Forms.ComboBox();
            this.labEye = new System.Windows.Forms.Label();
            this.lblUseOfMydriasisDrugs = new System.Windows.Forms.Label();
            this.cmbUseOfMydriasisDrugs = new System.Windows.Forms.ComboBox();
            this.grpOptometryState = new System.Windows.Forms.GroupBox();
            this.rdoPupilOptometry = new System.Windows.Forms.RadioButton();
            this.rdoCycloplegicRefraction = new System.Windows.Forms.RadioButton();
            this.txtEyesightWithGlassesOS = new System.Windows.Forms.TextBox();
            this.txtEyesightWithGlassesOD = new System.Windows.Forms.TextBox();
            this.txtPinholeImagingOS = new System.Windows.Forms.TextBox();
            this.txtPinholeImagingOD = new System.Windows.Forms.TextBox();
            this.lblEyesightWithGlassesOS = new System.Windows.Forms.Label();
            this.lblEyesightWithGlassesOD = new System.Windows.Forms.Label();
            this.lblPinholeImagingOS = new System.Windows.Forms.Label();
            this.lblPinholeImagingOD = new System.Windows.Forms.Label();
            this.cmbBillingDoctor = new System.Windows.Forms.ComboBox();
            this.lblBillingDoctor = new System.Windows.Forms.Label();
            this.txtOutpatientDiagnosisOrTreatment = new System.Windows.Forms.TextBox();
            this.lblOutpatientDiagnosisOrTreatment = new System.Windows.Forms.Label();
            this.txtNakedEyeNearVisualAcuityBeforeExaminationRight = new System.Windows.Forms.TextBox();
            this.lblNakedEyeNearVisualAcuityBeforeExaminationRight = new System.Windows.Forms.Label();
            this.txtNakedEyeNearVisualAcuityBeforeExaminationLeft = new System.Windows.Forms.TextBox();
            this.lblNakedEyeNearVisualAcuityBeforeExaminationLeft = new System.Windows.Forms.Label();
            this.lblNakedEyeNearVisualAcuityBeforeExamination = new System.Windows.Forms.Label();
            this.txtOpenVisionBeforeExaminationRight = new System.Windows.Forms.TextBox();
            this.lblOpenVisionBeforeExaminationRight = new System.Windows.Forms.Label();
            this.lblOpenVisionBeforeExaminationLeft = new System.Windows.Forms.Label();
            this.lblOpenVisionBeforeExamination = new System.Windows.Forms.Label();
            this.txtOpenVisionBeforeExaminationLeft = new System.Windows.Forms.TextBox();
            this.rdoYes = new System.Windows.Forms.RadioButton();
            this.rdoNo = new System.Windows.Forms.RadioButton();
            this.lblMedicalHistory = new System.Windows.Forms.Label();
            this.txtMobilePhone = new System.Windows.Forms.TextBox();
            this.txtTelphone = new System.Windows.Forms.TextBox();
            this.lblMobilePhone = new System.Windows.Forms.Label();
            this.lblTelphone = new System.Windows.Forms.Label();
            this.txtCustomerSource2 = new System.Windows.Forms.TextBox();
            this.txtCustomerSource1 = new System.Windows.Forms.TextBox();
            this.lblCustomerSource2 = new System.Windows.Forms.Label();
            this.lblCustomerSource1 = new System.Windows.Forms.Label();
            this.txtIdNumber = new System.Windows.Forms.TextBox();
            this.cmbIdType = new System.Windows.Forms.ComboBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.txtWeixin = new System.Windows.Forms.TextBox();
            this.txtCommunity = new System.Windows.Forms.TextBox();
            this.txtStreet = new System.Windows.Forms.TextBox();
            this.txtCounty = new System.Windows.Forms.TextBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.txtProvince = new System.Windows.Forms.TextBox();
            this.txtPostcodes = new System.Windows.Forms.TextBox();
            this.txtProfession = new System.Windows.Forms.TextBox();
            this.txtAge = new System.Windows.Forms.TextBox();
            this.dtpBrithday = new System.Windows.Forms.DateTimePicker();
            this.rdoSexGirl = new System.Windows.Forms.RadioButton();
            this.rdoSexMan = new System.Windows.Forms.RadioButton();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.txtDateTime = new System.Windows.Forms.TextBox();
            this.txtBranchOffice = new System.Windows.Forms.TextBox();
            this.txtVisitingCardNumber = new System.Windows.Forms.TextBox();
            this.txtVisitingNumber = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.lblWeixin = new System.Windows.Forms.Label();
            this.lblCommunity = new System.Windows.Forms.Label();
            this.lblStreet = new System.Windows.Forms.Label();
            this.lblCounty = new System.Windows.Forms.Label();
            this.lblCity = new System.Windows.Forms.Label();
            this.lblProvince = new System.Windows.Forms.Label();
            this.lblPostcodes = new System.Windows.Forms.Label();
            this.lblProfession = new System.Windows.Forms.Label();
            this.lblAge = new System.Windows.Forms.Label();
            this.lblBrithday = new System.Windows.Forms.Label();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.lblDateTime = new System.Windows.Forms.Label();
            this.lblBranchOffice = new System.Windows.Forms.Label();
            this.lblVisitingCardNumber = new System.Windows.Forms.Label();
            this.lblVisitingNumber = new System.Windows.Forms.Label();
            this.grpCustomerInformationQuery = new System.Windows.Forms.GroupBox();
            this.dgvCustomerInformationQuery = new System.Windows.Forms.DataGridView();
            this.lblVisitingNumber1 = new System.Windows.Forms.Label();
            this.lblCustomerName1 = new System.Windows.Forms.Label();
            this.lblVisitingCardNumber1 = new System.Windows.Forms.Label();
            this.txtVisitingNumber1 = new System.Windows.Forms.TextBox();
            this.txtCustomerName1 = new System.Windows.Forms.TextBox();
            this.txtVisitingCardNumber1 = new System.Windows.Forms.TextBox();
            this.btnQuery = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.btnQuit = new System.Windows.Forms.Button();
            this.grpCustomerInformation.SuspendLayout();
            this.grpOptometryState.SuspendLayout();
            this.grpCustomerInformationQuery.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomerInformationQuery)).BeginInit();
            this.SuspendLayout();
            // 
            // grpCustomerInformation
            // 
            this.grpCustomerInformation.Controls.Add(this.cmbEye);
            this.grpCustomerInformation.Controls.Add(this.labEye);
            this.grpCustomerInformation.Controls.Add(this.lblUseOfMydriasisDrugs);
            this.grpCustomerInformation.Controls.Add(this.cmbUseOfMydriasisDrugs);
            this.grpCustomerInformation.Controls.Add(this.grpOptometryState);
            this.grpCustomerInformation.Controls.Add(this.txtEyesightWithGlassesOS);
            this.grpCustomerInformation.Controls.Add(this.txtEyesightWithGlassesOD);
            this.grpCustomerInformation.Controls.Add(this.txtPinholeImagingOS);
            this.grpCustomerInformation.Controls.Add(this.txtPinholeImagingOD);
            this.grpCustomerInformation.Controls.Add(this.lblEyesightWithGlassesOS);
            this.grpCustomerInformation.Controls.Add(this.lblEyesightWithGlassesOD);
            this.grpCustomerInformation.Controls.Add(this.lblPinholeImagingOS);
            this.grpCustomerInformation.Controls.Add(this.lblPinholeImagingOD);
            this.grpCustomerInformation.Controls.Add(this.cmbBillingDoctor);
            this.grpCustomerInformation.Controls.Add(this.lblBillingDoctor);
            this.grpCustomerInformation.Controls.Add(this.txtOutpatientDiagnosisOrTreatment);
            this.grpCustomerInformation.Controls.Add(this.lblOutpatientDiagnosisOrTreatment);
            this.grpCustomerInformation.Controls.Add(this.txtNakedEyeNearVisualAcuityBeforeExaminationRight);
            this.grpCustomerInformation.Controls.Add(this.lblNakedEyeNearVisualAcuityBeforeExaminationRight);
            this.grpCustomerInformation.Controls.Add(this.txtNakedEyeNearVisualAcuityBeforeExaminationLeft);
            this.grpCustomerInformation.Controls.Add(this.lblNakedEyeNearVisualAcuityBeforeExaminationLeft);
            this.grpCustomerInformation.Controls.Add(this.lblNakedEyeNearVisualAcuityBeforeExamination);
            this.grpCustomerInformation.Controls.Add(this.txtOpenVisionBeforeExaminationRight);
            this.grpCustomerInformation.Controls.Add(this.lblOpenVisionBeforeExaminationRight);
            this.grpCustomerInformation.Controls.Add(this.lblOpenVisionBeforeExaminationLeft);
            this.grpCustomerInformation.Controls.Add(this.lblOpenVisionBeforeExamination);
            this.grpCustomerInformation.Controls.Add(this.txtOpenVisionBeforeExaminationLeft);
            this.grpCustomerInformation.Controls.Add(this.rdoYes);
            this.grpCustomerInformation.Controls.Add(this.rdoNo);
            this.grpCustomerInformation.Controls.Add(this.lblMedicalHistory);
            this.grpCustomerInformation.Controls.Add(this.txtMobilePhone);
            this.grpCustomerInformation.Controls.Add(this.txtTelphone);
            this.grpCustomerInformation.Controls.Add(this.lblMobilePhone);
            this.grpCustomerInformation.Controls.Add(this.lblTelphone);
            this.grpCustomerInformation.Controls.Add(this.txtCustomerSource2);
            this.grpCustomerInformation.Controls.Add(this.txtCustomerSource1);
            this.grpCustomerInformation.Controls.Add(this.lblCustomerSource2);
            this.grpCustomerInformation.Controls.Add(this.lblCustomerSource1);
            this.grpCustomerInformation.Controls.Add(this.txtIdNumber);
            this.grpCustomerInformation.Controls.Add(this.cmbIdType);
            this.grpCustomerInformation.Controls.Add(this.txtAddress);
            this.grpCustomerInformation.Controls.Add(this.txtWeixin);
            this.grpCustomerInformation.Controls.Add(this.txtCommunity);
            this.grpCustomerInformation.Controls.Add(this.txtStreet);
            this.grpCustomerInformation.Controls.Add(this.txtCounty);
            this.grpCustomerInformation.Controls.Add(this.txtCity);
            this.grpCustomerInformation.Controls.Add(this.txtProvince);
            this.grpCustomerInformation.Controls.Add(this.txtPostcodes);
            this.grpCustomerInformation.Controls.Add(this.txtProfession);
            this.grpCustomerInformation.Controls.Add(this.txtAge);
            this.grpCustomerInformation.Controls.Add(this.dtpBrithday);
            this.grpCustomerInformation.Controls.Add(this.rdoSexGirl);
            this.grpCustomerInformation.Controls.Add(this.rdoSexMan);
            this.grpCustomerInformation.Controls.Add(this.txtCustomerName);
            this.grpCustomerInformation.Controls.Add(this.txtDateTime);
            this.grpCustomerInformation.Controls.Add(this.txtBranchOffice);
            this.grpCustomerInformation.Controls.Add(this.txtVisitingCardNumber);
            this.grpCustomerInformation.Controls.Add(this.txtVisitingNumber);
            this.grpCustomerInformation.Controls.Add(this.label17);
            this.grpCustomerInformation.Controls.Add(this.lblAddress);
            this.grpCustomerInformation.Controls.Add(this.lblWeixin);
            this.grpCustomerInformation.Controls.Add(this.lblCommunity);
            this.grpCustomerInformation.Controls.Add(this.lblStreet);
            this.grpCustomerInformation.Controls.Add(this.lblCounty);
            this.grpCustomerInformation.Controls.Add(this.lblCity);
            this.grpCustomerInformation.Controls.Add(this.lblProvince);
            this.grpCustomerInformation.Controls.Add(this.lblPostcodes);
            this.grpCustomerInformation.Controls.Add(this.lblProfession);
            this.grpCustomerInformation.Controls.Add(this.lblAge);
            this.grpCustomerInformation.Controls.Add(this.lblBrithday);
            this.grpCustomerInformation.Controls.Add(this.lblCustomerName);
            this.grpCustomerInformation.Controls.Add(this.lblDateTime);
            this.grpCustomerInformation.Controls.Add(this.lblBranchOffice);
            this.grpCustomerInformation.Controls.Add(this.lblVisitingCardNumber);
            this.grpCustomerInformation.Controls.Add(this.lblVisitingNumber);
            this.grpCustomerInformation.Location = new System.Drawing.Point(12, 5);
            this.grpCustomerInformation.Name = "grpCustomerInformation";
            this.grpCustomerInformation.Size = new System.Drawing.Size(773, 288);
            this.grpCustomerInformation.TabIndex = 0;
            this.grpCustomerInformation.TabStop = false;
            this.grpCustomerInformation.Text = "客户资料";
            // 
            // cmbEye
            // 
            this.cmbEye.FormattingEnabled = true;
            this.cmbEye.Location = new System.Drawing.Point(680, 249);
            this.cmbEye.Name = "cmbEye";
            this.cmbEye.Size = new System.Drawing.Size(59, 20);
            this.cmbEye.TabIndex = 74;
            // 
            // labEye
            // 
            this.labEye.AutoSize = true;
            this.labEye.Location = new System.Drawing.Point(633, 253);
            this.labEye.Name = "labEye";
            this.labEye.Size = new System.Drawing.Size(41, 12);
            this.labEye.TabIndex = 73;
            this.labEye.Text = "眼别：";
            // 
            // lblUseOfMydriasisDrugs
            // 
            this.lblUseOfMydriasisDrugs.AutoSize = true;
            this.lblUseOfMydriasisDrugs.Location = new System.Drawing.Point(272, 253);
            this.lblUseOfMydriasisDrugs.Name = "lblUseOfMydriasisDrugs";
            this.lblUseOfMydriasisDrugs.Size = new System.Drawing.Size(89, 12);
            this.lblUseOfMydriasisDrugs.TabIndex = 72;
            this.lblUseOfMydriasisDrugs.Text = "使用散瞳药物：";
            // 
            // cmbUseOfMydriasisDrugs
            // 
            this.cmbUseOfMydriasisDrugs.FormattingEnabled = true;
            this.cmbUseOfMydriasisDrugs.Location = new System.Drawing.Point(367, 249);
            this.cmbUseOfMydriasisDrugs.Name = "cmbUseOfMydriasisDrugs";
            this.cmbUseOfMydriasisDrugs.Size = new System.Drawing.Size(207, 20);
            this.cmbUseOfMydriasisDrugs.TabIndex = 71;
            // 
            // grpOptometryState
            // 
            this.grpOptometryState.Controls.Add(this.rdoPupilOptometry);
            this.grpOptometryState.Controls.Add(this.rdoCycloplegicRefraction);
            this.grpOptometryState.Location = new System.Drawing.Point(33, 239);
            this.grpOptometryState.Name = "grpOptometryState";
            this.grpOptometryState.Size = new System.Drawing.Size(200, 40);
            this.grpOptometryState.TabIndex = 1;
            this.grpOptometryState.TabStop = false;
            this.grpOptometryState.Text = "验光状态";
            // 
            // rdoPupilOptometry
            // 
            this.rdoPupilOptometry.AutoSize = true;
            this.rdoPupilOptometry.Location = new System.Drawing.Point(112, 18);
            this.rdoPupilOptometry.Name = "rdoPupilOptometry";
            this.rdoPupilOptometry.Size = new System.Drawing.Size(71, 16);
            this.rdoPupilOptometry.TabIndex = 72;
            this.rdoPupilOptometry.TabStop = true;
            this.rdoPupilOptometry.Text = "小瞳验光";
            this.rdoPupilOptometry.UseVisualStyleBackColor = true;
            // 
            // rdoCycloplegicRefraction
            // 
            this.rdoCycloplegicRefraction.AutoSize = true;
            this.rdoCycloplegicRefraction.Location = new System.Drawing.Point(9, 18);
            this.rdoCycloplegicRefraction.Name = "rdoCycloplegicRefraction";
            this.rdoCycloplegicRefraction.Size = new System.Drawing.Size(71, 16);
            this.rdoCycloplegicRefraction.TabIndex = 71;
            this.rdoCycloplegicRefraction.TabStop = true;
            this.rdoCycloplegicRefraction.Text = "散瞳验光";
            this.rdoCycloplegicRefraction.UseVisualStyleBackColor = true;
            // 
            // txtEyesightWithGlassesOS
            // 
            this.txtEyesightWithGlassesOS.Location = new System.Drawing.Point(562, 222);
            this.txtEyesightWithGlassesOS.Name = "txtEyesightWithGlassesOS";
            this.txtEyesightWithGlassesOS.Size = new System.Drawing.Size(61, 21);
            this.txtEyesightWithGlassesOS.TabIndex = 70;
            // 
            // txtEyesightWithGlassesOD
            // 
            this.txtEyesightWithGlassesOD.Location = new System.Drawing.Point(433, 222);
            this.txtEyesightWithGlassesOD.Name = "txtEyesightWithGlassesOD";
            this.txtEyesightWithGlassesOD.Size = new System.Drawing.Size(61, 21);
            this.txtEyesightWithGlassesOD.TabIndex = 69;
            // 
            // txtPinholeImagingOS
            // 
            this.txtPinholeImagingOS.Location = new System.Drawing.Point(291, 222);
            this.txtPinholeImagingOS.Name = "txtPinholeImagingOS";
            this.txtPinholeImagingOS.Size = new System.Drawing.Size(61, 21);
            this.txtPinholeImagingOS.TabIndex = 68;
            // 
            // txtPinholeImagingOD
            // 
            this.txtPinholeImagingOD.Location = new System.Drawing.Point(146, 222);
            this.txtPinholeImagingOD.Name = "txtPinholeImagingOD";
            this.txtPinholeImagingOD.Size = new System.Drawing.Size(61, 21);
            this.txtPinholeImagingOD.TabIndex = 67;
            // 
            // lblEyesightWithGlassesOS
            // 
            this.lblEyesightWithGlassesOS.AutoSize = true;
            this.lblEyesightWithGlassesOS.Location = new System.Drawing.Point(490, 226);
            this.lblEyesightWithGlassesOS.Name = "lblEyesightWithGlassesOS";
            this.lblEyesightWithGlassesOS.Size = new System.Drawing.Size(77, 12);
            this.lblEyesightWithGlassesOS.TabIndex = 66;
            this.lblEyesightWithGlassesOS.Text = "戴镜视力OS：";
            // 
            // lblEyesightWithGlassesOD
            // 
            this.lblEyesightWithGlassesOD.AutoSize = true;
            this.lblEyesightWithGlassesOD.Location = new System.Drawing.Point(362, 226);
            this.lblEyesightWithGlassesOD.Name = "lblEyesightWithGlassesOD";
            this.lblEyesightWithGlassesOD.Size = new System.Drawing.Size(77, 12);
            this.lblEyesightWithGlassesOD.TabIndex = 65;
            this.lblEyesightWithGlassesOD.Text = "戴镜视力OD：";
            // 
            // lblPinholeImagingOS
            // 
            this.lblPinholeImagingOS.AutoSize = true;
            this.lblPinholeImagingOS.Location = new System.Drawing.Point(213, 226);
            this.lblPinholeImagingOS.Name = "lblPinholeImagingOS";
            this.lblPinholeImagingOS.Size = new System.Drawing.Size(77, 12);
            this.lblPinholeImagingOS.TabIndex = 64;
            this.lblPinholeImagingOS.Text = "小孔成像OS：";
            // 
            // lblPinholeImagingOD
            // 
            this.lblPinholeImagingOD.AutoSize = true;
            this.lblPinholeImagingOD.Location = new System.Drawing.Point(63, 226);
            this.lblPinholeImagingOD.Name = "lblPinholeImagingOD";
            this.lblPinholeImagingOD.Size = new System.Drawing.Size(77, 12);
            this.lblPinholeImagingOD.TabIndex = 63;
            this.lblPinholeImagingOD.Text = "小孔成像OD：";
            // 
            // cmbBillingDoctor
            // 
            this.cmbBillingDoctor.FormattingEnabled = true;
            this.cmbBillingDoctor.Location = new System.Drawing.Point(677, 195);
            this.cmbBillingDoctor.Name = "cmbBillingDoctor";
            this.cmbBillingDoctor.Size = new System.Drawing.Size(81, 20);
            this.cmbBillingDoctor.TabIndex = 62;
            // 
            // lblBillingDoctor
            // 
            this.lblBillingDoctor.AutoSize = true;
            this.lblBillingDoctor.Location = new System.Drawing.Point(617, 199);
            this.lblBillingDoctor.Name = "lblBillingDoctor";
            this.lblBillingDoctor.Size = new System.Drawing.Size(65, 12);
            this.lblBillingDoctor.TabIndex = 61;
            this.lblBillingDoctor.Text = "开单医生：";
            // 
            // txtOutpatientDiagnosisOrTreatment
            // 
            this.txtOutpatientDiagnosisOrTreatment.Location = new System.Drawing.Point(145, 195);
            this.txtOutpatientDiagnosisOrTreatment.Name = "txtOutpatientDiagnosisOrTreatment";
            this.txtOutpatientDiagnosisOrTreatment.Size = new System.Drawing.Size(461, 21);
            this.txtOutpatientDiagnosisOrTreatment.TabIndex = 60;
            // 
            // lblOutpatientDiagnosisOrTreatment
            // 
            this.lblOutpatientDiagnosisOrTreatment.AutoSize = true;
            this.lblOutpatientDiagnosisOrTreatment.Location = new System.Drawing.Point(38, 199);
            this.lblOutpatientDiagnosisOrTreatment.Name = "lblOutpatientDiagnosisOrTreatment";
            this.lblOutpatientDiagnosisOrTreatment.Size = new System.Drawing.Size(101, 12);
            this.lblOutpatientDiagnosisOrTreatment.TabIndex = 59;
            this.lblOutpatientDiagnosisOrTreatment.Text = "门诊诊断或处理：";
            // 
            // txtNakedEyeNearVisualAcuityBeforeExaminationRight
            // 
            this.txtNakedEyeNearVisualAcuityBeforeExaminationRight.Location = new System.Drawing.Point(596, 168);
            this.txtNakedEyeNearVisualAcuityBeforeExaminationRight.Name = "txtNakedEyeNearVisualAcuityBeforeExaminationRight";
            this.txtNakedEyeNearVisualAcuityBeforeExaminationRight.Size = new System.Drawing.Size(61, 21);
            this.txtNakedEyeNearVisualAcuityBeforeExaminationRight.TabIndex = 58;
            // 
            // lblNakedEyeNearVisualAcuityBeforeExaminationRight
            // 
            this.lblNakedEyeNearVisualAcuityBeforeExaminationRight.AutoSize = true;
            this.lblNakedEyeNearVisualAcuityBeforeExaminationRight.Location = new System.Drawing.Point(576, 172);
            this.lblNakedEyeNearVisualAcuityBeforeExaminationRight.Name = "lblNakedEyeNearVisualAcuityBeforeExaminationRight";
            this.lblNakedEyeNearVisualAcuityBeforeExaminationRight.Size = new System.Drawing.Size(17, 12);
            this.lblNakedEyeNearVisualAcuityBeforeExaminationRight.TabIndex = 57;
            this.lblNakedEyeNearVisualAcuityBeforeExaminationRight.Text = "右";
            // 
            // txtNakedEyeNearVisualAcuityBeforeExaminationLeft
            // 
            this.txtNakedEyeNearVisualAcuityBeforeExaminationLeft.Location = new System.Drawing.Point(513, 168);
            this.txtNakedEyeNearVisualAcuityBeforeExaminationLeft.Name = "txtNakedEyeNearVisualAcuityBeforeExaminationLeft";
            this.txtNakedEyeNearVisualAcuityBeforeExaminationLeft.Size = new System.Drawing.Size(61, 21);
            this.txtNakedEyeNearVisualAcuityBeforeExaminationLeft.TabIndex = 56;
            // 
            // lblNakedEyeNearVisualAcuityBeforeExaminationLeft
            // 
            this.lblNakedEyeNearVisualAcuityBeforeExaminationLeft.AutoSize = true;
            this.lblNakedEyeNearVisualAcuityBeforeExaminationLeft.Location = new System.Drawing.Point(490, 172);
            this.lblNakedEyeNearVisualAcuityBeforeExaminationLeft.Name = "lblNakedEyeNearVisualAcuityBeforeExaminationLeft";
            this.lblNakedEyeNearVisualAcuityBeforeExaminationLeft.Size = new System.Drawing.Size(17, 12);
            this.lblNakedEyeNearVisualAcuityBeforeExaminationLeft.TabIndex = 55;
            this.lblNakedEyeNearVisualAcuityBeforeExaminationLeft.Text = "左";
            // 
            // lblNakedEyeNearVisualAcuityBeforeExamination
            // 
            this.lblNakedEyeNearVisualAcuityBeforeExamination.AutoSize = true;
            this.lblNakedEyeNearVisualAcuityBeforeExamination.Location = new System.Drawing.Point(381, 172);
            this.lblNakedEyeNearVisualAcuityBeforeExamination.Name = "lblNakedEyeNearVisualAcuityBeforeExamination";
            this.lblNakedEyeNearVisualAcuityBeforeExamination.Size = new System.Drawing.Size(113, 12);
            this.lblNakedEyeNearVisualAcuityBeforeExamination.TabIndex = 54;
            this.lblNakedEyeNearVisualAcuityBeforeExamination.Text = "检验前裸眼近视力：";
            // 
            // txtOpenVisionBeforeExaminationRight
            // 
            this.txtOpenVisionBeforeExaminationRight.Location = new System.Drawing.Point(246, 168);
            this.txtOpenVisionBeforeExaminationRight.Name = "txtOpenVisionBeforeExaminationRight";
            this.txtOpenVisionBeforeExaminationRight.Size = new System.Drawing.Size(61, 21);
            this.txtOpenVisionBeforeExaminationRight.TabIndex = 53;
            // 
            // lblOpenVisionBeforeExaminationRight
            // 
            this.lblOpenVisionBeforeExaminationRight.AutoSize = true;
            this.lblOpenVisionBeforeExaminationRight.Location = new System.Drawing.Point(223, 172);
            this.lblOpenVisionBeforeExaminationRight.Name = "lblOpenVisionBeforeExaminationRight";
            this.lblOpenVisionBeforeExaminationRight.Size = new System.Drawing.Size(17, 12);
            this.lblOpenVisionBeforeExaminationRight.TabIndex = 52;
            this.lblOpenVisionBeforeExaminationRight.Text = "右";
            // 
            // lblOpenVisionBeforeExaminationLeft
            // 
            this.lblOpenVisionBeforeExaminationLeft.AutoSize = true;
            this.lblOpenVisionBeforeExaminationLeft.Location = new System.Drawing.Point(130, 172);
            this.lblOpenVisionBeforeExaminationLeft.Name = "lblOpenVisionBeforeExaminationLeft";
            this.lblOpenVisionBeforeExaminationLeft.Size = new System.Drawing.Size(17, 12);
            this.lblOpenVisionBeforeExaminationLeft.TabIndex = 51;
            this.lblOpenVisionBeforeExaminationLeft.Text = "左";
            // 
            // lblOpenVisionBeforeExamination
            // 
            this.lblOpenVisionBeforeExamination.AutoSize = true;
            this.lblOpenVisionBeforeExamination.Location = new System.Drawing.Point(16, 172);
            this.lblOpenVisionBeforeExamination.Name = "lblOpenVisionBeforeExamination";
            this.lblOpenVisionBeforeExamination.Size = new System.Drawing.Size(113, 12);
            this.lblOpenVisionBeforeExamination.TabIndex = 50;
            this.lblOpenVisionBeforeExamination.Text = "检验前裸眼远视力：";
            // 
            // txtOpenVisionBeforeExaminationLeft
            // 
            this.txtOpenVisionBeforeExaminationLeft.Location = new System.Drawing.Point(146, 168);
            this.txtOpenVisionBeforeExaminationLeft.Name = "txtOpenVisionBeforeExaminationLeft";
            this.txtOpenVisionBeforeExaminationLeft.Size = new System.Drawing.Size(61, 21);
            this.txtOpenVisionBeforeExaminationLeft.TabIndex = 49;
            // 
            // rdoYes
            // 
            this.rdoYes.AutoSize = true;
            this.rdoYes.Location = new System.Drawing.Point(384, 129);
            this.rdoYes.Name = "rdoYes";
            this.rdoYes.Size = new System.Drawing.Size(35, 16);
            this.rdoYes.TabIndex = 48;
            this.rdoYes.TabStop = true;
            this.rdoYes.Text = "有";
            this.rdoYes.UseVisualStyleBackColor = true;
            // 
            // rdoNo
            // 
            this.rdoNo.AutoSize = true;
            this.rdoNo.Location = new System.Drawing.Point(349, 129);
            this.rdoNo.Name = "rdoNo";
            this.rdoNo.Size = new System.Drawing.Size(35, 16);
            this.rdoNo.TabIndex = 47;
            this.rdoNo.TabStop = true;
            this.rdoNo.Text = "无";
            this.rdoNo.UseVisualStyleBackColor = true;
            // 
            // lblMedicalHistory
            // 
            this.lblMedicalHistory.AutoSize = true;
            this.lblMedicalHistory.Location = new System.Drawing.Point(311, 131);
            this.lblMedicalHistory.Name = "lblMedicalHistory";
            this.lblMedicalHistory.Size = new System.Drawing.Size(41, 12);
            this.lblMedicalHistory.TabIndex = 46;
            this.lblMedicalHistory.Text = "病史：";
            // 
            // txtMobilePhone
            // 
            this.txtMobilePhone.Location = new System.Drawing.Point(205, 127);
            this.txtMobilePhone.Name = "txtMobilePhone";
            this.txtMobilePhone.Size = new System.Drawing.Size(100, 21);
            this.txtMobilePhone.TabIndex = 45;
            // 
            // txtTelphone
            // 
            this.txtTelphone.Location = new System.Drawing.Point(58, 127);
            this.txtTelphone.Name = "txtTelphone";
            this.txtTelphone.Size = new System.Drawing.Size(100, 21);
            this.txtTelphone.TabIndex = 44;
            // 
            // lblMobilePhone
            // 
            this.lblMobilePhone.AutoSize = true;
            this.lblMobilePhone.Location = new System.Drawing.Point(158, 131);
            this.lblMobilePhone.Name = "lblMobilePhone";
            this.lblMobilePhone.Size = new System.Drawing.Size(41, 12);
            this.lblMobilePhone.TabIndex = 43;
            this.lblMobilePhone.Text = "手机：";
            // 
            // lblTelphone
            // 
            this.lblTelphone.AutoSize = true;
            this.lblTelphone.Location = new System.Drawing.Point(19, 131);
            this.lblTelphone.Name = "lblTelphone";
            this.lblTelphone.Size = new System.Drawing.Size(41, 12);
            this.lblTelphone.TabIndex = 42;
            this.lblTelphone.Text = "电话：";
            // 
            // txtCustomerSource2
            // 
            this.txtCustomerSource2.Location = new System.Drawing.Point(695, 100);
            this.txtCustomerSource2.Name = "txtCustomerSource2";
            this.txtCustomerSource2.Size = new System.Drawing.Size(72, 21);
            this.txtCustomerSource2.TabIndex = 41;
            // 
            // txtCustomerSource1
            // 
            this.txtCustomerSource1.Location = new System.Drawing.Point(577, 100);
            this.txtCustomerSource1.Name = "txtCustomerSource1";
            this.txtCustomerSource1.Size = new System.Drawing.Size(76, 21);
            this.txtCustomerSource1.TabIndex = 40;
            // 
            // lblCustomerSource2
            // 
            this.lblCustomerSource2.AutoSize = true;
            this.lblCustomerSource2.Location = new System.Drawing.Point(659, 104);
            this.lblCustomerSource2.Name = "lblCustomerSource2";
            this.lblCustomerSource2.Size = new System.Drawing.Size(47, 12);
            this.lblCustomerSource2.TabIndex = 39;
            this.lblCustomerSource2.Text = "来源2：";
            // 
            // lblCustomerSource1
            // 
            this.lblCustomerSource1.AutoSize = true;
            this.lblCustomerSource1.Location = new System.Drawing.Point(527, 104);
            this.lblCustomerSource1.Name = "lblCustomerSource1";
            this.lblCustomerSource1.Size = new System.Drawing.Size(47, 12);
            this.lblCustomerSource1.TabIndex = 38;
            this.lblCustomerSource1.Text = "来源1：";
            // 
            // txtIdNumber
            // 
            this.txtIdNumber.Location = new System.Drawing.Point(367, 100);
            this.txtIdNumber.Name = "txtIdNumber";
            this.txtIdNumber.Size = new System.Drawing.Size(127, 21);
            this.txtIdNumber.TabIndex = 37;
            this.txtIdNumber.Text = "640322198901140319";
            // 
            // cmbIdType
            // 
            this.cmbIdType.FormattingEnabled = true;
            this.cmbIdType.Location = new System.Drawing.Point(277, 101);
            this.cmbIdType.Name = "cmbIdType";
            this.cmbIdType.Size = new System.Drawing.Size(50, 20);
            this.cmbIdType.TabIndex = 36;
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(58, 100);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(213, 21);
            this.txtAddress.TabIndex = 35;
            // 
            // txtWeixin
            // 
            this.txtWeixin.Location = new System.Drawing.Point(584, 73);
            this.txtWeixin.Name = "txtWeixin";
            this.txtWeixin.Size = new System.Drawing.Size(118, 21);
            this.txtWeixin.TabIndex = 34;
            // 
            // txtCommunity
            // 
            this.txtCommunity.Location = new System.Drawing.Point(471, 73);
            this.txtCommunity.Name = "txtCommunity";
            this.txtCommunity.Size = new System.Drawing.Size(56, 21);
            this.txtCommunity.TabIndex = 33;
            // 
            // txtStreet
            // 
            this.txtStreet.Location = new System.Drawing.Point(379, 73);
            this.txtStreet.Name = "txtStreet";
            this.txtStreet.Size = new System.Drawing.Size(71, 21);
            this.txtStreet.TabIndex = 32;
            this.txtStreet.Text = "大竹林街道";
            // 
            // txtCounty
            // 
            this.txtCounty.Location = new System.Drawing.Point(290, 73);
            this.txtCounty.Name = "txtCounty";
            this.txtCounty.Size = new System.Drawing.Size(56, 21);
            this.txtCounty.TabIndex = 31;
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(187, 73);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(56, 21);
            this.txtCity.TabIndex = 30;
            // 
            // txtProvince
            // 
            this.txtProvince.Location = new System.Drawing.Point(58, 74);
            this.txtProvince.Name = "txtProvince";
            this.txtProvince.Size = new System.Drawing.Size(100, 21);
            this.txtProvince.TabIndex = 29;
            this.txtProvince.Text = "新疆维吾尔自治区";
            // 
            // txtPostcodes
            // 
            this.txtPostcodes.Location = new System.Drawing.Point(678, 46);
            this.txtPostcodes.Name = "txtPostcodes";
            this.txtPostcodes.Size = new System.Drawing.Size(56, 21);
            this.txtPostcodes.TabIndex = 28;
            this.txtPostcodes.Text = "400000";
            // 
            // txtProfession
            // 
            this.txtProfession.Location = new System.Drawing.Point(539, 46);
            this.txtProfession.Name = "txtProfession";
            this.txtProfession.Size = new System.Drawing.Size(100, 21);
            this.txtProfession.TabIndex = 27;
            // 
            // txtAge
            // 
            this.txtAge.Location = new System.Drawing.Point(456, 46);
            this.txtAge.Name = "txtAge";
            this.txtAge.Size = new System.Drawing.Size(36, 21);
            this.txtAge.TabIndex = 26;
            // 
            // dtpBrithday
            // 
            this.dtpBrithday.Location = new System.Drawing.Point(277, 46);
            this.dtpBrithday.Name = "dtpBrithday";
            this.dtpBrithday.Size = new System.Drawing.Size(126, 21);
            this.dtpBrithday.TabIndex = 25;
            // 
            // rdoSexGirl
            // 
            this.rdoSexGirl.AutoSize = true;
            this.rdoSexGirl.Location = new System.Drawing.Point(205, 48);
            this.rdoSexGirl.Name = "rdoSexGirl";
            this.rdoSexGirl.Size = new System.Drawing.Size(35, 16);
            this.rdoSexGirl.TabIndex = 24;
            this.rdoSexGirl.TabStop = true;
            this.rdoSexGirl.Text = "女";
            this.rdoSexGirl.UseVisualStyleBackColor = true;
            // 
            // rdoSexMan
            // 
            this.rdoSexMan.AutoSize = true;
            this.rdoSexMan.Location = new System.Drawing.Point(164, 48);
            this.rdoSexMan.Name = "rdoSexMan";
            this.rdoSexMan.Size = new System.Drawing.Size(35, 16);
            this.rdoSexMan.TabIndex = 23;
            this.rdoSexMan.TabStop = true;
            this.rdoSexMan.Text = "男";
            this.rdoSexMan.UseVisualStyleBackColor = true;
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Location = new System.Drawing.Point(58, 47);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(100, 21);
            this.txtCustomerName.TabIndex = 22;
            this.txtCustomerName.Text = "北京普瑞眼科医院";
            // 
            // txtDateTime
            // 
            this.txtDateTime.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txtDateTime.Location = new System.Drawing.Point(620, 20);
            this.txtDateTime.Name = "txtDateTime";
            this.txtDateTime.Size = new System.Drawing.Size(122, 21);
            this.txtDateTime.TabIndex = 21;
            // 
            // txtBranchOffice
            // 
            this.txtBranchOffice.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txtBranchOffice.Location = new System.Drawing.Point(428, 20);
            this.txtBranchOffice.Name = "txtBranchOffice";
            this.txtBranchOffice.Size = new System.Drawing.Size(129, 21);
            this.txtBranchOffice.TabIndex = 20;
            // 
            // txtVisitingCardNumber
            // 
            this.txtVisitingCardNumber.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txtVisitingCardNumber.Location = new System.Drawing.Point(249, 20);
            this.txtVisitingCardNumber.Name = "txtVisitingCardNumber";
            this.txtVisitingCardNumber.Size = new System.Drawing.Size(143, 21);
            this.txtVisitingCardNumber.TabIndex = 19;
            this.txtVisitingCardNumber.Text = "10040179800S";
            // 
            // txtVisitingNumber
            // 
            this.txtVisitingNumber.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.txtVisitingNumber.Location = new System.Drawing.Point(58, 21);
            this.txtVisitingNumber.Name = "txtVisitingNumber";
            this.txtVisitingNumber.Size = new System.Drawing.Size(100, 21);
            this.txtVisitingNumber.TabIndex = 18;
            this.txtVisitingNumber.Text = "010011811140002";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(331, 104);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 12);
            this.label17.TabIndex = 17;
            this.label17.Text = "证件号：";
            // 
            // lblAddress
            // 
            this.lblAddress.AutoSize = true;
            this.lblAddress.Location = new System.Drawing.Point(19, 104);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(41, 12);
            this.lblAddress.TabIndex = 16;
            this.lblAddress.Text = "住址：";
            // 
            // lblWeixin
            // 
            this.lblWeixin.AutoSize = true;
            this.lblWeixin.Location = new System.Drawing.Point(532, 77);
            this.lblWeixin.Name = "lblWeixin";
            this.lblWeixin.Size = new System.Drawing.Size(53, 12);
            this.lblWeixin.TabIndex = 15;
            this.lblWeixin.Text = "微信号：";
            // 
            // lblCommunity
            // 
            this.lblCommunity.AutoSize = true;
            this.lblCommunity.Location = new System.Drawing.Point(440, 77);
            this.lblCommunity.Name = "lblCommunity";
            this.lblCommunity.Size = new System.Drawing.Size(41, 12);
            this.lblCommunity.TabIndex = 14;
            this.lblCommunity.Text = "社区：";
            // 
            // lblStreet
            // 
            this.lblStreet.AutoSize = true;
            this.lblStreet.Location = new System.Drawing.Point(351, 77);
            this.lblStreet.Name = "lblStreet";
            this.lblStreet.Size = new System.Drawing.Size(41, 12);
            this.lblStreet.TabIndex = 13;
            this.lblStreet.Text = "街道：";
            // 
            // lblCounty
            // 
            this.lblCounty.AutoSize = true;
            this.lblCounty.Location = new System.Drawing.Point(247, 77);
            this.lblCounty.Name = "lblCounty";
            this.lblCounty.Size = new System.Drawing.Size(41, 12);
            this.lblCounty.TabIndex = 12;
            this.lblCounty.Text = "区县：";
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Location = new System.Drawing.Point(162, 76);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(41, 12);
            this.lblCity.TabIndex = 11;
            this.lblCity.Text = "城市：";
            // 
            // lblProvince
            // 
            this.lblProvince.AutoSize = true;
            this.lblProvince.Location = new System.Drawing.Point(19, 78);
            this.lblProvince.Name = "lblProvince";
            this.lblProvince.Size = new System.Drawing.Size(41, 12);
            this.lblProvince.TabIndex = 10;
            this.lblProvince.Text = "省份：";
            // 
            // lblPostcodes
            // 
            this.lblPostcodes.AutoSize = true;
            this.lblPostcodes.Location = new System.Drawing.Point(645, 50);
            this.lblPostcodes.Name = "lblPostcodes";
            this.lblPostcodes.Size = new System.Drawing.Size(41, 12);
            this.lblPostcodes.TabIndex = 9;
            this.lblPostcodes.Text = "邮编：";
            // 
            // lblProfession
            // 
            this.lblProfession.AutoSize = true;
            this.lblProfession.Location = new System.Drawing.Point(498, 50);
            this.lblProfession.Name = "lblProfession";
            this.lblProfession.Size = new System.Drawing.Size(41, 12);
            this.lblProfession.TabIndex = 8;
            this.lblProfession.Text = "职业：";
            // 
            // lblAge
            // 
            this.lblAge.AutoSize = true;
            this.lblAge.Location = new System.Drawing.Point(409, 50);
            this.lblAge.Name = "lblAge";
            this.lblAge.Size = new System.Drawing.Size(41, 12);
            this.lblAge.TabIndex = 7;
            this.lblAge.Text = "年龄：";
            // 
            // lblBrithday
            // 
            this.lblBrithday.AutoSize = true;
            this.lblBrithday.Location = new System.Drawing.Point(241, 50);
            this.lblBrithday.Name = "lblBrithday";
            this.lblBrithday.Size = new System.Drawing.Size(41, 12);
            this.lblBrithday.TabIndex = 6;
            this.lblBrithday.Text = "生日：";
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Location = new System.Drawing.Point(19, 51);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(41, 12);
            this.lblCustomerName.TabIndex = 5;
            this.lblCustomerName.Text = "姓名：";
            // 
            // lblDateTime
            // 
            this.lblDateTime.AutoSize = true;
            this.lblDateTime.Location = new System.Drawing.Point(582, 24);
            this.lblDateTime.Name = "lblDateTime";
            this.lblDateTime.Size = new System.Drawing.Size(41, 12);
            this.lblDateTime.TabIndex = 4;
            this.lblDateTime.Text = "时间：";
            // 
            // lblBranchOffice
            // 
            this.lblBranchOffice.AutoSize = true;
            this.lblBranchOffice.Location = new System.Drawing.Point(384, 24);
            this.lblBranchOffice.Name = "lblBranchOffice";
            this.lblBranchOffice.Size = new System.Drawing.Size(41, 12);
            this.lblBranchOffice.TabIndex = 3;
            this.lblBranchOffice.Text = "分店：";
            // 
            // lblVisitingCardNumber
            // 
            this.lblVisitingCardNumber.AutoSize = true;
            this.lblVisitingCardNumber.Location = new System.Drawing.Point(178, 24);
            this.lblVisitingCardNumber.Name = "lblVisitingCardNumber";
            this.lblVisitingCardNumber.Size = new System.Drawing.Size(65, 12);
            this.lblVisitingCardNumber.TabIndex = 2;
            this.lblVisitingCardNumber.Text = "就诊卡号：";
            // 
            // lblVisitingNumber
            // 
            this.lblVisitingNumber.AutoSize = true;
            this.lblVisitingNumber.Location = new System.Drawing.Point(7, 25);
            this.lblVisitingNumber.Name = "lblVisitingNumber";
            this.lblVisitingNumber.Size = new System.Drawing.Size(53, 12);
            this.lblVisitingNumber.TabIndex = 1;
            this.lblVisitingNumber.Text = "就诊号：";
            // 
            // grpCustomerInformationQuery
            // 
            this.grpCustomerInformationQuery.Controls.Add(this.dgvCustomerInformationQuery);
            this.grpCustomerInformationQuery.Location = new System.Drawing.Point(12, 361);
            this.grpCustomerInformationQuery.Name = "grpCustomerInformationQuery";
            this.grpCustomerInformationQuery.Size = new System.Drawing.Size(773, 275);
            this.grpCustomerInformationQuery.TabIndex = 1;
            this.grpCustomerInformationQuery.TabStop = false;
            this.grpCustomerInformationQuery.Text = "客户资料查询：";
            // 
            // dgvCustomerInformationQuery
            // 
            this.dgvCustomerInformationQuery.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dgvCustomerInformationQuery.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvCustomerInformationQuery.Location = new System.Drawing.Point(9, 20);
            this.dgvCustomerInformationQuery.Name = "dgvCustomerInformationQuery";
            this.dgvCustomerInformationQuery.RowTemplate.Height = 23;
            this.dgvCustomerInformationQuery.Size = new System.Drawing.Size(754, 246);
            this.dgvCustomerInformationQuery.TabIndex = 0;
            this.dgvCustomerInformationQuery.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.DgvCustomerInformationQuery_RowPostPaint);
            // 
            // lblVisitingNumber1
            // 
            this.lblVisitingNumber1.AutoSize = true;
            this.lblVisitingNumber1.Location = new System.Drawing.Point(53, 309);
            this.lblVisitingNumber1.Name = "lblVisitingNumber1";
            this.lblVisitingNumber1.Size = new System.Drawing.Size(53, 12);
            this.lblVisitingNumber1.TabIndex = 2;
            this.lblVisitingNumber1.Text = "就诊号：";
            // 
            // lblCustomerName1
            // 
            this.lblCustomerName1.AutoSize = true;
            this.lblCustomerName1.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.lblCustomerName1.ForeColor = System.Drawing.Color.Red;
            this.lblCustomerName1.Location = new System.Drawing.Point(276, 309);
            this.lblCustomerName1.Name = "lblCustomerName1";
            this.lblCustomerName1.Size = new System.Drawing.Size(44, 12);
            this.lblCustomerName1.TabIndex = 3;
            this.lblCustomerName1.Text = "姓名：";
            // 
            // lblVisitingCardNumber1
            // 
            this.lblVisitingCardNumber1.AutoSize = true;
            this.lblVisitingCardNumber1.Location = new System.Drawing.Point(41, 340);
            this.lblVisitingCardNumber1.Name = "lblVisitingCardNumber1";
            this.lblVisitingCardNumber1.Size = new System.Drawing.Size(65, 12);
            this.lblVisitingCardNumber1.TabIndex = 4;
            this.lblVisitingCardNumber1.Text = "就诊卡号：";
            // 
            // txtVisitingNumber1
            // 
            this.txtVisitingNumber1.Location = new System.Drawing.Point(111, 305);
            this.txtVisitingNumber1.Name = "txtVisitingNumber1";
            this.txtVisitingNumber1.Size = new System.Drawing.Size(144, 21);
            this.txtVisitingNumber1.TabIndex = 5;
            // 
            // txtCustomerName1
            // 
            this.txtCustomerName1.Location = new System.Drawing.Point(325, 305);
            this.txtCustomerName1.Name = "txtCustomerName1";
            this.txtCustomerName1.Size = new System.Drawing.Size(100, 21);
            this.txtCustomerName1.TabIndex = 6;
            // 
            // txtVisitingCardNumber1
            // 
            this.txtVisitingCardNumber1.Location = new System.Drawing.Point(111, 336);
            this.txtVisitingCardNumber1.Name = "txtVisitingCardNumber1";
            this.txtVisitingCardNumber1.Size = new System.Drawing.Size(314, 21);
            this.txtVisitingCardNumber1.TabIndex = 7;
            // 
            // btnQuery
            // 
            this.btnQuery.Location = new System.Drawing.Point(454, 304);
            this.btnQuery.Name = "btnQuery";
            this.btnQuery.Size = new System.Drawing.Size(65, 23);
            this.btnQuery.TabIndex = 1;
            this.btnQuery.Text = "查询";
            this.btnQuery.UseVisualStyleBackColor = true;
            this.btnQuery.Click += new System.EventHandler(this.BtnQuery_Click);
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(454, 335);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(65, 23);
            this.btnSave.TabIndex = 8;
            this.btnSave.Text = "保存";
            this.btnSave.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(542, 304);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(65, 23);
            this.button1.TabIndex = 9;
            this.button1.Text = "新建";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(542, 335);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(65, 23);
            this.button2.TabIndex = 10;
            this.button2.Text = "历史信息";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // btnQuit
            // 
            this.btnQuit.Location = new System.Drawing.Point(630, 335);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(65, 23);
            this.btnQuit.TabIndex = 11;
            this.btnQuit.Text = "退出";
            this.btnQuit.UseVisualStyleBackColor = true;
            this.btnQuit.Click += new System.EventHandler(this.BtnQuit_Click);
            // 
            // NewRefractionList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(797, 660);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnQuery);
            this.Controls.Add(this.txtVisitingCardNumber1);
            this.Controls.Add(this.txtCustomerName1);
            this.Controls.Add(this.txtVisitingNumber1);
            this.Controls.Add(this.lblVisitingCardNumber1);
            this.Controls.Add(this.lblCustomerName1);
            this.Controls.Add(this.lblVisitingNumber1);
            this.Controls.Add(this.grpCustomerInformationQuery);
            this.Controls.Add(this.grpCustomerInformation);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "NewRefractionList";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "添加验光单资料";
            this.grpCustomerInformation.ResumeLayout(false);
            this.grpCustomerInformation.PerformLayout();
            this.grpOptometryState.ResumeLayout(false);
            this.grpOptometryState.PerformLayout();
            this.grpCustomerInformationQuery.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomerInformationQuery)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpCustomerInformation;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.Label lblWeixin;
        private System.Windows.Forms.Label lblCommunity;
        private System.Windows.Forms.Label lblStreet;
        private System.Windows.Forms.Label lblCounty;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.Label lblProvince;
        private System.Windows.Forms.Label lblPostcodes;
        private System.Windows.Forms.Label lblProfession;
        private System.Windows.Forms.Label lblAge;
        private System.Windows.Forms.Label lblBrithday;
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.Label lblDateTime;
        private System.Windows.Forms.Label lblBranchOffice;
        private System.Windows.Forms.Label lblVisitingCardNumber;
        private System.Windows.Forms.Label lblVisitingNumber;
        private System.Windows.Forms.TextBox txtBranchOffice;
        private System.Windows.Forms.TextBox txtVisitingCardNumber;
        private System.Windows.Forms.TextBox txtVisitingNumber;
        private System.Windows.Forms.TextBox txtDateTime;
        private System.Windows.Forms.RadioButton rdoSexGirl;
        private System.Windows.Forms.RadioButton rdoSexMan;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.DateTimePicker dtpBrithday;
        private System.Windows.Forms.TextBox txtAge;
        private System.Windows.Forms.TextBox txtProfession;
        private System.Windows.Forms.TextBox txtPostcodes;
        private System.Windows.Forms.TextBox txtWeixin;
        private System.Windows.Forms.TextBox txtCommunity;
        private System.Windows.Forms.TextBox txtStreet;
        private System.Windows.Forms.TextBox txtCounty;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.TextBox txtProvince;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.ComboBox cmbIdType;
        private System.Windows.Forms.TextBox txtIdNumber;
        private System.Windows.Forms.Label lblCustomerSource2;
        private System.Windows.Forms.Label lblCustomerSource1;
        private System.Windows.Forms.TextBox txtCustomerSource2;
        private System.Windows.Forms.TextBox txtCustomerSource1;
        private System.Windows.Forms.TextBox txtMobilePhone;
        private System.Windows.Forms.TextBox txtTelphone;
        private System.Windows.Forms.Label lblMobilePhone;
        private System.Windows.Forms.Label lblTelphone;
        private System.Windows.Forms.Label lblMedicalHistory;
        private System.Windows.Forms.RadioButton rdoNo;
        private System.Windows.Forms.RadioButton rdoYes;
        private System.Windows.Forms.Label lblOpenVisionBeforeExamination;
        private System.Windows.Forms.TextBox txtOpenVisionBeforeExaminationLeft;
        private System.Windows.Forms.TextBox txtNakedEyeNearVisualAcuityBeforeExaminationRight;
        private System.Windows.Forms.Label lblNakedEyeNearVisualAcuityBeforeExaminationRight;
        private System.Windows.Forms.TextBox txtNakedEyeNearVisualAcuityBeforeExaminationLeft;
        private System.Windows.Forms.Label lblNakedEyeNearVisualAcuityBeforeExaminationLeft;
        private System.Windows.Forms.Label lblNakedEyeNearVisualAcuityBeforeExamination;
        private System.Windows.Forms.TextBox txtOpenVisionBeforeExaminationRight;
        private System.Windows.Forms.Label lblOpenVisionBeforeExaminationRight;
        private System.Windows.Forms.Label lblOpenVisionBeforeExaminationLeft;
        private System.Windows.Forms.Label lblOutpatientDiagnosisOrTreatment;
        private System.Windows.Forms.TextBox txtOutpatientDiagnosisOrTreatment;
        private System.Windows.Forms.Label lblBillingDoctor;
        private System.Windows.Forms.ComboBox cmbBillingDoctor;
        private System.Windows.Forms.TextBox txtEyesightWithGlassesOS;
        private System.Windows.Forms.TextBox txtEyesightWithGlassesOD;
        private System.Windows.Forms.TextBox txtPinholeImagingOS;
        private System.Windows.Forms.TextBox txtPinholeImagingOD;
        private System.Windows.Forms.Label lblEyesightWithGlassesOS;
        private System.Windows.Forms.Label lblEyesightWithGlassesOD;
        private System.Windows.Forms.Label lblPinholeImagingOS;
        private System.Windows.Forms.Label lblPinholeImagingOD;
        private System.Windows.Forms.GroupBox grpOptometryState;
        private System.Windows.Forms.RadioButton rdoCycloplegicRefraction;
        private System.Windows.Forms.RadioButton rdoPupilOptometry;
        private System.Windows.Forms.Label lblUseOfMydriasisDrugs;
        private System.Windows.Forms.ComboBox cmbUseOfMydriasisDrugs;
        private System.Windows.Forms.Label labEye;
        private System.Windows.Forms.ComboBox cmbEye;
        private System.Windows.Forms.GroupBox grpCustomerInformationQuery;
        private System.Windows.Forms.DataGridView dgvCustomerInformationQuery;
        private System.Windows.Forms.Label lblVisitingNumber1;
        private System.Windows.Forms.Label lblCustomerName1;
        private System.Windows.Forms.Label lblVisitingCardNumber1;
        private System.Windows.Forms.TextBox txtVisitingNumber1;
        private System.Windows.Forms.TextBox txtCustomerName1;
        private System.Windows.Forms.TextBox txtVisitingCardNumber1;
        private System.Windows.Forms.Button btnQuery;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnQuit;
    }
}