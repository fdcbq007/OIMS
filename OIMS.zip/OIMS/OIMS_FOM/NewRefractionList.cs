﻿using OIMS_DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
//using OIMS_DAL;
using OIMS_FOM_BLL;

namespace OIMS_FOM
{
    public partial class NewRefractionList : Form
    {
        public NewRefractionList()
        {
            InitializeComponent();
            txtBranchOffice.Text = LoginUserHelper.LoginComapny;
            txtDateTime.Text = DateTime.Now.ToLocalTime().ToString();
            txtProfession.Text = Guid.NewGuid().ToString();
            txtProvince.Text = ProvinceCityBLL.FomProvince;
            txtCity.Text = ProvinceCityBLL.FomCity;
        }


        private void NewRefractionList_FormClosed(object sender, FormClosedEventArgs e)
        {
            this.Close();
        }

        private void BtnQuit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnQuery_Click(object sender, EventArgs e)
        {
            Display();
        }

        public void Display()
        {
            if (string.IsNullOrWhiteSpace(txtCustomerName1.Text) && string.IsNullOrWhiteSpace(txtVisitingNumber1.Text))
            {
                MessageBox.Show("未输入就诊号或姓名。请重新输入！");
                return;
            }
            else if (txtCustomerName1.Text != string.Empty && txtVisitingNumber1.Text != string.Empty)
            {
                MessageBox.Show("就诊号或姓名不能同时输入。请重新输入！");
            }
            else
            {
                if (string.IsNullOrWhiteSpace(txtCustomerName1.Text))
                {
                    txtVisitingNumber.Text = txtVisitingNumber1.Text.Trim();


                }
                else if (string.IsNullOrWhiteSpace(txtVisitingNumber1.Text))
                {
                    txtCustomerName.Text = txtCustomerName1.Text.Trim();
                    SqlConnection conn = OIMS_FOM_Helper.GetConnection(OIMS_FOM_Helper.GetConnString());
                    conn.Open();
                    string strSql = "select * from v_yh_ygdzl where brxm like '%" + txtCustomerName1.Text.Trim() + "%'";
                    SqlDataAdapter sda = new SqlDataAdapter();
                    SqlCommand cmd = new SqlCommand(strSql, conn);
                    sda.SelectCommand = cmd;

                    DataSet ds = new DataSet();
                    ds.Clear();

                    sda.TableMappings.Add("SourceTable", "DestTable");
                    sda.TableMappings.Add("DestTable", "DestTable");

                    sda.TableMappings["DestTable"].ColumnMappings.Add("JGMC", "公司");
                    sda.TableMappings["DestTable"].ColumnMappings.Add("BRXM", "客户姓名");
                    sda.TableMappings["DestTable"].ColumnMappings.Add("BRKH", "就诊卡号");
                    sda.TableMappings["DestTable"].ColumnMappings.Add("SEX", "性别");
                    sda.TableMappings["DestTable"].ColumnMappings.Add("CSRQ", "出生日期");
                    sda.TableMappings["DestTable"].ColumnMappings.Add("BRNL", "年龄");

                    sda.Fill(ds,"DestTable");

                    try
                    {
                        this.dgvCustomerInformationQuery.DataSource = ds;
                        this.dgvCustomerInformationQuery.DataMember = "DestTable";

                        //显示列宽
                        dgvCustomerInformationQuery.Columns[0].Width = 90;
                        dgvCustomerInformationQuery.Columns[1].Width = 90;
                        dgvCustomerInformationQuery.Columns[2].Width = 100;
                        dgvCustomerInformationQuery.Columns[3].Width = 100;
                        dgvCustomerInformationQuery.Columns[4].Width = 100;
                        dgvCustomerInformationQuery.Columns[5].Width = 100;
                    }
                    catch
                    {
                        MessageBox.Show("error!");
                    }

                    if (conn.State == ConnectionState.Open)
                    {
                        conn.Close();
                    }
                }
                else
                {
                    return;
                }
            }
        }

        private void DgvCustomerInformationQuery_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            var grid = sender as DataGridView;
            var rowIdx = (e.RowIndex + 1).ToString();

            var centerFormat = new StringFormat()
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };

            var headerBounds = new Rectangle(e.RowBounds.Left, e.RowBounds.Top, grid.RowHeadersWidth, e.RowBounds.Height);
            e.Graphics.DrawString(rowIdx, this.Font, SystemBrushes.ControlText, headerBounds, centerFormat);
        }
    }
}
