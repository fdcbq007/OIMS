﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS_FOM_BLL
{
    public class ProvinceCityBLL
    {
        private static string fomProvince;
        private static string fomCity;

        public static string FomProvince { get => fomProvince; set => fomProvince = value; }
        public static string FomCity { get => fomCity; set => fomCity = value; }
    }
}
