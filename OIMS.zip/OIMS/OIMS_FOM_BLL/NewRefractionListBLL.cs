﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS_FOM_BLL
{
    public class NewRefractionListBLL
    {

    }
}
