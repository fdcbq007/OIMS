﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using OIMS_DAL;

namespace OIMS_BLL
{
    public class LoginBLL
   {
        /// <summary> 
        /// 1、校验输入的用户ID和密码是否完整
        /// 2、校验输入的用户ID和密码是否是数字和字母 
        public static bool IsValidataInput(string LoginUserId, string LoginUserPass)
        {

            if (0 == LoginUserId.Length || 0 == LoginUserPass.Length)
            {
                MessageBox.Show(null, "请填写完整！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            else if (Validator.IsIntegerAndEnglishCharacter(LoginUserId) == false && Validator.IsIntegerAndEnglishCharacter(LoginUserPass) == false)
            {
                MessageBox.Show("用户ID格式输入有误，请重新输入！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            else
            {
                return true;
            }           
        }

        /// <summary> 
        /// 1、判断输入的用户名和密码是否在数据库中存在
        public static bool IsValidataUserId(string LoginUserId, string LoginUserPass, ref string message)
        {
            string sqlStr = String.Format("select count(*) from Users where sDLZH = '{0}' and sDLMM = '{1}'",
                LoginUserId, DesEncryption.EncryptDES(LoginUserPass+ LoginUserId, "201902231230"));
            int i = LoginHelper.ShowSelect(sqlStr);
            if (i < 1)
            {
                message = "密码输入错误，请重新输入！";
                return false;
            }
            else
            {
                return true;
            }
        }

        /// <summary> 
        /// 1、获取输入的用户ID对应的用户名
        public static string ReturnUserName(string LoginUserId, ref string message)
        {
            //string getUserName;
            string sqlStr = string.Format("select sYHM from Users where sDLZH = '{0}'", LoginUserId);
            string userName = LoginHelper.ReturnUserName(sqlStr);
            if (string.IsNullOrWhiteSpace(userName))
            {
                message = "该用户名不存在！";
                return message;
            }
            else
            {
                return userName;
            }
        }
    }
}
