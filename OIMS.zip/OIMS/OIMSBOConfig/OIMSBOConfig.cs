﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using OIMSConfig_BLL;

namespace OIMSBOConfig
{
    public partial class OIMSBOConfig : Form
    {
        private string serverIpName;
        private string databaseName;
        private string databaseUserName;
        private string databaseUserPwd;
        public OIMSBOConfig()
        {
            InitializeComponent();

            //初始化读取配置文件中的数据信息。两种获取配置文件的信息都可以
            //string strSqlConnection = ConfigurationManager.AppSettings["ConnString"].ToString().Trim();
            string strSqlConnection = ConfigurationManager.ConnectionStrings["ConnectionString"].ToString().Trim();
            string[] strSqlConnectionArray = strSqlConnection.Split(';');

            serverIpName = strSqlConnectionArray[0];
            string[] serverIpNameArray = serverIpName.Split('=');
            databaseName = strSqlConnectionArray[1];
            string[] databaseNameArray = databaseName.Split('=');
            databaseUserName = strSqlConnectionArray[2];
            string[] databaseUserNameArray = databaseUserName.Split('=');
            databaseUserPwd = strSqlConnectionArray[3];
            string[] databaseUserPwdArray = databaseUserPwd.Split('=');

            txtServerIpName.Text = serverIpNameArray[1];
            txtDatabaseName.Text = databaseNameArray[1];
            txtDatabaseUserName.Text = databaseUserNameArray[1];
            txtDatabaseUserPwd.Text = databaseUserPwdArray[1];
        }

        private void BtnSaveSQLServer_Click(object sender, EventArgs e)
        {
            string connectionString = "server=" + txtServerIpName.Text.Trim() + ";" + "database=" + txtDatabaseName.Text.Trim() + ";" + "UID=" + txtDatabaseUserName.Text.Trim() + ";" + "password=" + txtDatabaseUserPwd.Text.Trim();
            ConfigFileOperation.UpdateConnectionStringsConfig("ConnectionString", connectionString);
            MessageBox.Show("数据库更新成功:" + ConfigurationManager.ConnectionStrings["ConnectionString"].ToString().Trim(), "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Information);

            
        }

        private void BtnTestSQLServer_Click(object sender, EventArgs e)
        {
            serverIpName = txtServerIpName.Text.Trim();
            databaseName = txtDatabaseName.Text.Trim();
            databaseUserName = txtDatabaseUserName.Text.Trim();
            databaseUserPwd = txtDatabaseUserPwd.Text.Trim();

            try
            {
                TestSQLServer testSQLServer = new TestSQLServer();
                int sqlServer = testSQLServer.GetNum(serverIpName, databaseName, databaseUserName, databaseUserPwd);
                if (sqlServer == 1)
                {
                    MessageBox.Show("数据库连接成功", "提示");
                }
                else
                {
                    MessageBox.Show("数据库连接失败", "提示");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "操作数据库出错！", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            
        }

        private void BtnQuitSQLServer_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("您确定要退出登录吗？", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
