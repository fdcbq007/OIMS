﻿namespace OIMSBOConfig
{
    partial class OIMSBOConfig
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtDatabaseUserPwd = new System.Windows.Forms.TextBox();
            this.txtDatabaseUserName = new System.Windows.Forms.TextBox();
            this.txtDatabaseName = new System.Windows.Forms.TextBox();
            this.txtServerIpName = new System.Windows.Forms.TextBox();
            this.labDatabaseUserName = new System.Windows.Forms.Label();
            this.labDatabaseUserPwd = new System.Windows.Forms.Label();
            this.labDatabaseName = new System.Windows.Forms.Label();
            this.labServerIpName = new System.Windows.Forms.Label();
            this.BtnTestSQLServer = new System.Windows.Forms.Button();
            this.BtnSaveSQLServer = new System.Windows.Forms.Button();
            this.BtnQuitSQLServer = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtDatabaseUserPwd);
            this.groupBox1.Controls.Add(this.txtDatabaseUserName);
            this.groupBox1.Controls.Add(this.txtDatabaseName);
            this.groupBox1.Controls.Add(this.txtServerIpName);
            this.groupBox1.Controls.Add(this.labDatabaseUserName);
            this.groupBox1.Controls.Add(this.labDatabaseUserPwd);
            this.groupBox1.Controls.Add(this.labDatabaseName);
            this.groupBox1.Controls.Add(this.labServerIpName);
            this.groupBox1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(380, 194);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "分店服务器连接参数设置";
            // 
            // txtDatabaseUserPwd
            // 
            this.txtDatabaseUserPwd.Location = new System.Drawing.Point(157, 149);
            this.txtDatabaseUserPwd.Name = "txtDatabaseUserPwd";
            this.txtDatabaseUserPwd.PasswordChar = '*';
            this.txtDatabaseUserPwd.Size = new System.Drawing.Size(189, 26);
            this.txtDatabaseUserPwd.TabIndex = 4;
            // 
            // txtDatabaseUserName
            // 
            this.txtDatabaseUserName.Location = new System.Drawing.Point(157, 113);
            this.txtDatabaseUserName.Name = "txtDatabaseUserName";
            this.txtDatabaseUserName.Size = new System.Drawing.Size(189, 26);
            this.txtDatabaseUserName.TabIndex = 3;
            // 
            // txtDatabaseName
            // 
            this.txtDatabaseName.Location = new System.Drawing.Point(157, 77);
            this.txtDatabaseName.Name = "txtDatabaseName";
            this.txtDatabaseName.Size = new System.Drawing.Size(189, 26);
            this.txtDatabaseName.TabIndex = 2;
            // 
            // txtServerIpName
            // 
            this.txtServerIpName.Location = new System.Drawing.Point(157, 41);
            this.txtServerIpName.Name = "txtServerIpName";
            this.txtServerIpName.Size = new System.Drawing.Size(189, 26);
            this.txtServerIpName.TabIndex = 1;
            // 
            // labDatabaseUserName
            // 
            this.labDatabaseUserName.AutoSize = true;
            this.labDatabaseUserName.Location = new System.Drawing.Point(93, 118);
            this.labDatabaseUserName.Name = "labDatabaseUserName";
            this.labDatabaseUserName.Size = new System.Drawing.Size(64, 16);
            this.labDatabaseUserName.TabIndex = 3;
            this.labDatabaseUserName.Text = "用户名:";
            // 
            // labDatabaseUserPwd
            // 
            this.labDatabaseUserPwd.AutoSize = true;
            this.labDatabaseUserPwd.Location = new System.Drawing.Point(77, 154);
            this.labDatabaseUserPwd.Name = "labDatabaseUserPwd";
            this.labDatabaseUserPwd.Size = new System.Drawing.Size(80, 16);
            this.labDatabaseUserPwd.TabIndex = 2;
            this.labDatabaseUserPwd.Text = "用户密码:";
            // 
            // labDatabaseName
            // 
            this.labDatabaseName.AutoSize = true;
            this.labDatabaseName.Location = new System.Drawing.Point(61, 82);
            this.labDatabaseName.Name = "labDatabaseName";
            this.labDatabaseName.Size = new System.Drawing.Size(96, 16);
            this.labDatabaseName.TabIndex = 1;
            this.labDatabaseName.Text = "数据库名称:";
            // 
            // labServerIpName
            // 
            this.labServerIpName.AutoSize = true;
            this.labServerIpName.Location = new System.Drawing.Point(37, 46);
            this.labServerIpName.Name = "labServerIpName";
            this.labServerIpName.Size = new System.Drawing.Size(120, 16);
            this.labServerIpName.TabIndex = 0;
            this.labServerIpName.Text = "服务器IP/名称:";
            // 
            // BtnTestSQLServer
            // 
            this.BtnTestSQLServer.Location = new System.Drawing.Point(63, 222);
            this.BtnTestSQLServer.Name = "BtnTestSQLServer";
            this.BtnTestSQLServer.Size = new System.Drawing.Size(75, 30);
            this.BtnTestSQLServer.TabIndex = 5;
            this.BtnTestSQLServer.Text = "测试";
            this.BtnTestSQLServer.UseVisualStyleBackColor = true;
            this.BtnTestSQLServer.Click += new System.EventHandler(this.BtnTestSQLServer_Click);
            // 
            // BtnSaveSQLServer
            // 
            this.BtnSaveSQLServer.Location = new System.Drawing.Point(164, 222);
            this.BtnSaveSQLServer.Name = "BtnSaveSQLServer";
            this.BtnSaveSQLServer.Size = new System.Drawing.Size(75, 30);
            this.BtnSaveSQLServer.TabIndex = 6;
            this.BtnSaveSQLServer.Text = "保存";
            this.BtnSaveSQLServer.UseVisualStyleBackColor = true;
            this.BtnSaveSQLServer.Click += new System.EventHandler(this.BtnSaveSQLServer_Click);
            // 
            // BtnQuitSQLServer
            // 
            this.BtnQuitSQLServer.Location = new System.Drawing.Point(265, 222);
            this.BtnQuitSQLServer.Name = "BtnQuitSQLServer";
            this.BtnQuitSQLServer.Size = new System.Drawing.Size(75, 30);
            this.BtnQuitSQLServer.TabIndex = 7;
            this.BtnQuitSQLServer.Text = "退出";
            this.BtnQuitSQLServer.UseVisualStyleBackColor = true;
            this.BtnQuitSQLServer.Click += new System.EventHandler(this.BtnQuitSQLServer_Click);
            // 
            // OIMSBOConfig
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(404, 266);
            this.Controls.Add(this.BtnQuitSQLServer);
            this.Controls.Add(this.BtnSaveSQLServer);
            this.Controls.Add(this.BtnTestSQLServer);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "OIMSBOConfig";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "分店服务器连接参数设置";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button BtnTestSQLServer;
        private System.Windows.Forms.Button BtnSaveSQLServer;
        private System.Windows.Forms.Button BtnQuitSQLServer;
        private System.Windows.Forms.TextBox txtDatabaseUserPwd;
        private System.Windows.Forms.TextBox txtDatabaseUserName;
        private System.Windows.Forms.TextBox txtDatabaseName;
        private System.Windows.Forms.TextBox txtServerIpName;
        private System.Windows.Forms.Label labDatabaseUserName;
        private System.Windows.Forms.Label labDatabaseUserPwd;
        private System.Windows.Forms.Label labDatabaseName;
        private System.Windows.Forms.Label labServerIpName;
    }
}

