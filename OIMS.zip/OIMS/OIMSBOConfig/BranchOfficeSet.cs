﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.IO;
using System.Security.AccessControl;
using System.Data.SqlClient;

namespace OIMSBOConfig
{
    public partial class BranchOfficeSet : Form
    {
        public string ConnString = ConfigurationManager.AppSettings["ConnString"].ToString().Trim();
      

        public BranchOfficeSet()
        {
            InitializeComponent();
            this.txtConnString.Text = ConnString;
        }

        private void BtnSave_Click(object sender, EventArgs e)
        {
            try
            {

                Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
                config.AppSettings.Settings.Remove("ConnString");


                //MessageBox.Show(ConfigurationManager.AppSettings["ConnString"].ToString().Trim(), "");
                string ConnString = txtConnString.Text.Trim();

                config.AppSettings.Settings.Add("ConnString", ConnString);


                config.Save(ConfigurationSaveMode.Modified);
                string x = System.Windows.Forms.Application.ExecutablePath;
                String y = System.Windows.Forms.Application.StartupPath + "\\OIMSBOConfig.EXE";
                MessageBox.Show(x);
                MessageBox.Show(y);
                //config.Save();
                //分配权限
                //MessageBox.Show(config.FilePath.Replace(@"/OIMSBOConfig.exe.Config", ""));
                MessageBox.Show((ConfigurationManager.OpenExeConfiguration("\\Modify.exe.").ToString()));
               // ConfigurationManager.OpenExeConfiguration("C:\\Modify.exe.config");

               // addpathPower(config.FilePath.Replace(@"/OIMSBOConfig.exe.Config", ""), "Everyone", "FullControl");
               //addpathPower((ConfigurationManager.OpenExeConfiguration(@"/Modify.exe.").ToString()), "Everyone", "FullControl");


                //config.Save();
                ConfigurationManager.RefreshSection("appSettings");
                MessageBox.Show("你修改了配置文件需要重启程序！");
                //this.Close();
                //Application.Exit(); 

            }
            catch
            {
                MessageBox.Show("读写配置文件出错，请检查安装目录是否有读写权限。");
            }
        }

        /// <summary>
        /// 为创建的临时文件分配权限
        /// </summary>
        /// <param name="pathname"></param>
        /// <param name="username"></param>
        /// <param name="power"></param>
        /// <remarks>SKY 2007-8-6</remarks>
        public void AddpathPower(string pathname, string username, string power)
        {

            DirectoryInfo dirinfo = new DirectoryInfo(pathname);

            if ((dirinfo.Attributes & FileAttributes.ReadOnly) != 0)
            {
                dirinfo.Attributes = FileAttributes.Normal;
            }

            //取得访问控制列表
            DirectorySecurity dirsecurity = dirinfo.GetAccessControl();

            switch (power)
            {
                case "FullControl":
                    dirsecurity.AddAccessRule(new FileSystemAccessRule(username, FileSystemRights.FullControl, InheritanceFlags.ContainerInherit, PropagationFlags.InheritOnly, AccessControlType.Allow));
                    break;
                case "ReadOnly":
                    dirsecurity.AddAccessRule(new FileSystemAccessRule(username, FileSystemRights.Read, AccessControlType.Allow));
                    break;
                case "Write":
                    dirsecurity.AddAccessRule(new FileSystemAccessRule(username, FileSystemRights.Write, AccessControlType.Allow));
                    break;
                case "Modify":
                    dirsecurity.AddAccessRule(new FileSystemAccessRule(username, FileSystemRights.Modify, AccessControlType.Allow));
                    break;
            }
        }

        private void BtnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnTest_Click(object sender, EventArgs e)
        {
            SqlConnection _SqlConnection = new SqlConnection(this.txtConnString.Text.Trim());
            try
            {
                _SqlConnection.Open();
                MessageBox.Show("数据库连接成功！", "恭喜", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception)
            {
                MessageBox.Show("不能连接数据库，请重新设置！", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;

            }
            finally
            {
                _SqlConnection.Close();
            }
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            string FilePath = this.txtFilePath.Text.Trim();
            string LogPath = this.txtLogPath.Text.Trim();
            string BackupPath = this.txtBackupPath.Text.Trim();
            if (!Directory.Exists(FilePath))
            {
                Directory.CreateDirectory(FilePath);
            }

            if (!Directory.Exists(LogPath))
            {
                Directory.CreateDirectory(LogPath);
            }

            if (!Directory.Exists(BackupPath))
            {
                Directory.CreateDirectory(BackupPath);
            }

            MessageBox.Show("执行成功！", "提示");

        }
    }
}
