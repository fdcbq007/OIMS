﻿using Microsoft.Win32;
using OIMS_DAL;
using OIMS_HOSM_DAL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Management;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace OIMS_HOSM_DAL
{
    public class SJZDFL_Helper
    {
        private static string sPKey;
        private static string sFLBM;
        private static string sFLMC;
        private static string sFPKey;
        private static string sFFLBM;
        private static string sFFLMC;
        private static bool iSFQY;
        private static string sIPDZ;
        private static string sJSJ;
        private static string sMACDZ;
        private static string sXZRYYHID;
        private static string sXZRY;
        private static DateTime dXZSJ;
        private static string sBZ;
        private static string sBJRYYHID;
        private static string sBJRY;
        private static DateTime dBJSJ;
        private static string sBJIPDZ;
        private static string sBJJSJ;
        private static string sBJMACDZ;
        private static string sBJBZDZ;
        private static string sPYCZM;

        public static string SPKey { get => sPKey; set => sPKey = value; }
        public static string SFLBM { get => sFLBM; set => sFLBM = value; }
        public static string SFLMC { get => sFLMC; set => sFLMC = value; }
        public static string SFPKey { get => sFPKey; set => sFPKey = value; }
        public static string SFFLBM { get => sFFLBM; set => sFFLBM = value; }
        public static string SFFLMC { get => sFFLMC; set => sFFLMC = value; }
        public static bool ISFQY { get => iSFQY; set => iSFQY = value; }
        public static string SIPDZ { get => sIPDZ; set => sIPDZ = value; }
        public static string SJSJ { get => sJSJ; set => sJSJ = value; }
        public static string SMACDZ { get => sMACDZ; set => sMACDZ = value; }
        public static string SXZRYYHID { get => sXZRYYHID; set => sXZRYYHID = value; }
        public static string SXZRY { get => sXZRY; set => sXZRY = value; }
        public static DateTime DXZSJ { get => dXZSJ; set => dXZSJ = value; }
        public static string SBZ { get => sBZ; set => sBZ = value; }
        public static string SBJRYYHID { get => sBJRYYHID; set => sBJRYYHID = value; }
        public static string SBJRY { get => sBJRY; set => sBJRY = value; }
        public static DateTime DBJSJ { get => dBJSJ; set => dBJSJ = value; }
        public static string SBJIPDZ { get => sBJIPDZ; set => sBJIPDZ = value; }
        public static string SBJJSJ { get => sBJJSJ; set => sBJJSJ = value; }
        public static string SBJMACDZ { get => sBJMACDZ; set => sBJMACDZ = value; }
        public static string SBJBZDZ { get => sBJBZDZ; set => sBJBZDZ = value; }
        public static string SPYCZM { get => sPYCZM; set => sPYCZM = value; }
        public string SFLMC1 { get; set; }
        public string SFLBM1 { get; set; }
        
    }
}
