﻿using System;
using System.Data;
using System.Xml;
using System.Data.SqlClient;
using System.Collections;
using System.Configuration;
namespace OIMS_DAL
{
    /// <summary> 
    /// SqlServer数据访问帮助类 
    /// </summary> 
    public sealed class OIMS_FOM_Helper
    {
        private static string connString;

        //已经过李翔修改过的代码----------------------------------------------------------------------------------------------------------
        #region 数据库连接 
        /// <summary> 
        /// 一个有效的数据库连接字符串 
        /// </summary> 
        /// <returns></returns> 
        public static string GetConnString(string serverIpName, string databaseName, string databaseUserName, string databaseUserPwd)
        {
            connString = "server =" + serverIpName + ";" + "database=" + databaseName + ";" + "UID=" + databaseUserName + ";" + "password=" + databaseUserPwd;
            return connString;   
        }

        #region 数据库连接 
        /// <summary> 
        /// 一个有效的数据库连接字符串 
        /// </summary> 
        /// <returns></returns> 
        public static string GetConnString()
        {
            connString = ConfigurationManager.ConnectionStrings["ConnStringDZ"].ConnectionString;
            return connString;
        }

        //已经过李翔修改过的代码----------------------------------------------------------------------------------------------------------
        /// <summary> 
        /// 一个有效的数据库连接对象 
        /// </summary> 
        /// <returns></returns> 
        public static SqlConnection GetConnection(String connString1)
        {
            connString = connString1;
            SqlConnection Connection = new SqlConnection(connString);
            return Connection;
        }
        #endregion
        #endregion
    }
}