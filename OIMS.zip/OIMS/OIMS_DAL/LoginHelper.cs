﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS_DAL
{
    public class LoginHelper
    {
        public static int ShowSelect(string sqlString)
        {
            SqlConnection conn = OIMS_ConfigHelper.GetConnection(OIMS_ConfigHelper.GetConnString());
            SqlCommand cmd = new SqlCommand(sqlString, conn);
            conn.Open();
            int i = (int)cmd.ExecuteScalar();
            return i;
        }

        public static string ReturnUserName(string sqlString)
        {
            SqlConnection conn = OIMS_ConfigHelper.GetConnection(OIMS_ConfigHelper.GetConnString());
            SqlCommand cmd = new SqlCommand(sqlString, conn);
            conn.Open();
            string userName = (string)cmd.ExecuteScalar();
            return userName;
        }
    }
}
