﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OIMS_DAL
{
    public class LoginUserHelper
    {
        private static string loginUserId;
        private static string loginUserName;
        private static string loginUserDeaprtment;
        private static string loginComapny;

        public LoginUserHelper()
        {

        }

        public static string LoginUserId { get => loginUserId; set => loginUserId = value; }
        public static string LoginUserName { get => loginUserName; set => loginUserName = value; }
        public static string LoginUserDeaprtment { get => loginUserDeaprtment; set => loginUserDeaprtment = value; }
        public static string LoginComapny { get => loginComapny; set => loginComapny = value; }
    }
}
 