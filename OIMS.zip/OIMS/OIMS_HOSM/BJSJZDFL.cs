﻿using OIMS_BLL;
using OIMS_DAL;
using OIMS_HOSM_BLL;
using OIMS_HOSM_DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OIMS_HOSM
{
    public partial class BJSJZDFL : Form
    {
        public BJSJZDFL()
        {
            InitializeComponent();
            //自动在下拉下表中显示父分类名称
            //cmbFFLMC.DataSource = SJZD_BLL.GetAllSJZDFL();
            //.DisplayMember = "SFLMC1";
            //cmbFFLMC.ValueMember = "SFLBM1";
            txtFLBM.Text = SJZDFL_Helper.SFLBM;
            txtFLMC.Text = SJZDFL_Helper.SFLMC;
            txtFFLBM.Text = SJZDFL_Helper.SFFLBM;
            //MessageBox.Show(cmbFFLMC.DisplayMember);
            cmbFFLMC.Text = SJZDFL_Helper.SFFLMC;
            //MessageBox.Show(cmbFFLMC.Text);
            if (SJZDFL_Helper.ISFQY)
            {
                cmbSFQY.Text = "是";
            }
            else
            {
                cmbSFQY.Text = "否";
            }
            txtBJIPDZ.Text = HQJSJXGXX.GetDQIP();
            txtBJJSJ.Text = HQJSJXGXX.GetJSJ();
            txtBJMACDZ.Text = HQJSJXGXX.GetDQMACDZ();
            txtBJRY.Text = LoginUserHelper.LoginUserName;
            dtpBJSJ.Text = dtpBJSJ.Value.ToLocalTime().ToString();
        }

        public string message = "";
        string sFPKey;
        string sFFLBM;
        string sFFLMC;
        SqlConnection conn = OIMS_ConfigHelper.GetConnection(OIMS_ConfigHelper.GetConnString());

        private void TsrbBC_Click(object sender, EventArgs e)
        {
            string sFLBM = txtFLBM.Text.ToString();
            string sFLMC = txtFLMC.Text.ToString();

            //获取下拉框绑定的分类编码和分类名称
            //MessageBox.Show(cmbFFLMC.SelectedText.ToString());
            //MessageBox.Show(cmbFFLMC.SelectedValue.ToString());
            //判断选择的下拉框的内容
            if (cmbFFLMC.Text.Trim().Length == 0)
            {
                sFPKey = "";
                sFFLBM = "";
                sFFLMC = "";
            }
            else
            {
                sFPKey = SJZD_BLL.GetSPKey(txtFFLBM.Text);
                sFFLBM = txtFFLBM.Text;
                sFFLMC = txtFFLBM.Text;
            }

            bool iSFQY;
            if (cmbSFQY.Text.ToString() == "是")
            {
                iSFQY = true;
            }
            else
            {
                iSFQY = false;
            }
            string sPYCZM = HZZPY.GetSpellCode(sFLMC);
            string sBJIPDZ = txtBJIPDZ.Text.ToString();
            string sBJJSJ = txtBJJSJ.Text.ToString();
            string sBJMACDZ = txtBJMACDZ.Text.ToString();
            string sBJRYYHID = LoginUserHelper.LoginUserId;
            string sBJRY = txtBJRY.Text.ToString();
            DateTime dBJSJ  = dtpBJSJ.Value.ToLocalTime();
            string sBJBZ = txtBJBZ.Text.ToString();
            

            if (SJZD_BLL.IsValidataInputFLMC(sFLMC) == false)
            {
                MessageBox.Show("分类名称不能为空", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            }
            else
            {
                if (SJZD_BLL.IsValidataFLMC1(sFLMC, ref message))
                {
                    string cmdStr = "update SJZDFL set "
                    + "sFLMC='" + sFLMC
                    + "',iSFQY='" + iSFQY
                    + "',sBJIPDZ='" + sBJIPDZ
                    + "',sBJJSJ='" + sBJJSJ
                    + "',sBJMACDZ='" + sBJMACDZ
                    + "',sBJRY='" + sBJRY
                    + "',sBJRYYHID='" + sBJRYYHID
                    + "',dBJSJ='" + dBJSJ
                    + "',sBJBZ='" + sBJBZ
                    + "',sPYCZM='" + sPYCZM
                    + "' where sFLBM='" + sFLBM
                    + "'";
                    try
                    {
                        SqlCommand cmd = new SqlCommand(cmdStr, conn);

                        conn.Open();
                        int count = cmd.ExecuteNonQuery();
                        if (count > 0)
                        {
                            MessageBox.Show("修改成功！");
                        }

                        else
                        {
                            MessageBox.Show("修改失败！");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    finally
                    {
                        if (conn != null)
                        {
                            conn.Close();
                        }
                        tsrbBC.Enabled = false;
                    }
                }
                else
                {
                    string cmdStr = "update SJZDFL set "
                    + "sFLMC='" + sFLMC
                    + "',iSFQY='" + iSFQY
                    + "',sBJIPDZ='" + sBJIPDZ
                    + "',sBJJSJ='" + sBJJSJ
                    + "',sBJMACDZ='" + sBJMACDZ
                    + "',sBJRY='" + sBJRY
                    + "',sBJRYYHID='" + sBJRYYHID
                    + "',dBJSJ='" + dBJSJ
                    + "',sBJBZ='" + sBJBZ
                    + "',sPYCZM='" + sPYCZM
                    + "' where sFLBM='" + sFLBM
                    + "'";
                    try
                    {
                        SqlCommand cmd = new SqlCommand(cmdStr, conn);

                        conn.Open();
                        int count = cmd.ExecuteNonQuery();
                        if (count > 0)
                        {
                            MessageBox.Show("修改成功！");
                        }
                        else
                        {
                            MessageBox.Show("修改失败！");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    finally
                    {
                        if (conn != null)
                        {
                            conn.Close();
                        }
                        tsrbBC.Enabled = false;
                    }
                }
                
            }
        }

        private void TsrbTC_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void TxtFLMC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                cmbSFQY.Focus();
            }
        }

        private void CmbFFLMC_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbFFLMC.Text.Trim().Length == 0)
            {
                cmbSFQY.Focus();
            }
            else
            {
                txtFFLBM.Text = cmbFFLMC.SelectedValue.ToString();
                SJZDFL_Helper.SFFLMC = cmbFFLMC.Text;
                cmbSFQY.Focus();
            }
        }

        private void CmbSFQY_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtBJBZ.Focus();
            }
        }


    }
}
