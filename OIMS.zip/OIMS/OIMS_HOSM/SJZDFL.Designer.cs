﻿namespace OIMS_HOSM
{
    partial class SJZDFL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SJZDFL));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.tsrSJZDFL = new System.Windows.Forms.ToolStrip();
            this.tsrbXZ = new System.Windows.Forms.ToolStripButton();
            this.tsrbBJ = new System.Windows.Forms.ToolStripButton();
            this.tsrbTC = new System.Windows.Forms.ToolStripButton();
            this.tsrbCX = new System.Windows.Forms.ToolStripButton();
            this.tsrbSX = new System.Windows.Forms.ToolStripButton();
            this.dgvSJZDFL = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.rdoFLMC = new System.Windows.Forms.RadioButton();
            this.rdoFLBM = new System.Windows.Forms.RadioButton();
            this.txtKSCZFL = new System.Windows.Forms.TextBox();
            this.lblKSCZFL = new System.Windows.Forms.Label();
            this.cmbQYCX = new System.Windows.Forms.ComboBox();
            this.btnSJDC = new System.Windows.Forms.Button();
            this.ssrFLXS = new System.Windows.Forms.StatusStrip();
            this.ssrlT = new System.Windows.Forms.ToolStripStatusLabel();
            this.ssrlJ = new System.Windows.Forms.ToolStripStatusLabel();
            this.ssrlTJ = new System.Windows.Forms.ToolStripStatusLabel();
            this.dgtcFLBM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgtcFLMC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgtcFFLBM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgtcFFLMC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgtcPYCZM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgtcSFQY = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dgtcIPDZ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgtcJSJ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgtcMACDZ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgtcXZRY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgtcXZSJ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgtcBZ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tsrSJZDFL.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSJZDFL)).BeginInit();
            this.panel1.SuspendLayout();
            this.ssrFLXS.SuspendLayout();
            this.SuspendLayout();
            // 
            // tsrSJZDFL
            // 
            this.tsrSJZDFL.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsrbXZ,
            this.tsrbBJ,
            this.tsrbTC,
            this.tsrbCX,
            this.tsrbSX});
            this.tsrSJZDFL.Location = new System.Drawing.Point(0, 0);
            this.tsrSJZDFL.Name = "tsrSJZDFL";
            this.tsrSJZDFL.Size = new System.Drawing.Size(1079, 25);
            this.tsrSJZDFL.TabIndex = 5;
            this.tsrSJZDFL.Text = "数据字典分类菜单";
            // 
            // tsrbXZ
            // 
            this.tsrbXZ.Image = ((System.Drawing.Image)(resources.GetObject("tsrbXZ.Image")));
            this.tsrbXZ.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsrbXZ.Name = "tsrbXZ";
            this.tsrbXZ.Size = new System.Drawing.Size(52, 22);
            this.tsrbXZ.Text = "新增";
            this.tsrbXZ.Click += new System.EventHandler(this.TsrbXZ_Click);
            // 
            // tsrbBJ
            // 
            this.tsrbBJ.Image = ((System.Drawing.Image)(resources.GetObject("tsrbBJ.Image")));
            this.tsrbBJ.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsrbBJ.Name = "tsrbBJ";
            this.tsrbBJ.Size = new System.Drawing.Size(52, 22);
            this.tsrbBJ.Text = "编辑";
            this.tsrbBJ.Click += new System.EventHandler(this.TsrbBJ_Click);
            // 
            // tsrbTC
            // 
            this.tsrbTC.Image = ((System.Drawing.Image)(resources.GetObject("tsrbTC.Image")));
            this.tsrbTC.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsrbTC.Name = "tsrbTC";
            this.tsrbTC.Size = new System.Drawing.Size(52, 22);
            this.tsrbTC.Text = "退出";
            this.tsrbTC.Click += new System.EventHandler(this.TsrbTC_Click);
            // 
            // tsrbCX
            // 
            this.tsrbCX.Image = ((System.Drawing.Image)(resources.GetObject("tsrbCX.Image")));
            this.tsrbCX.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsrbCX.Name = "tsrbCX";
            this.tsrbCX.Size = new System.Drawing.Size(52, 22);
            this.tsrbCX.Text = "查询";
            this.tsrbCX.ToolTipText = "查询";
            this.tsrbCX.Click += new System.EventHandler(this.TsrbCX_Click);
            // 
            // tsrbSX
            // 
            this.tsrbSX.Image = ((System.Drawing.Image)(resources.GetObject("tsrbSX.Image")));
            this.tsrbSX.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsrbSX.Name = "tsrbSX";
            this.tsrbSX.Size = new System.Drawing.Size(52, 22);
            this.tsrbSX.Text = "刷新";
            this.tsrbSX.Click += new System.EventHandler(this.TsrbSX_Click);
            // 
            // dgvSJZDFL
            // 
            this.dgvSJZDFL.AllowUserToAddRows = false;
            this.dgvSJZDFL.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Red;
            this.dgvSJZDFL.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvSJZDFL.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dgvSJZDFL.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvSJZDFL.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgtcFLBM,
            this.dgtcFLMC,
            this.dgtcFFLBM,
            this.dgtcFFLMC,
            this.dgtcPYCZM,
            this.dgtcSFQY,
            this.dgtcIPDZ,
            this.dgtcJSJ,
            this.dgtcMACDZ,
            this.dgtcXZRY,
            this.dgtcXZSJ,
            this.dgtcBZ});
            this.dgvSJZDFL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvSJZDFL.GridColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.dgvSJZDFL.Location = new System.Drawing.Point(0, 55);
            this.dgvSJZDFL.Name = "dgvSJZDFL";
            this.dgvSJZDFL.ReadOnly = true;
            this.dgvSJZDFL.RowTemplate.Height = 23;
            this.dgvSJZDFL.Size = new System.Drawing.Size(1079, 716);
            this.dgvSJZDFL.TabIndex = 7;
            this.dgvSJZDFL.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvSJZDFL_CellClick);
            this.dgvSJZDFL.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.DgvSJZDFL_RowPostPaint);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.rdoFLMC);
            this.panel1.Controls.Add(this.rdoFLBM);
            this.panel1.Controls.Add(this.txtKSCZFL);
            this.panel1.Controls.Add(this.lblKSCZFL);
            this.panel1.Controls.Add(this.cmbQYCX);
            this.panel1.Controls.Add(this.btnSJDC);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 25);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1079, 30);
            this.panel1.TabIndex = 8;
            // 
            // rdoFLMC
            // 
            this.rdoFLMC.AutoSize = true;
            this.rdoFLMC.Location = new System.Drawing.Point(445, 7);
            this.rdoFLMC.Name = "rdoFLMC";
            this.rdoFLMC.Size = new System.Drawing.Size(71, 16);
            this.rdoFLMC.TabIndex = 14;
            this.rdoFLMC.Text = "分类名称";
            this.rdoFLMC.UseVisualStyleBackColor = true;
            // 
            // rdoFLBM
            // 
            this.rdoFLBM.AutoSize = true;
            this.rdoFLBM.Checked = true;
            this.rdoFLBM.Location = new System.Drawing.Point(368, 7);
            this.rdoFLBM.Name = "rdoFLBM";
            this.rdoFLBM.Size = new System.Drawing.Size(71, 16);
            this.rdoFLBM.TabIndex = 13;
            this.rdoFLBM.TabStop = true;
            this.rdoFLBM.Text = "分类编码";
            this.rdoFLBM.UseVisualStyleBackColor = true;
            // 
            // txtKSCZFL
            // 
            this.txtKSCZFL.Location = new System.Drawing.Point(230, 5);
            this.txtKSCZFL.Name = "txtKSCZFL";
            this.txtKSCZFL.Size = new System.Drawing.Size(132, 21);
            this.txtKSCZFL.TabIndex = 12;
            this.txtKSCZFL.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtKSCZFL_KeyPress);
            // 
            // lblKSCZFL
            // 
            this.lblKSCZFL.AutoSize = true;
            this.lblKSCZFL.Location = new System.Drawing.Point(146, 9);
            this.lblKSCZFL.Name = "lblKSCZFL";
            this.lblKSCZFL.Size = new System.Drawing.Size(89, 12);
            this.lblKSCZFL.TabIndex = 11;
            this.lblKSCZFL.Text = "快速查找分类：";
            // 
            // cmbQYCX
            // 
            this.cmbQYCX.FormattingEnabled = true;
            this.cmbQYCX.Items.AddRange(new object[] {
            "全部",
            "启用",
            "停用"});
            this.cmbQYCX.Location = new System.Drawing.Point(3, 5);
            this.cmbQYCX.Name = "cmbQYCX";
            this.cmbQYCX.Size = new System.Drawing.Size(121, 20);
            this.cmbQYCX.TabIndex = 10;
            this.cmbQYCX.SelectedIndexChanged += new System.EventHandler(this.CmbQYCX_SelectedIndexChanged);
            // 
            // btnSJDC
            // 
            this.btnSJDC.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnSJDC.Location = new System.Drawing.Point(1004, 0);
            this.btnSJDC.Name = "btnSJDC";
            this.btnSJDC.Size = new System.Drawing.Size(75, 30);
            this.btnSJDC.TabIndex = 9;
            this.btnSJDC.Text = "数据导出";
            this.btnSJDC.UseVisualStyleBackColor = true;
            this.btnSJDC.Click += new System.EventHandler(this.BtnSJDC_Click);
            // 
            // ssrFLXS
            // 
            this.ssrFLXS.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ssrlT,
            this.ssrlJ,
            this.ssrlTJ});
            this.ssrFLXS.Location = new System.Drawing.Point(0, 749);
            this.ssrFLXS.Name = "ssrFLXS";
            this.ssrFLXS.Size = new System.Drawing.Size(1079, 22);
            this.ssrFLXS.TabIndex = 9;
            this.ssrFLXS.Text = "数据字典分类统计";
            // 
            // ssrlT
            // 
            this.ssrlT.Name = "ssrlT";
            this.ssrlT.Size = new System.Drawing.Size(36, 17);
            this.ssrlT.Text = "  统  ";
            // 
            // ssrlJ
            // 
            this.ssrlJ.Name = "ssrlJ";
            this.ssrlJ.Size = new System.Drawing.Size(48, 17);
            this.ssrlJ.Text = "  计：  ";
            // 
            // ssrlTJ
            // 
            this.ssrlTJ.Name = "ssrlTJ";
            this.ssrlTJ.Size = new System.Drawing.Size(40, 17);
            this.ssrlTJ.Text = "ssrlTJ";
            // 
            // dgtcFLBM
            // 
            this.dgtcFLBM.DataPropertyName = "sFLBM";
            this.dgtcFLBM.HeaderText = "分类编码";
            this.dgtcFLBM.Name = "dgtcFLBM";
            this.dgtcFLBM.ReadOnly = true;
            this.dgtcFLBM.Width = 80;
            // 
            // dgtcFLMC
            // 
            this.dgtcFLMC.DataPropertyName = "sFLMC";
            this.dgtcFLMC.HeaderText = "分类名称";
            this.dgtcFLMC.Name = "dgtcFLMC";
            this.dgtcFLMC.ReadOnly = true;
            this.dgtcFLMC.Width = 80;
            // 
            // dgtcFFLBM
            // 
            this.dgtcFFLBM.DataPropertyName = "sFFLBM";
            this.dgtcFFLBM.HeaderText = "父分类编码";
            this.dgtcFFLBM.Name = "dgtcFFLBM";
            this.dgtcFFLBM.ReadOnly = true;
            this.dgtcFFLBM.Width = 90;
            // 
            // dgtcFFLMC
            // 
            this.dgtcFFLMC.DataPropertyName = "sFFLMC";
            this.dgtcFFLMC.HeaderText = "父分类名称";
            this.dgtcFFLMC.Name = "dgtcFFLMC";
            this.dgtcFFLMC.ReadOnly = true;
            // 
            // dgtcPYCZM
            // 
            this.dgtcPYCZM.DataPropertyName = "sPYCZM";
            this.dgtcPYCZM.HeaderText = "拼音查找码";
            this.dgtcPYCZM.Name = "dgtcPYCZM";
            this.dgtcPYCZM.ReadOnly = true;
            // 
            // dgtcSFQY
            // 
            this.dgtcSFQY.DataPropertyName = "iSFQY";
            this.dgtcSFQY.FalseValue = "";
            this.dgtcSFQY.HeaderText = "是否启用";
            this.dgtcSFQY.Name = "dgtcSFQY";
            this.dgtcSFQY.ReadOnly = true;
            this.dgtcSFQY.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dgtcSFQY.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.dgtcSFQY.Width = 80;
            // 
            // dgtcIPDZ
            // 
            this.dgtcIPDZ.DataPropertyName = "sIPDZ";
            this.dgtcIPDZ.HeaderText = "IP地址";
            this.dgtcIPDZ.Name = "dgtcIPDZ";
            this.dgtcIPDZ.ReadOnly = true;
            this.dgtcIPDZ.Width = 90;
            // 
            // dgtcJSJ
            // 
            this.dgtcJSJ.DataPropertyName = "sJSJ";
            this.dgtcJSJ.HeaderText = "计算机";
            this.dgtcJSJ.Name = "dgtcJSJ";
            this.dgtcJSJ.ReadOnly = true;
            this.dgtcJSJ.Width = 80;
            // 
            // dgtcMACDZ
            // 
            this.dgtcMACDZ.DataPropertyName = "sMACDZ";
            this.dgtcMACDZ.HeaderText = "MAC地址";
            this.dgtcMACDZ.Name = "dgtcMACDZ";
            this.dgtcMACDZ.ReadOnly = true;
            this.dgtcMACDZ.Width = 140;
            // 
            // dgtcXZRY
            // 
            this.dgtcXZRY.DataPropertyName = "sXZRY";
            this.dgtcXZRY.HeaderText = "新增人员";
            this.dgtcXZRY.Name = "dgtcXZRY";
            this.dgtcXZRY.ReadOnly = true;
            this.dgtcXZRY.Width = 80;
            // 
            // dgtcXZSJ
            // 
            this.dgtcXZSJ.DataPropertyName = "dXZSJ";
            this.dgtcXZSJ.HeaderText = "新增时间";
            this.dgtcXZSJ.Name = "dgtcXZSJ";
            this.dgtcXZSJ.ReadOnly = true;
            this.dgtcXZSJ.Width = 120;
            // 
            // dgtcBZ
            // 
            this.dgtcBZ.DataPropertyName = "sBZ";
            this.dgtcBZ.HeaderText = "备注";
            this.dgtcBZ.Name = "dgtcBZ";
            this.dgtcBZ.ReadOnly = true;
            // 
            // SJZDFL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1079, 771);
            this.Controls.Add(this.ssrFLXS);
            this.Controls.Add(this.dgvSJZDFL);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tsrSJZDFL);
            this.Name = "SJZDFL";
            this.Text = "数据字典分类";
            this.TopMost = true;
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.SJZDFL_Load);
            this.tsrSJZDFL.ResumeLayout(false);
            this.tsrSJZDFL.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvSJZDFL)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ssrFLXS.ResumeLayout(false);
            this.ssrFLXS.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ToolStrip tsrSJZDFL;
        private System.Windows.Forms.ToolStripButton tsrbXZ;
        private System.Windows.Forms.ToolStripButton tsrbBJ;
        private System.Windows.Forms.ToolStripButton tsrbTC;
        private System.Windows.Forms.DataGridView dgvSJZDFL;
        private System.Windows.Forms.ToolStripButton tsrbCX;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.ToolStripButton tsrbSX;
        private System.Windows.Forms.Button btnSJDC;
        private System.Windows.Forms.RadioButton rdoFLMC;
        private System.Windows.Forms.RadioButton rdoFLBM;
        private System.Windows.Forms.TextBox txtKSCZFL;
        private System.Windows.Forms.Label lblKSCZFL;
        private System.Windows.Forms.ComboBox cmbQYCX;
        private System.Windows.Forms.StatusStrip ssrFLXS;
        private System.Windows.Forms.ToolStripStatusLabel ssrlT;
        private System.Windows.Forms.ToolStripStatusLabel ssrlJ;
        private System.Windows.Forms.ToolStripStatusLabel ssrlTJ;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgtcFLBM;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgtcFLMC;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgtcFFLBM;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgtcFFLMC;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgtcPYCZM;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dgtcSFQY;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgtcIPDZ;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgtcJSJ;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgtcMACDZ;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgtcXZRY;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgtcXZSJ;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgtcBZ;
    }
}