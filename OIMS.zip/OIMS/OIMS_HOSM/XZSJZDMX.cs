﻿using OIMS_BLL;
using OIMS_DAL;
using OIMS_HOSM_BLL;
using OIMS_HOSM_DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OIMS_HOSM
{
    public partial class XZSJZDMX : Form
    {
        public XZSJZDMX()
        {
            InitializeComponent();
            //自动在下拉下表中显示父分类名称

            txtMXBM.Clear();
            txtMXMC.Clear();

            txtFLMC.Text = SJZDFL_Helper.SFLMC;
            txtFLBM.Text = SJZDFL_Helper.SFLBM;
            txtIPDZ.Text = HQJSJXGXX.GetDQIP();
            txtJSJ.Text = HQJSJXGXX.GetJSJ();
            txtMACDZ.Text = HQJSJXGXX.GetDQMACDZ();
            txtXZRY.Text = LoginUserHelper.LoginUserName;


            cmbSFQY.SelectedIndex = 0;
        }

        public string message = "";
        bool iSFQY;
        SqlConnection conn = OIMS_ConfigHelper.GetConnection(OIMS_ConfigHelper.GetConnString());

        private void TsrbXZ_Click(object sender, EventArgs e)
        {
            txtMXBM.Clear();
            txtMXMC.Clear();
            txtMXBM.Focus();
        }

        private void TsrbBC_Click(object sender, EventArgs e)
        {
            string sPKey = Guid.NewGuid().ToString();
            string sFLBM = txtFLBM.Text.ToString();
            string sBSM = SJZD_BLL.GetSBSM(sFLBM);
            string sMXBM = txtMXBM.Text.ToString();
            string sMXMC = txtMXMC.Text.ToString();

            //获取下拉框绑定的分类编码和分类名称
            //MessageBox.Show(cmbFFLMC.SelectedText.ToString());
            //MessageBox.Show(cmbFFLMC.SelectedValue.ToString());
            //判断选择的下拉框的内容
            string sFLPKey = SJZD_BLL.GetSPKey(sFLBM);
            string sFLMC = txtFLMC.Text.ToString();
            string sIPDZ = txtIPDZ.Text.ToString();
            string sJSJ = txtJSJ.Text.ToString();
            string sMACDZ = txtMACDZ.Text.ToString();
            string sXZRYYHID = LoginUserHelper.LoginUserId;
            string sXZRY = txtXZRY.Text.ToString();
            DateTime dXZSJ  = dtpXZSJ.Value.ToLocalTime();
            string sBZ = txtBZ.Text.ToString();
            string sPYCZM = HZZPY.GetSpellCode(sMXMC);

            if (SJZD_BLL.IsValidataInputFLBM(sMXBM) == false)
            {
                MessageBox.Show("明细编码不能为空", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            }
            else if (SJZD_BLL.IsValidataInputFLMC(sMXMC) == false)
            {
                MessageBox.Show("明细名称不能为空", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            }
            else
            {
                string cmdStr = "insert into SJZDMX(sPKey,sBSM,sMXBM,sMXMC,sPYCZM,sFLPKey,sFLBM,sFLMC,iSFQY,sIPDZ,sJSJ,sMACDZ,sXZRY,sXZRYYHID,dXZSJ,sBZ) " +
                            "values('" + sPKey +
                            "','" + sBSM +
                            "','" + sMXBM +
                            "','" + sMXMC +
                            "','" + sPYCZM +
                            "','" + sFLPKey +
                            "','" + sFLBM +
                            "','" + sFLMC +
                            "','" + iSFQY +
                            "','" + sIPDZ +
                            "','" + sJSJ +
                            "','" + sMACDZ +
                            "','" + sXZRY +
                            "','" + sXZRYYHID +
                            "','" + dXZSJ +
                            "','" + sBZ +
                            "')";
                SqlConnection conn = OIMS_ConfigHelper.GetConnection(OIMS_ConfigHelper.GetConnString());
                SqlCommand sqlcmd = new SqlCommand(cmdStr, conn);
                conn.Open();

                int count = sqlcmd.ExecuteNonQuery();
                if (count > 0)
                {
                    MessageBox.Show("添加成功");
                }
                else
                {
                    MessageBox.Show("添加失败");
                }
                conn.Close();
                //请空已录入的数据
                txtMXBM.Focus();
                txtMXBM.Clear();
                txtMXMC.Clear();
            }
        }

        private void TsrbTC_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void TxtFLBM_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtMXMC.Focus();
            }
        }

        private void TxtFLMC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {

                txtFLMC.Focus();
                
            }
        }
        private void CmbFFLMC_KeyPress(object sender, KeyPressEventArgs e)

        {
            if (e.KeyChar == '\r')
            {
                if (txtFLMC.Text.Trim().Length == 0)
                {
                    cmbSFQY.Focus();
                }
                else
                {
                    //MessageBox.Show(cmbFFLMC.SelectedItem.ToString());
                    //MessageBox.Show(cmbFFLMC.SelectedValue.ToString());
                    //MessageBox.Show(cmbFFLMC.SelectedText.ToString());
                    //sFFLMC = cmbFFLMC.SelectedText.ToString();
                    txtFLBM.Text = txtFLMC.Text.ToString();
                    cmbSFQY.Focus();
                }     
            }
        }

        private void CmbSFQY_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == '\r')
            {
                txtBZ.Focus();
            }
        }

        private void CmbSFQY_SelectedIndexChanged(object sender, EventArgs e)
        {
            //获取下拉数据的项目名称
            if (cmbSFQY.SelectedItem.ToString() == "是")
            {
                iSFQY = true;
            }
            else
            {
                iSFQY = false;
            }
        }

        private void TsrbTC_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CmbFFLMC_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (txtFLMC.Text.Trim().Length == 0)
            {
                cmbSFQY.Focus();
            }
            else
            {
                SJZDFL_Helper.SFFLMC = txtFLMC.Text;
                txtFLBM.Text = txtFLMC.Text.ToString();
                cmbSFQY.Focus();
            }
        }
    }
}
