﻿using OIMS_DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OIMS_HOSM
{
    public partial class WY_ZYHZ : Form
    {
        //string connString = "server =" + "." + ";" + "database=" + "MainDataBase" + ";" + "UID=" + "sa" + ";" + "password=" + "a1234567890";
        DataSet ds = new DataSet(); //定义一个数据集

        public WY_ZYHZ()
        {
            InitializeComponent();
            //datagvWYZYHZ.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        }

        public void DisplayWYZYHZ()
        {
            string connString = ConfigurationManager.AppSettings["ConnectionStringWY"].ToString();
            //dataSet.Tables["BuyDetialTemp"].Clear();
            string sql = "select top 5000 * from V_WY_ZYHZ";    //SQL语句
            SqlDataAdapter dataAdapter = new SqlDataAdapter(sql, OIMS_ConfigHelper.GetConnection(connString));   //定义一个dataAdapter
            dataAdapter.Fill(ds, "V_WY_ZYHZ");   //填充数据集
            datagvWYZYHZ.DataSource = ds.Tables[0];  //填充数据进控件
        }

        private void WY_ZYHZ_Load(object sender, EventArgs e)
        {
            this.DisplayWYZYHZ();
        }

        private void DatagvWYZYHZ_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void DatagvWYZYHZ_RowStateChanged(object sender, DataGridViewRowStateChangedEventArgs e)
        {
            ////显示在HeaderCell上
            //for (int i = 0; i < this.datagvWYZYHZ.Rows.Count; i++)
            //{
            //    DataGridViewRow r = this.datagvWYZYHZ.Rows[i];
            //    r.HeaderCell.Value = string.Format("{0}", i + 1);
            //}
            //this.datagvWYZYHZ.Refresh();

            //e.Row.HeaderCell.Value = string.Format("{0}", e.Row.Index + 1);

        }

        private void DatagvWYZYHZ_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            var grid = sender as DataGridView;
            var rowIdx = (e.RowIndex + 1).ToString();

            var centerFormat = new StringFormat()
            {
                // right alignment might actually make more sense for numbers
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };

            var headerBounds = new Rectangle(e.RowBounds.Left, e.RowBounds.Top, grid.RowHeadersWidth, e.RowBounds.Height);
            e.Graphics.DrawString(rowIdx, this.Font, SystemBrushes.ControlText, headerBounds, centerFormat);
        }
    }
}
