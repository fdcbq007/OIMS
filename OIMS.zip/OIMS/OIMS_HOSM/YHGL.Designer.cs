﻿namespace OIMS_HOSM
{
    partial class YHGL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnXGYH = new System.Windows.Forms.Button();
            this.labSearchUser = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnBCYH = new System.Windows.Forms.Button();
            this.btnFH = new System.Windows.Forms.Button();
            this.btnCXYH = new System.Windows.Forms.Button();
            this.tabYHMX = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dtpGYRQ = new System.Windows.Forms.DateTimePicker();
            this.cmbZW = new System.Windows.Forms.ComboBox();
            this.dtpCJSJ = new System.Windows.Forms.DateTimePicker();
            this.labCJSJ = new System.Windows.Forms.Label();
            this.txtJSJ = new System.Windows.Forms.TextBox();
            this.labJSJ = new System.Windows.Forms.Label();
            this.rdoQSSBBZ = new System.Windows.Forms.RadioButton();
            this.cmbQSKB = new System.Windows.Forms.ComboBox();
            this.cmbQSRLLX = new System.Windows.Forms.ComboBox();
            this.labQSRLLX = new System.Windows.Forms.Label();
            this.labQSKB = new System.Windows.Forms.Label();
            this.cmbGYLX = new System.Windows.Forms.ComboBox();
            this.labGYLX = new System.Windows.Forms.Label();
            this.cmbBM = new System.Windows.Forms.ComboBox();
            this.cmbGS = new System.Windows.Forms.ComboBox();
            this.txtBZ1 = new System.Windows.Forms.TextBox();
            this.labBZ1 = new System.Windows.Forms.Label();
            this.txtMACDZ = new System.Windows.Forms.TextBox();
            this.txtIP = new System.Windows.Forms.TextBox();
            this.labIP = new System.Windows.Forms.Label();
            this.labZW = new System.Windows.Forms.Label();
            this.txtYWJS = new System.Windows.Forms.TextBox();
            this.labYWJS = new System.Windows.Forms.Label();
            this.txtYHJC = new System.Windows.Forms.TextBox();
            this.labYHJC = new System.Windows.Forms.Label();
            this.txtGH = new System.Windows.Forms.TextBox();
            this.labGYRQ = new System.Windows.Forms.Label();
            this.labGS = new System.Windows.Forms.Label();
            this.labMACDZ = new System.Windows.Forms.Label();
            this.labBM = new System.Windows.Forms.Label();
            this.labGH = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmbXB = new System.Windows.Forms.ComboBox();
            this.cmbQX = new System.Windows.Forms.ComboBox();
            this.cmbCS = new System.Windows.Forms.ComboBox();
            this.cmbSF = new System.Windows.Forms.ComboBox();
            this.txtBZ = new System.Windows.Forms.TextBox();
            this.labBZ = new System.Windows.Forms.Label();
            this.txtYZBM = new System.Windows.Forms.TextBox();
            this.labYZBM = new System.Windows.Forms.Label();
            this.txtJZDZ = new System.Windows.Forms.TextBox();
            this.labJZDZ = new System.Windows.Forms.Label();
            this.txtWX = new System.Windows.Forms.TextBox();
            this.cmbZJLX = new System.Windows.Forms.ComboBox();
            this.txtNL = new System.Windows.Forms.TextBox();
            this.labNL = new System.Windows.Forms.Label();
            this.txtPYSZM = new System.Windows.Forms.TextBox();
            this.dtpSR = new System.Windows.Forms.DateTimePicker();
            this.labSR = new System.Windows.Forms.Label();
            this.labXB = new System.Windows.Forms.Label();
            this.labPYSZM = new System.Windows.Forms.Label();
            this.txtQQ = new System.Windows.Forms.TextBox();
            this.txtDZYX = new System.Windows.Forms.TextBox();
            this.txtYHID = new System.Windows.Forms.TextBox();
            this.labYHID = new System.Windows.Forms.Label();
            this.txtYHM = new System.Windows.Forms.TextBox();
            this.labZJLX = new System.Windows.Forms.Label();
            this.txtZJHM = new System.Windows.Forms.TextBox();
            this.txtSJH = new System.Windows.Forms.TextBox();
            this.labWX = new System.Windows.Forms.Label();
            this.labZJHM = new System.Windows.Forms.Label();
            this.labSF = new System.Windows.Forms.Label();
            this.labDZYX = new System.Windows.Forms.Label();
            this.labQX = new System.Windows.Forms.Label();
            this.labCS = new System.Windows.Forms.Label();
            this.labQQ = new System.Windows.Forms.Label();
            this.labYHM = new System.Windows.Forms.Label();
            this.labSJH = new System.Windows.Forms.Label();
            this.tabYHLB = new System.Windows.Forms.TabPage();
            this.dgvYHLB = new System.Windows.Forms.DataGridView();
            this.dgtcYHID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgtcYHM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgtcPYSZM = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgtcSR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dgtcNL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnTC = new System.Windows.Forms.Button();
            this.btnTJYH = new System.Windows.Forms.Button();
            this.tabYHGL = new System.Windows.Forms.TabControl();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tabYHMX.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabYHLB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvYHLB)).BeginInit();
            this.tabYHGL.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnXGYH
            // 
            this.btnXGYH.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnXGYH.Location = new System.Drawing.Point(417, 675);
            this.btnXGYH.Name = "btnXGYH";
            this.btnXGYH.Size = new System.Drawing.Size(75, 36);
            this.btnXGYH.TabIndex = 2;
            this.btnXGYH.Text = "修改用户";
            this.btnXGYH.UseVisualStyleBackColor = true;
            this.btnXGYH.Click += new System.EventHandler(this.BtnXGYH_Click);
            // 
            // labSearchUser
            // 
            this.labSearchUser.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labSearchUser.Location = new System.Drawing.Point(22, 683);
            this.labSearchUser.Name = "labSearchUser";
            this.labSearchUser.Size = new System.Drawing.Size(75, 21);
            this.labSearchUser.TabIndex = 3;
            this.labSearchUser.Text = "搜索用户:";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.textBox1.Location = new System.Drawing.Point(112, 682);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(104, 23);
            this.textBox1.TabIndex = 4;
            // 
            // btnBCYH
            // 
            this.btnBCYH.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnBCYH.Location = new System.Drawing.Point(517, 675);
            this.btnBCYH.Name = "btnBCYH";
            this.btnBCYH.Size = new System.Drawing.Size(75, 36);
            this.btnBCYH.TabIndex = 5;
            this.btnBCYH.Text = "保存用户";
            this.btnBCYH.UseVisualStyleBackColor = true;
            this.btnBCYH.Click += new System.EventHandler(this.BtnBCYH_Click);
            // 
            // btnFH
            // 
            this.btnFH.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnFH.Location = new System.Drawing.Point(613, 675);
            this.btnFH.Name = "btnFH";
            this.btnFH.Size = new System.Drawing.Size(75, 36);
            this.btnFH.TabIndex = 6;
            this.btnFH.Text = "返回";
            this.btnFH.UseVisualStyleBackColor = true;
            this.btnFH.Click += new System.EventHandler(this.BtnFH_Click);
            // 
            // btnCXYH
            // 
            this.btnCXYH.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnCXYH.Location = new System.Drawing.Point(222, 675);
            this.btnCXYH.Name = "btnCXYH";
            this.btnCXYH.Size = new System.Drawing.Size(75, 36);
            this.btnCXYH.TabIndex = 7;
            this.btnCXYH.Text = "查询用户";
            this.btnCXYH.UseVisualStyleBackColor = true;
            this.btnCXYH.Click += new System.EventHandler(this.BtnCXYH_Click);
            // 
            // tabYHMX
            // 
            this.tabYHMX.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.tabYHMX.Controls.Add(this.groupBox2);
            this.tabYHMX.Controls.Add(this.groupBox1);
            this.tabYHMX.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.tabYHMX.Location = new System.Drawing.Point(4, 26);
            this.tabYHMX.Name = "tabYHMX";
            this.tabYHMX.Padding = new System.Windows.Forms.Padding(3);
            this.tabYHMX.Size = new System.Drawing.Size(853, 639);
            this.tabYHMX.TabIndex = 1;
            this.tabYHMX.Text = "用户明细";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.groupBox2.Controls.Add(this.dtpGYRQ);
            this.groupBox2.Controls.Add(this.cmbZW);
            this.groupBox2.Controls.Add(this.dtpCJSJ);
            this.groupBox2.Controls.Add(this.labCJSJ);
            this.groupBox2.Controls.Add(this.txtJSJ);
            this.groupBox2.Controls.Add(this.labJSJ);
            this.groupBox2.Controls.Add(this.rdoQSSBBZ);
            this.groupBox2.Controls.Add(this.cmbQSKB);
            this.groupBox2.Controls.Add(this.cmbQSRLLX);
            this.groupBox2.Controls.Add(this.labQSRLLX);
            this.groupBox2.Controls.Add(this.labQSKB);
            this.groupBox2.Controls.Add(this.cmbGYLX);
            this.groupBox2.Controls.Add(this.labGYLX);
            this.groupBox2.Controls.Add(this.cmbBM);
            this.groupBox2.Controls.Add(this.cmbGS);
            this.groupBox2.Controls.Add(this.txtBZ1);
            this.groupBox2.Controls.Add(this.labBZ1);
            this.groupBox2.Controls.Add(this.txtMACDZ);
            this.groupBox2.Controls.Add(this.txtIP);
            this.groupBox2.Controls.Add(this.labIP);
            this.groupBox2.Controls.Add(this.labZW);
            this.groupBox2.Controls.Add(this.txtYWJS);
            this.groupBox2.Controls.Add(this.labYWJS);
            this.groupBox2.Controls.Add(this.txtYHJC);
            this.groupBox2.Controls.Add(this.labYHJC);
            this.groupBox2.Controls.Add(this.txtGH);
            this.groupBox2.Controls.Add(this.labGYRQ);
            this.groupBox2.Controls.Add(this.labGS);
            this.groupBox2.Controls.Add(this.labMACDZ);
            this.groupBox2.Controls.Add(this.labBM);
            this.groupBox2.Controls.Add(this.labGH);
            this.groupBox2.Location = new System.Drawing.Point(20, 351);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(809, 269);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "员工属性";
            // 
            // dtpGYRQ
            // 
            this.dtpGYRQ.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.dtpGYRQ.Location = new System.Drawing.Point(383, 108);
            this.dtpGYRQ.Name = "dtpGYRQ";
            this.dtpGYRQ.Size = new System.Drawing.Size(142, 26);
            this.dtpGYRQ.TabIndex = 108;
            this.dtpGYRQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DtpGYRQ_KeyPress);
            // 
            // cmbZW
            // 
            this.cmbZW.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmbZW.FormattingEnabled = true;
            this.cmbZW.Location = new System.Drawing.Point(637, 72);
            this.cmbZW.Name = "cmbZW";
            this.cmbZW.Size = new System.Drawing.Size(142, 24);
            this.cmbZW.TabIndex = 107;
            this.cmbZW.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CmbZW_KeyPress);
            // 
            // dtpCJSJ
            // 
            this.dtpCJSJ.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.dtpCJSJ.Location = new System.Drawing.Point(636, 107);
            this.dtpCJSJ.Name = "dtpCJSJ";
            this.dtpCJSJ.Size = new System.Drawing.Size(142, 26);
            this.dtpCJSJ.TabIndex = 27;
            this.dtpCJSJ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DtpCJSJ_KeyPress);
            // 
            // labCJSJ
            // 
            this.labCJSJ.AutoSize = true;
            this.labCJSJ.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labCJSJ.Location = new System.Drawing.Point(559, 112);
            this.labCJSJ.Name = "labCJSJ";
            this.labCJSJ.Size = new System.Drawing.Size(88, 16);
            this.labCJSJ.TabIndex = 106;
            this.labCJSJ.Text = "创建时间：";
            // 
            // txtJSJ
            // 
            this.txtJSJ.Enabled = false;
            this.txtJSJ.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtJSJ.Location = new System.Drawing.Point(383, 180);
            this.txtJSJ.Name = "txtJSJ";
            this.txtJSJ.Size = new System.Drawing.Size(142, 26);
            this.txtJSJ.TabIndex = 32;
            // 
            // labJSJ
            // 
            this.labJSJ.AutoSize = true;
            this.labJSJ.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labJSJ.Location = new System.Drawing.Point(321, 185);
            this.labJSJ.Name = "labJSJ";
            this.labJSJ.Size = new System.Drawing.Size(72, 16);
            this.labJSJ.TabIndex = 105;
            this.labJSJ.Text = "计算机：";
            // 
            // rdoQSSBBZ
            // 
            this.rdoQSSBBZ.AutoSize = true;
            this.rdoQSSBBZ.Location = new System.Drawing.Point(618, 146);
            this.rdoQSSBBZ.Name = "rdoQSSBBZ";
            this.rdoQSSBBZ.Size = new System.Drawing.Size(122, 20);
            this.rdoQSSBBZ.TabIndex = 30;
            this.rdoQSSBBZ.TabStop = true;
            this.rdoQSSBBZ.Text = "缺省上班标志";
            this.rdoQSSBBZ.UseVisualStyleBackColor = true;
            this.rdoQSSBBZ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.RdoQSSBBZ_KeyPress);
            // 
            // cmbQSKB
            // 
            this.cmbQSKB.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmbQSKB.FormattingEnabled = true;
            this.cmbQSKB.Location = new System.Drawing.Point(383, 144);
            this.cmbQSKB.Name = "cmbQSKB";
            this.cmbQSKB.Size = new System.Drawing.Size(142, 24);
            this.cmbQSKB.TabIndex = 29;
            this.cmbQSKB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CmbQSKB_KeyPress);
            // 
            // cmbQSRLLX
            // 
            this.cmbQSRLLX.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmbQSRLLX.FormattingEnabled = true;
            this.cmbQSRLLX.Location = new System.Drawing.Point(135, 144);
            this.cmbQSRLLX.Name = "cmbQSRLLX";
            this.cmbQSRLLX.Size = new System.Drawing.Size(142, 24);
            this.cmbQSRLLX.TabIndex = 28;
            this.cmbQSRLLX.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CmbQSRLLX_KeyPress);
            // 
            // labQSRLLX
            // 
            this.labQSRLLX.AutoSize = true;
            this.labQSRLLX.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labQSRLLX.Location = new System.Drawing.Point(25, 148);
            this.labQSRLLX.Name = "labQSRLLX";
            this.labQSRLLX.Size = new System.Drawing.Size(120, 16);
            this.labQSRLLX.TabIndex = 99;
            this.labQSRLLX.Text = "缺省日历类型：";
            // 
            // labQSKB
            // 
            this.labQSKB.AutoSize = true;
            this.labQSKB.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labQSKB.Location = new System.Drawing.Point(305, 148);
            this.labQSKB.Name = "labQSKB";
            this.labQSKB.Size = new System.Drawing.Size(88, 16);
            this.labQSKB.TabIndex = 100;
            this.labQSKB.Text = "缺省科别：";
            // 
            // cmbGYLX
            // 
            this.cmbGYLX.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmbGYLX.FormattingEnabled = true;
            this.cmbGYLX.Location = new System.Drawing.Point(135, 108);
            this.cmbGYLX.Name = "cmbGYLX";
            this.cmbGYLX.Size = new System.Drawing.Size(142, 24);
            this.cmbGYLX.TabIndex = 25;
            this.cmbGYLX.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CmbGYLX_KeyPress);
            // 
            // labGYLX
            // 
            this.labGYLX.AutoSize = true;
            this.labGYLX.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labGYLX.Location = new System.Drawing.Point(57, 112);
            this.labGYLX.Name = "labGYLX";
            this.labGYLX.Size = new System.Drawing.Size(88, 16);
            this.labGYLX.TabIndex = 97;
            this.labGYLX.Text = "雇佣类型：";
            // 
            // cmbBM
            // 
            this.cmbBM.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmbBM.FormattingEnabled = true;
            this.cmbBM.Location = new System.Drawing.Point(383, 72);
            this.cmbBM.Name = "cmbBM";
            this.cmbBM.Size = new System.Drawing.Size(142, 24);
            this.cmbBM.TabIndex = 23;
            this.cmbBM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CmbBM_KeyPress);
            // 
            // cmbGS
            // 
            this.cmbGS.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmbGS.FormattingEnabled = true;
            this.cmbGS.Location = new System.Drawing.Point(135, 72);
            this.cmbGS.Name = "cmbGS";
            this.cmbGS.Size = new System.Drawing.Size(142, 24);
            this.cmbGS.TabIndex = 22;
            this.cmbGS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CmbGS_KeyPress);
            // 
            // txtBZ1
            // 
            this.txtBZ1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtBZ1.Location = new System.Drawing.Point(135, 217);
            this.txtBZ1.Name = "txtBZ1";
            this.txtBZ1.Size = new System.Drawing.Size(644, 26);
            this.txtBZ1.TabIndex = 34;
            // 
            // labBZ1
            // 
            this.labBZ1.AutoSize = true;
            this.labBZ1.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labBZ1.Location = new System.Drawing.Point(88, 222);
            this.labBZ1.Name = "labBZ1";
            this.labBZ1.Size = new System.Drawing.Size(56, 16);
            this.labBZ1.TabIndex = 93;
            this.labBZ1.Text = "备注：";
            // 
            // txtMACDZ
            // 
            this.txtMACDZ.Enabled = false;
            this.txtMACDZ.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtMACDZ.Location = new System.Drawing.Point(637, 180);
            this.txtMACDZ.Name = "txtMACDZ";
            this.txtMACDZ.Size = new System.Drawing.Size(142, 26);
            this.txtMACDZ.TabIndex = 33;
            // 
            // txtIP
            // 
            this.txtIP.Enabled = false;
            this.txtIP.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtIP.Location = new System.Drawing.Point(135, 180);
            this.txtIP.Name = "txtIP";
            this.txtIP.Size = new System.Drawing.Size(142, 26);
            this.txtIP.TabIndex = 31;
            // 
            // labIP
            // 
            this.labIP.AutoSize = true;
            this.labIP.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labIP.Location = new System.Drawing.Point(104, 185);
            this.labIP.Name = "labIP";
            this.labIP.Size = new System.Drawing.Size(40, 16);
            this.labIP.TabIndex = 89;
            this.labIP.Text = "IP：";
            // 
            // labZW
            // 
            this.labZW.AutoSize = true;
            this.labZW.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labZW.Location = new System.Drawing.Point(591, 76);
            this.labZW.Name = "labZW";
            this.labZW.Size = new System.Drawing.Size(56, 16);
            this.labZW.TabIndex = 80;
            this.labZW.Text = "职位：";
            // 
            // txtYWJS
            // 
            this.txtYWJS.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtYWJS.Location = new System.Drawing.Point(637, 34);
            this.txtYWJS.Name = "txtYWJS";
            this.txtYWJS.Size = new System.Drawing.Size(142, 26);
            this.txtYWJS.TabIndex = 21;
            this.txtYWJS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtYWJS_KeyPress);
            // 
            // labYWJS
            // 
            this.labYWJS.AutoSize = true;
            this.labYWJS.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.labYWJS.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labYWJS.Location = new System.Drawing.Point(559, 39);
            this.labYWJS.Name = "labYWJS";
            this.labYWJS.Size = new System.Drawing.Size(88, 16);
            this.labYWJS.TabIndex = 72;
            this.labYWJS.Text = "业务角色：";
            // 
            // txtYHJC
            // 
            this.txtYHJC.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtYHJC.Location = new System.Drawing.Point(135, 34);
            this.txtYHJC.Name = "txtYHJC";
            this.txtYHJC.Size = new System.Drawing.Size(142, 26);
            this.txtYHJC.TabIndex = 19;
            this.txtYHJC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtYHJC_KeyPress);
            // 
            // labYHJC
            // 
            this.labYHJC.AutoSize = true;
            this.labYHJC.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labYHJC.Location = new System.Drawing.Point(56, 39);
            this.labYHJC.Name = "labYHJC";
            this.labYHJC.Size = new System.Drawing.Size(88, 16);
            this.labYHJC.TabIndex = 59;
            this.labYHJC.Text = "用户简称：";
            // 
            // txtGH
            // 
            this.txtGH.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtGH.Location = new System.Drawing.Point(383, 34);
            this.txtGH.Name = "txtGH";
            this.txtGH.Size = new System.Drawing.Size(142, 26);
            this.txtGH.TabIndex = 20;
            this.txtGH.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtGH_KeyPress);
            // 
            // labGYRQ
            // 
            this.labGYRQ.AutoSize = true;
            this.labGYRQ.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labGYRQ.Location = new System.Drawing.Point(305, 112);
            this.labGYRQ.Name = "labGYRQ";
            this.labGYRQ.Size = new System.Drawing.Size(88, 16);
            this.labGYRQ.TabIndex = 63;
            this.labGYRQ.Text = "雇佣日期：";
            // 
            // labGS
            // 
            this.labGS.AutoSize = true;
            this.labGS.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labGS.Location = new System.Drawing.Point(88, 76);
            this.labGS.Name = "labGS";
            this.labGS.Size = new System.Drawing.Size(56, 16);
            this.labGS.TabIndex = 71;
            this.labGS.Text = "公司：";
            // 
            // labMACDZ
            // 
            this.labMACDZ.AutoSize = true;
            this.labMACDZ.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labMACDZ.Location = new System.Drawing.Point(567, 185);
            this.labMACDZ.Name = "labMACDZ";
            this.labMACDZ.Size = new System.Drawing.Size(80, 16);
            this.labMACDZ.TabIndex = 87;
            this.labMACDZ.Text = "MAC地址：";
            // 
            // labBM
            // 
            this.labBM.AutoSize = true;
            this.labBM.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labBM.Location = new System.Drawing.Point(337, 76);
            this.labBM.Name = "labBM";
            this.labBM.Size = new System.Drawing.Size(56, 16);
            this.labBM.TabIndex = 86;
            this.labBM.Text = "部门：";
            // 
            // labGH
            // 
            this.labGH.AutoSize = true;
            this.labGH.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labGH.Location = new System.Drawing.Point(337, 39);
            this.labGH.Name = "labGH";
            this.labGH.Size = new System.Drawing.Size(56, 16);
            this.labGH.TabIndex = 61;
            this.labGH.Text = "工号：";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.groupBox1.Controls.Add(this.cmbXB);
            this.groupBox1.Controls.Add(this.cmbQX);
            this.groupBox1.Controls.Add(this.cmbCS);
            this.groupBox1.Controls.Add(this.cmbSF);
            this.groupBox1.Controls.Add(this.txtBZ);
            this.groupBox1.Controls.Add(this.labBZ);
            this.groupBox1.Controls.Add(this.txtYZBM);
            this.groupBox1.Controls.Add(this.labYZBM);
            this.groupBox1.Controls.Add(this.txtJZDZ);
            this.groupBox1.Controls.Add(this.labJZDZ);
            this.groupBox1.Controls.Add(this.txtWX);
            this.groupBox1.Controls.Add(this.cmbZJLX);
            this.groupBox1.Controls.Add(this.txtNL);
            this.groupBox1.Controls.Add(this.labNL);
            this.groupBox1.Controls.Add(this.txtPYSZM);
            this.groupBox1.Controls.Add(this.dtpSR);
            this.groupBox1.Controls.Add(this.labSR);
            this.groupBox1.Controls.Add(this.labXB);
            this.groupBox1.Controls.Add(this.labPYSZM);
            this.groupBox1.Controls.Add(this.txtQQ);
            this.groupBox1.Controls.Add(this.txtDZYX);
            this.groupBox1.Controls.Add(this.txtYHID);
            this.groupBox1.Controls.Add(this.labYHID);
            this.groupBox1.Controls.Add(this.txtYHM);
            this.groupBox1.Controls.Add(this.labZJLX);
            this.groupBox1.Controls.Add(this.txtZJHM);
            this.groupBox1.Controls.Add(this.txtSJH);
            this.groupBox1.Controls.Add(this.labWX);
            this.groupBox1.Controls.Add(this.labZJHM);
            this.groupBox1.Controls.Add(this.labSF);
            this.groupBox1.Controls.Add(this.labDZYX);
            this.groupBox1.Controls.Add(this.labQX);
            this.groupBox1.Controls.Add(this.labCS);
            this.groupBox1.Controls.Add(this.labQQ);
            this.groupBox1.Controls.Add(this.labYHM);
            this.groupBox1.Controls.Add(this.labSJH);
            this.groupBox1.Location = new System.Drawing.Point(20, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(809, 307);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "个人信息";
            // 
            // cmbXB
            // 
            this.cmbXB.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmbXB.FormattingEnabled = true;
            this.cmbXB.Items.AddRange(new object[] {
            "男",
            "女",
            "未知"});
            this.cmbXB.Location = new System.Drawing.Point(134, 69);
            this.cmbXB.Name = "cmbXB";
            this.cmbXB.Size = new System.Drawing.Size(142, 24);
            this.cmbXB.TabIndex = 56;
            this.cmbXB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CmbXB_KeyPress);
            // 
            // cmbQX
            // 
            this.cmbQX.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmbQX.FormattingEnabled = true;
            this.cmbQX.Location = new System.Drawing.Point(636, 181);
            this.cmbQX.Name = "cmbQX";
            this.cmbQX.Size = new System.Drawing.Size(142, 24);
            this.cmbQX.TabIndex = 15;
            this.cmbQX.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CmbQX_KeyPress);
            // 
            // cmbCS
            // 
            this.cmbCS.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmbCS.FormattingEnabled = true;
            this.cmbCS.Location = new System.Drawing.Point(383, 181);
            this.cmbCS.Name = "cmbCS";
            this.cmbCS.Size = new System.Drawing.Size(142, 24);
            this.cmbCS.TabIndex = 14;
            this.cmbCS.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CmbCS_KeyPress);
            // 
            // cmbSF
            // 
            this.cmbSF.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmbSF.FormattingEnabled = true;
            this.cmbSF.Location = new System.Drawing.Point(134, 181);
            this.cmbSF.Name = "cmbSF";
            this.cmbSF.Size = new System.Drawing.Size(142, 24);
            this.cmbSF.TabIndex = 13;
            this.cmbSF.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CmbSF_KeyPress);
            // 
            // txtBZ
            // 
            this.txtBZ.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtBZ.Location = new System.Drawing.Point(134, 254);
            this.txtBZ.Name = "txtBZ";
            this.txtBZ.Size = new System.Drawing.Size(644, 26);
            this.txtBZ.TabIndex = 18;
            this.txtBZ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBZ_KeyPress);
            // 
            // labBZ
            // 
            this.labBZ.AutoSize = true;
            this.labBZ.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labBZ.Location = new System.Drawing.Point(87, 259);
            this.labBZ.Name = "labBZ";
            this.labBZ.Size = new System.Drawing.Size(56, 16);
            this.labBZ.TabIndex = 55;
            this.labBZ.Text = "备注：";
            // 
            // txtYZBM
            // 
            this.txtYZBM.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtYZBM.Location = new System.Drawing.Point(636, 217);
            this.txtYZBM.Name = "txtYZBM";
            this.txtYZBM.Size = new System.Drawing.Size(142, 26);
            this.txtYZBM.TabIndex = 17;
            this.txtYZBM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtYZBM_KeyPress);
            // 
            // labYZBM
            // 
            this.labYZBM.AutoSize = true;
            this.labYZBM.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labYZBM.Location = new System.Drawing.Point(558, 222);
            this.labYZBM.Name = "labYZBM";
            this.labYZBM.Size = new System.Drawing.Size(88, 16);
            this.labYZBM.TabIndex = 52;
            this.labYZBM.Text = "邮政编码：";
            // 
            // txtJZDZ
            // 
            this.txtJZDZ.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtJZDZ.Location = new System.Drawing.Point(134, 217);
            this.txtJZDZ.Name = "txtJZDZ";
            this.txtJZDZ.Size = new System.Drawing.Size(391, 26);
            this.txtJZDZ.TabIndex = 16;
            this.txtJZDZ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtJZDZ_KeyPress);
            // 
            // labJZDZ
            // 
            this.labJZDZ.AutoSize = true;
            this.labJZDZ.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labJZDZ.Location = new System.Drawing.Point(55, 222);
            this.labJZDZ.Name = "labJZDZ";
            this.labJZDZ.Size = new System.Drawing.Size(88, 16);
            this.labJZDZ.TabIndex = 51;
            this.labJZDZ.Text = "居住地址：";
            // 
            // txtWX
            // 
            this.txtWX.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtWX.Location = new System.Drawing.Point(636, 143);
            this.txtWX.Name = "txtWX";
            this.txtWX.Size = new System.Drawing.Size(142, 26);
            this.txtWX.TabIndex = 12;
            this.txtWX.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtWX_KeyPress);
            // 
            // cmbZJLX
            // 
            this.cmbZJLX.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.cmbZJLX.FormattingEnabled = true;
            this.cmbZJLX.Location = new System.Drawing.Point(383, 107);
            this.cmbZJLX.Name = "cmbZJLX";
            this.cmbZJLX.Size = new System.Drawing.Size(142, 24);
            this.cmbZJLX.TabIndex = 8;
            this.cmbZJLX.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CmbZJLX_KeyPress);
            // 
            // txtNL
            // 
            this.txtNL.Enabled = false;
            this.txtNL.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtNL.Location = new System.Drawing.Point(636, 69);
            this.txtNL.Name = "txtNL";
            this.txtNL.Size = new System.Drawing.Size(142, 26);
            this.txtNL.TabIndex = 6;
            // 
            // labNL
            // 
            this.labNL.AutoSize = true;
            this.labNL.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labNL.Location = new System.Drawing.Point(590, 74);
            this.labNL.Name = "labNL";
            this.labNL.Size = new System.Drawing.Size(56, 16);
            this.labNL.TabIndex = 40;
            this.labNL.Text = "年龄：";
            // 
            // txtPYSZM
            // 
            this.txtPYSZM.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtPYSZM.Location = new System.Drawing.Point(636, 32);
            this.txtPYSZM.Name = "txtPYSZM";
            this.txtPYSZM.Size = new System.Drawing.Size(142, 26);
            this.txtPYSZM.TabIndex = 3;
            this.txtPYSZM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtPYSZM_KeyPress);
            // 
            // dtpSR
            // 
            this.dtpSR.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.dtpSR.Location = new System.Drawing.Point(383, 69);
            this.dtpSR.Name = "dtpSR";
            this.dtpSR.Size = new System.Drawing.Size(142, 26);
            this.dtpSR.TabIndex = 5;
            this.dtpSR.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DtpSR_KeyPress);
            // 
            // labSR
            // 
            this.labSR.AutoSize = true;
            this.labSR.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labSR.Location = new System.Drawing.Point(337, 74);
            this.labSR.Name = "labSR";
            this.labSR.Size = new System.Drawing.Size(56, 16);
            this.labSR.TabIndex = 38;
            this.labSR.Text = "生日：";
            // 
            // labXB
            // 
            this.labXB.AutoSize = true;
            this.labXB.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labXB.Location = new System.Drawing.Point(87, 74);
            this.labXB.Name = "labXB";
            this.labXB.Size = new System.Drawing.Size(56, 16);
            this.labXB.TabIndex = 34;
            this.labXB.Text = "性别：";
            // 
            // labPYSZM
            // 
            this.labPYSZM.AutoSize = true;
            this.labPYSZM.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.labPYSZM.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labPYSZM.Location = new System.Drawing.Point(542, 37);
            this.labPYSZM.Name = "labPYSZM";
            this.labPYSZM.Size = new System.Drawing.Size(104, 16);
            this.labPYSZM.TabIndex = 32;
            this.labPYSZM.Text = "拼音首字母：";
            // 
            // txtQQ
            // 
            this.txtQQ.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtQQ.Location = new System.Drawing.Point(383, 143);
            this.txtQQ.Name = "txtQQ";
            this.txtQQ.Size = new System.Drawing.Size(142, 26);
            this.txtQQ.TabIndex = 11;
            this.txtQQ.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtQQ_KeyPress);
            // 
            // txtDZYX
            // 
            this.txtDZYX.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtDZYX.Location = new System.Drawing.Point(134, 143);
            this.txtDZYX.Name = "txtDZYX";
            this.txtDZYX.Size = new System.Drawing.Size(142, 26);
            this.txtDZYX.TabIndex = 10;
            this.txtDZYX.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtDZYX_KeyPress);
            // 
            // txtYHID
            // 
            this.txtYHID.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtYHID.Location = new System.Drawing.Point(134, 32);
            this.txtYHID.Name = "txtYHID";
            this.txtYHID.Size = new System.Drawing.Size(142, 26);
            this.txtYHID.TabIndex = 1;
            this.txtYHID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtYHID_KeyPress);
            // 
            // labYHID
            // 
            this.labYHID.AutoSize = true;
            this.labYHID.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labYHID.Location = new System.Drawing.Point(71, 37);
            this.labYHID.Name = "labYHID";
            this.labYHID.Size = new System.Drawing.Size(72, 16);
            this.labYHID.TabIndex = 0;
            this.labYHID.Text = "用户ID：";
            // 
            // txtYHM
            // 
            this.txtYHM.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtYHM.Location = new System.Drawing.Point(383, 32);
            this.txtYHM.Name = "txtYHM";
            this.txtYHM.Size = new System.Drawing.Size(142, 26);
            this.txtYHM.TabIndex = 2;
            this.txtYHM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtYHM_KeyPress);
            // 
            // labZJLX
            // 
            this.labZJLX.AutoSize = true;
            this.labZJLX.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labZJLX.Location = new System.Drawing.Point(305, 111);
            this.labZJLX.Name = "labZJLX";
            this.labZJLX.Size = new System.Drawing.Size(88, 16);
            this.labZJLX.TabIndex = 6;
            this.labZJLX.Text = "证件类型：";
            // 
            // txtZJHM
            // 
            this.txtZJHM.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtZJHM.Location = new System.Drawing.Point(636, 106);
            this.txtZJHM.Name = "txtZJHM";
            this.txtZJHM.Size = new System.Drawing.Size(142, 26);
            this.txtZJHM.TabIndex = 9;
            this.txtZJHM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtZJHM_KeyPress);
            // 
            // txtSJH
            // 
            this.txtSJH.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txtSJH.Location = new System.Drawing.Point(134, 106);
            this.txtSJH.Name = "txtSJH";
            this.txtSJH.Size = new System.Drawing.Size(142, 26);
            this.txtSJH.TabIndex = 7;
            this.txtSJH.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtSJH_KeyPress);
            // 
            // labWX
            // 
            this.labWX.AutoSize = true;
            this.labWX.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labWX.Location = new System.Drawing.Point(590, 148);
            this.labWX.Name = "labWX";
            this.labWX.Size = new System.Drawing.Size(56, 16);
            this.labWX.TabIndex = 45;
            this.labWX.Text = "微信：";
            // 
            // labZJHM
            // 
            this.labZJHM.AutoSize = true;
            this.labZJHM.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labZJHM.Location = new System.Drawing.Point(558, 111);
            this.labZJHM.Name = "labZJHM";
            this.labZJHM.Size = new System.Drawing.Size(88, 16);
            this.labZJHM.TabIndex = 43;
            this.labZJHM.Text = "证件号码：";
            // 
            // labSF
            // 
            this.labSF.AutoSize = true;
            this.labSF.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labSF.Location = new System.Drawing.Point(87, 185);
            this.labSF.Name = "labSF";
            this.labSF.Size = new System.Drawing.Size(56, 16);
            this.labSF.TabIndex = 31;
            this.labSF.Text = "省份：";
            // 
            // labDZYX
            // 
            this.labDZYX.AutoSize = true;
            this.labDZYX.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labDZYX.Location = new System.Drawing.Point(55, 148);
            this.labDZYX.Name = "labDZYX";
            this.labDZYX.Size = new System.Drawing.Size(88, 16);
            this.labDZYX.TabIndex = 27;
            this.labDZYX.Text = "电子邮箱：";
            // 
            // labQX
            // 
            this.labQX.AutoSize = true;
            this.labQX.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labQX.Location = new System.Drawing.Point(590, 185);
            this.labQX.Name = "labQX";
            this.labQX.Size = new System.Drawing.Size(56, 16);
            this.labQX.TabIndex = 49;
            this.labQX.Text = "区县：";
            // 
            // labCS
            // 
            this.labCS.AutoSize = true;
            this.labCS.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labCS.Location = new System.Drawing.Point(337, 185);
            this.labCS.Name = "labCS";
            this.labCS.Size = new System.Drawing.Size(56, 16);
            this.labCS.TabIndex = 47;
            this.labCS.Text = "城市：";
            // 
            // labQQ
            // 
            this.labQQ.AutoSize = true;
            this.labQQ.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labQQ.Location = new System.Drawing.Point(353, 148);
            this.labQQ.Name = "labQQ";
            this.labQQ.Size = new System.Drawing.Size(40, 16);
            this.labQQ.TabIndex = 28;
            this.labQQ.Text = "QQ：";
            // 
            // labYHM
            // 
            this.labYHM.AutoSize = true;
            this.labYHM.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labYHM.Location = new System.Drawing.Point(321, 37);
            this.labYHM.Name = "labYHM";
            this.labYHM.Size = new System.Drawing.Size(72, 16);
            this.labYHM.TabIndex = 2;
            this.labYHM.Text = "用户名：";
            // 
            // labSJH
            // 
            this.labSJH.AutoSize = true;
            this.labSJH.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.labSJH.Location = new System.Drawing.Point(71, 111);
            this.labSJH.Name = "labSJH";
            this.labSJH.Size = new System.Drawing.Size(72, 16);
            this.labSJH.TabIndex = 13;
            this.labSJH.Text = "手机号：";
            // 
            // tabYHLB
            // 
            this.tabYHLB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.tabYHLB.Controls.Add(this.dgvYHLB);
            this.tabYHLB.Location = new System.Drawing.Point(4, 26);
            this.tabYHLB.Name = "tabYHLB";
            this.tabYHLB.Padding = new System.Windows.Forms.Padding(3);
            this.tabYHLB.Size = new System.Drawing.Size(853, 639);
            this.tabYHLB.TabIndex = 0;
            this.tabYHLB.Text = "用户列表";
            // 
            // dgvYHLB
            // 
            this.dgvYHLB.AllowUserToOrderColumns = true;
            this.dgvYHLB.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.dgvYHLB.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.dgvYHLB.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
            this.dgvYHLB.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvYHLB.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dgtcYHID,
            this.dgtcYHM,
            this.dgtcPYSZM,
            this.dgtcSR,
            this.dgtcNL});
            this.dgvYHLB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvYHLB.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.dgvYHLB.Location = new System.Drawing.Point(3, 3);
            this.dgvYHLB.Name = "dgvYHLB";
            this.dgvYHLB.RowTemplate.Height = 23;
            this.dgvYHLB.Size = new System.Drawing.Size(847, 633);
            this.dgvYHLB.TabIndex = 0;
            this.dgvYHLB.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvYHLB_CellDoubleClick);
            this.dgvYHLB.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.DatagvUserList_RowPostPaint);
            // 
            // dgtcYHID
            // 
            this.dgtcYHID.DataPropertyName = "sYHID";
            this.dgtcYHID.HeaderText = "用户ID";
            this.dgtcYHID.Name = "dgtcYHID";
            // 
            // dgtcYHM
            // 
            this.dgtcYHM.DataPropertyName = "sYHM";
            this.dgtcYHM.HeaderText = "用户名";
            this.dgtcYHM.Name = "dgtcYHM";
            // 
            // dgtcPYSZM
            // 
            this.dgtcPYSZM.DataPropertyName = "sPYSZM";
            this.dgtcPYSZM.HeaderText = "拼音首字母";
            this.dgtcPYSZM.Name = "dgtcPYSZM";
            // 
            // dgtcSR
            // 
            this.dgtcSR.DataPropertyName = "dSR";
            this.dgtcSR.HeaderText = "生日";
            this.dgtcSR.Name = "dgtcSR";
            // 
            // dgtcNL
            // 
            this.dgtcNL.DataPropertyName = "sNL";
            this.dgtcNL.HeaderText = "年龄";
            this.dgtcNL.Name = "dgtcNL";
            // 
            // btnTC
            // 
            this.btnTC.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnTC.Image = global::OIMS_HOSM.Properties.Resources.exit;
            this.btnTC.Location = new System.Drawing.Point(710, 675);
            this.btnTC.Name = "btnTC";
            this.btnTC.Size = new System.Drawing.Size(75, 36);
            this.btnTC.TabIndex = 8;
            this.btnTC.Text = "退出";
            this.btnTC.UseVisualStyleBackColor = true;
            this.btnTC.Click += new System.EventHandler(this.BtnTC_Click);
            // 
            // btnTJYH
            // 
            this.btnTJYH.Font = new System.Drawing.Font("宋体", 10.5F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btnTJYH.Image = global::OIMS_HOSM.Properties.Resources.add;
            this.btnTJYH.Location = new System.Drawing.Point(318, 675);
            this.btnTJYH.Name = "btnTJYH";
            this.btnTJYH.Size = new System.Drawing.Size(75, 36);
            this.btnTJYH.TabIndex = 1;
            this.btnTJYH.Text = "添加用户";
            this.btnTJYH.UseVisualStyleBackColor = true;
            this.btnTJYH.Click += new System.EventHandler(this.BtnTJYH_Click);
            // 
            // tabYHGL
            // 
            this.tabYHGL.Controls.Add(this.tabYHLB);
            this.tabYHGL.Controls.Add(this.tabYHMX);
            this.tabYHGL.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.tabYHGL.Location = new System.Drawing.Point(-3, 0);
            this.tabYHGL.Name = "tabYHGL";
            this.tabYHGL.SelectedIndex = 0;
            this.tabYHGL.Size = new System.Drawing.Size(861, 669);
            this.tabYHGL.TabIndex = 0;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 715);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(854, 22);
            this.statusStrip1.TabIndex = 1;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // YHGL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(854, 737);
            this.Controls.Add(this.btnTC);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.labSearchUser);
            this.Controls.Add(this.tabYHGL);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.btnXGYH);
            this.Controls.Add(this.btnTJYH);
            this.Controls.Add(this.btnFH);
            this.Controls.Add(this.btnCXYH);
            this.Controls.Add(this.btnBCYH);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "YHGL";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "用户管理";
            this.TopMost = true;
            this.tabYHMX.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabYHLB.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvYHLB)).EndInit();
            this.tabYHGL.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnTJYH;
        private System.Windows.Forms.Button btnXGYH;
        private System.Windows.Forms.Label labSearchUser;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnBCYH;
        private System.Windows.Forms.Button btnFH;
        private System.Windows.Forms.Button btnCXYH;
        private System.Windows.Forms.Button btnTC;
        private System.Windows.Forms.TabPage tabYHMX;
        private System.Windows.Forms.TabPage tabYHLB;
        private System.Windows.Forms.DataGridView dgvYHLB;
        private System.Windows.Forms.TabControl tabYHGL;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label labSF;
        private System.Windows.Forms.Label labQQ;
        private System.Windows.Forms.Label labDZYX;
        private System.Windows.Forms.TextBox txtQQ;
        private System.Windows.Forms.TextBox txtDZYX;
        private System.Windows.Forms.TextBox txtYHID;
        private System.Windows.Forms.Label labYHID;
        private System.Windows.Forms.Label labYHM;
        private System.Windows.Forms.TextBox txtYHM;
        private System.Windows.Forms.Label labZJLX;
        private System.Windows.Forms.Label labSJH;
        private System.Windows.Forms.TextBox txtZJHM;
        private System.Windows.Forms.TextBox txtSJH;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label labPYSZM;
        private System.Windows.Forms.TextBox txtPYSZM;
        private System.Windows.Forms.Label labXB;
        private System.Windows.Forms.Label labSR;
        private System.Windows.Forms.DateTimePicker dtpSR;
        private System.Windows.Forms.TextBox txtNL;
        private System.Windows.Forms.Label labNL;
        private System.Windows.Forms.Label labZJHM;
        private System.Windows.Forms.ComboBox cmbZJLX;
        private System.Windows.Forms.Label labWX;
        private System.Windows.Forms.TextBox txtWX;
        private System.Windows.Forms.Label labCS;
        private System.Windows.Forms.Label labQX;
        private System.Windows.Forms.TextBox txtJZDZ;
        private System.Windows.Forms.Label labJZDZ;
        private System.Windows.Forms.TextBox txtYZBM;
        private System.Windows.Forms.Label labYZBM;
        private System.Windows.Forms.TextBox txtBZ;
        private System.Windows.Forms.Label labBZ;
        private System.Windows.Forms.ComboBox cmbQX;
        private System.Windows.Forms.ComboBox cmbCS;
        private System.Windows.Forms.ComboBox cmbSF;
        private System.Windows.Forms.ComboBox cmbBM;
        private System.Windows.Forms.ComboBox cmbGS;
        private System.Windows.Forms.TextBox txtBZ1;
        private System.Windows.Forms.Label labBZ1;
        private System.Windows.Forms.TextBox txtMACDZ;
        private System.Windows.Forms.TextBox txtIP;
        private System.Windows.Forms.Label labIP;
        private System.Windows.Forms.Label labZW;
        private System.Windows.Forms.TextBox txtYWJS;
        private System.Windows.Forms.Label labYWJS;
        private System.Windows.Forms.TextBox txtYHJC;
        private System.Windows.Forms.Label labYHJC;
        private System.Windows.Forms.TextBox txtGH;
        private System.Windows.Forms.Label labGYRQ;
        private System.Windows.Forms.Label labGS;
        private System.Windows.Forms.Label labMACDZ;
        private System.Windows.Forms.Label labBM;
        private System.Windows.Forms.Label labGH;
        private System.Windows.Forms.ComboBox cmbGYLX;
        private System.Windows.Forms.Label labGYLX;
        private System.Windows.Forms.ComboBox cmbQSKB;
        private System.Windows.Forms.ComboBox cmbQSRLLX;
        private System.Windows.Forms.Label labQSRLLX;
        private System.Windows.Forms.Label labQSKB;
        private System.Windows.Forms.RadioButton rdoQSSBBZ;
        private System.Windows.Forms.TextBox txtJSJ;
        private System.Windows.Forms.Label labJSJ;
        private System.Windows.Forms.DateTimePicker dtpCJSJ;
        private System.Windows.Forms.Label labCJSJ;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgtcYHID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgtcYHM;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgtcPYSZM;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgtcSR;
        private System.Windows.Forms.DataGridViewTextBoxColumn dgtcNL;
        private System.Windows.Forms.ComboBox cmbXB;
        private System.Windows.Forms.ComboBox cmbZW;
        private System.Windows.Forms.DateTimePicker dtpGYRQ;
        private System.Windows.Forms.StatusStrip statusStrip1;
    }
}