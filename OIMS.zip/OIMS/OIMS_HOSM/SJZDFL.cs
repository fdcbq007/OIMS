﻿using OIMS_DAL;
using OIMS_HOSM_BLL;
using OIMS_HOSM_DAL;
using Sunisoft.IrisSkin;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using OIMS_BLL;

namespace OIMS_HOSM
{
    public partial class SJZDFL : Form
    {
        SqlConnection conn = OIMS_ConfigHelper.GetConnection(OIMS_ConfigHelper.GetConnString());
        DataSet ds = new DataSet();
        public SJZDFL()
        {
            InitializeComponent();
            dgvSJZDFL.AutoGenerateColumns = false;
            Display();
        }

        private void TsrbXZ_Click(object sender, EventArgs e)
        {
            XZSJZDFL xzsjzdfl = new XZSJZDFL();
            xzsjzdfl.ShowDialog();
        }

        private void TsrbBJ_Click(object sender, EventArgs e)
        {
            if (dgvSJZDFL.SelectedRows.Count > 0)
            {
                BJSJZDFL bjsjzdfl = new BJSJZDFL();
                bjsjzdfl.ShowDialog();
            }
            else
            {
                MessageBox.Show("您没有选中任何数据项，请选中后再操作。","提示",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
            
        }

        private void TsrbTC_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        SkinEngine se = new SkinEngine();
        private void TsrbCX_Click(object sender, EventArgs e)
        {
            if (txtKSCZFL.Text != "")
            {
                if (rdoFLBM.Checked)
                {
                    ds.Clear();
                    string strSql = "select sFLBM,sFLMC,sFFLBM,sFFLMC,iSFQY,sIPDZ,sJSJ,sMACDZ,sXZRY,dXZSJ,sBZ,sPYCZM " +
                "from SJZDFL where sFLBM like '%" + txtKSCZFL.Text.ToString().Trim() + "%' order by sFLBM";
                    SqlDataAdapter sda = new SqlDataAdapter(strSql, conn);
                    conn.Open();
                    sda.Fill(ds, "SJZDFL");
                    dgvSJZDFL.DataSource = ds.Tables["SJZDFL"];

                    ssrlTJ.Text = "共" + ds.Tables["SJZDFL"].Rows.Count.ToString() + "个分类";
                    try
                    {

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
                else
                {
                    ds.Clear();
                    string strSql = "select sFLBM,sFLMC,sFFLBM,sFFLMC,iSFQY,sIPDZ,sJSJ,sMACDZ,sXZRY,dXZSJ,sBZ,sPYCZM " +
                "from SJZDFL where sFLMC like '%" + txtKSCZFL.Text.ToString().Trim() + "%' order by sFLBM";
                    SqlDataAdapter sda = new SqlDataAdapter(strSql, conn);
                    conn.Open();
                    sda.Fill(ds, "SJZDFL");
                    dgvSJZDFL.DataSource = ds.Tables["SJZDFL"];

                    ssrlTJ.Text = "共" + ds.Tables["SJZDFL"].Rows.Count.ToString() + "个分类";
                    try
                    {

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
            else
            {
                ds.Clear();
                Display();
            }
        }

        public void Display()
        {
            string strSql = "select sFLBM,sFLMC,sFFLBM,sFFLMC,iSFQY,sIPDZ,sJSJ,sMACDZ,sXZRY,dXZSJ,sBZ,sPYCZM " +
                "from SJZDFL order by sFLBM";
            SqlDataAdapter sda = new SqlDataAdapter(strSql, conn);
            conn.Open();
            sda.Fill(ds, "SJZDFL");
            dgvSJZDFL.DataSource = ds.Tables["SJZDFL"];

            ssrlTJ.Text = "共" + ds.Tables["SJZDFL"].Rows.Count.ToString() + "个分类";
            try
            {

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
        }

        //设置编号
        private void DgvSJZDFL_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            var grid = sender as DataGridView;
            var rowIdx = (e.RowIndex + 1).ToString();

            var centerFormat = new StringFormat()
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };

            var headerBounds = new Rectangle(e.RowBounds.Left, e.RowBounds.Top, grid.RowHeadersWidth, e.RowBounds.Height);
            e.Graphics.DrawString(rowIdx, this.Font, SystemBrushes.ControlText, headerBounds, centerFormat);
        }

        private void TsrbSX_Click(object sender, EventArgs e)
        {
            ds.Clear();
            Display();
        }

        private void BtnSJDC_Click(object sender, EventArgs e)
        {   
            try
            {
                SJDC sjdc = new SJDC();
                sjdc.ExportDataGridview(dgvSJZDFL, true);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        //通过停用启用查询分类编码的数据
        private void CmbQYCX_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbQYCX.Text == "全部")
            {
                ds.Clear();
                Display();
            }
            else if (cmbQYCX.Text == "启用")
            {
                ds.Clear();
                string strSql = "select sFLBM,sFLMC,sFFLBM,sFFLMC,iSFQY,sIPDZ,sJSJ,sMACDZ,sXZRY,dXZSJ,sBZ " +
                "from SJZDFL where iSFQY = 1 order by sFLBM";
                SqlDataAdapter sda = new SqlDataAdapter(strSql, conn);
                conn.Open();
                sda.Fill(ds, "SJZDFL");
                dgvSJZDFL.DataSource = ds.Tables["SJZDFL"];
                ssrlTJ.Text = "共" + ds.Tables["SJZDFL"].Rows.Count.ToString() + "个分类";
                try
                {

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                ds.Clear();
                string strSql = "select sFLBM,sFLMC,sFFLBM,sFFLMC,iSFQY,sIPDZ,sJSJ,sMACDZ,sXZRY,dXZSJ,sBZ " +
                "from SJZDFL where iSFQY = 0 order by sFLBM";
                SqlDataAdapter sda = new SqlDataAdapter(strSql, conn);
                conn.Open();
                sda.Fill(ds, "SJZDFL");
                dgvSJZDFL.DataSource = ds.Tables["SJZDFL"];
                ssrlTJ.Text = "共" + ds.Tables["SJZDFL"].Rows.Count.ToString() + "个分类";
                try
                {

                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        private void TxtKSCZFL_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                if (txtKSCZFL.Text != "")
                {
                    if (rdoFLBM.Checked)
                    {
                        ds.Clear();
                        string strSql = "select sFLBM,sFLMC,sFFLBM,sFFLMC,sPYCZM,iSFQY,sIPDZ,sJSJ,sMACDZ,sXZRY,dXZSJ,sBZ " +
                    "from SJZDFL where sFLBM like '%" + txtKSCZFL.Text.ToString().Trim() + "%' order by sFLBM";
                        SqlDataAdapter sda = new SqlDataAdapter(strSql, conn);
                        conn.Open();
                        sda.Fill(ds, "SJZDFL");
                        dgvSJZDFL.DataSource = ds.Tables["SJZDFL"];

                        ssrlTJ.Text = "共" + ds.Tables["SJZDFL"].Rows.Count.ToString() + "个分类";
                        try
                        {

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                        finally
                        {
                            conn.Close();
                        }
                    }
                    else
                    {
                        ds.Clear();
                        string strSql = "select sFLBM,sFLMC,sFFLBM,sFFLMC,sPYCZM,iSFQY,sIPDZ,sJSJ,sMACDZ,sXZRY,dXZSJ,sBZ " +
                    "from SJZDFL where sFLMC like '%" + txtKSCZFL.Text.ToString().Trim() + "%' order by sFLBM";
                        SqlDataAdapter sda = new SqlDataAdapter(strSql, conn);
                        conn.Open();
                        sda.Fill(ds, "SJZDFL");
                        dgvSJZDFL.DataSource = ds.Tables["SJZDFL"];

                        ssrlTJ.Text = "共" + ds.Tables["SJZDFL"].Rows.Count.ToString() + "个分类";
                        try
                        {

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                        finally
                        {
                            conn.Close();
                        }
                    }
                }
                else
                {
                    ds.Clear();
                    Display();
                }
            }
        }

        private void DgvSJZDFL_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            SJZDFL_Helper.SFLBM = dgvSJZDFL.CurrentRow.Cells[0].Value.ToString();
            //MessageBox.Show(dgvSJZDFL.CurrentRow.Cells[1].Value.ToString());
            SJZDFL_Helper.SFLMC = dgvSJZDFL.CurrentRow.Cells[1].Value.ToString();
            SJZDFL_Helper.SFFLBM = dgvSJZDFL.CurrentRow.Cells[2].Value.ToString();
            //MessageBox.Show(dgvSJZDFL.CurrentRow.Cells[2].Value.ToString());
            SJZDFL_Helper.SFFLMC = dgvSJZDFL.CurrentRow.Cells[3].Value.ToString();
            //MessageBox.Show(dgvSJZDFL.CurrentRow.Cells[3].Value.ToString());
            //MessageBox.Show(SJZDFL_Helper.SFFLMC);
            //MessageBox.Show(Convert.ToBoolean(dgvSJZDFL.CurrentRow.Cells[5].Value.ToString()));
            SJZDFL_Helper.SPYCZM = dgvSJZDFL.CurrentRow.Cells[4].Value.ToString();
            SJZDFL_Helper.ISFQY = Convert.ToBoolean(dgvSJZDFL.CurrentRow.Cells[5].Value.ToString());
            //MessageBox.Show(SJZDFL_Helper.ISFQY.ToString());
        }

        private void SJZDFL_Load(object sender, EventArgs e)
        {
            ds.Clear();
            Display();
        }
    }
}
