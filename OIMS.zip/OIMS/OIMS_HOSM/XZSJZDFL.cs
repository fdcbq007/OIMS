﻿using OIMS_BLL;
using OIMS_DAL;
using OIMS_HOSM_BLL;
using OIMS_HOSM_DAL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OIMS_HOSM
{
    public partial class XZSJZDFL : Form
    {
        public XZSJZDFL()
        {
            InitializeComponent();
            //自动在下拉下表中显示父分类名称
            cmbFFLMC.DataSource = SJZD_BLL.GetAllSJZDFL();
            cmbFFLMC.DisplayMember = "SFLMC1";
            cmbFFLMC.ValueMember = "SFLBM1";
            cmbFFLMC.SelectedIndex = -1;

            txtBSM.Clear();
            txtFLBM.Clear();
            txtFLMC.Clear();
            cmbFFLMC.SelectedIndex = -1;
            txtBSM.Focus();
            //txtFFLBM.Text = "";

            txtIPDZ.Text = HQJSJXGXX.GetDQIP();
            txtJSJ.Text = HQJSJXGXX.GetJSJ();
            txtMACDZ.Text = HQJSJXGXX.GetDQMACDZ();
            txtXZRY.Text = LoginUserHelper.LoginUserName;

            cmbSFQY.SelectedIndex = 0;
        }

        public string message = "";
        string sFPKey;
        string sFFLBM;
        string sFFLMC;
        bool iSFQY;
        SqlConnection conn = OIMS_ConfigHelper.GetConnection(OIMS_ConfigHelper.GetConnString());

        private void TsrbXZ_Click(object sender, EventArgs e)
        {
            txtBSM.Clear();
            txtFLBM.Clear();
            txtFLMC.Clear();
            txtBSM.Focus();
        }

        private void TsrbBC_Click(object sender, EventArgs e)
        {
            string sPKey = Guid.NewGuid().ToString();
            string sBSM = txtBSM.Text.ToString();
            string sFLBM = txtFLBM.Text.ToString();
            string sFLMC = txtFLMC.Text.ToString();

            //获取下拉框绑定的分类编码和分类名称
            //MessageBox.Show(cmbFFLMC.SelectedText.ToString());
            //MessageBox.Show(cmbFFLMC.SelectedValue.ToString());
            //判断选择的下拉框的内容
            if (cmbFFLMC.Text.Trim().Length == 0)
            {
                sFPKey = "";
                sFFLBM = "";
                sFFLMC = "";
            }
            else
            {
                sFPKey = SJZD_BLL.GetSPKey(cmbFFLMC.SelectedValue.ToString());
                sFFLBM = cmbFFLMC.SelectedValue.ToString();
                sFFLMC = SJZDFL_Helper.SFFLMC;
            }

            string sPYCZM = HZZPY.GetSpellCode(sFLMC);
            string sIPDZ = txtIPDZ.Text.ToString();
            string sJSJ = txtJSJ.Text.ToString();
            string sMACDZ = txtMACDZ.Text.ToString();
            string sXZRYYHID = LoginUserHelper.LoginUserId;
            string sXZRY = txtXZRY.Text.ToString();
            DateTime dXZSJ  = dtpXZSJ.Value.ToLocalTime();
            string sBZ = txtBZ.Text.ToString();

            if (SJZD_BLL.IsValidataInputFLBM(sFLBM) == false)
            {
                MessageBox.Show("分类编码不能为空", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            }
            else if (SJZD_BLL.IsValidataInputFLMC(sFLMC) == false)
            {
                MessageBox.Show("分类名称不能为空", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            }
            else if (SJZD_BLL.IsValidataInputBSM(sBSM) == false)
            {
                MessageBox.Show("标识码不能为空", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            }
            else
            {
                if (SJZD_BLL.IsValidataFLBM(sFLBM, ref message))
                {
                    if (SJZD_BLL.IsValidataFLMC(sFLMC, ref message))
                    {
                        if (SJZD_BLL.IsValidataBSM(sBSM,ref message))
                        {
                            string cmdStr = "insert into sjzdfl(sPKey,sBSM,sFLBM,sFLMC,sFPKey,sFFLBM,sFFLMC,sPYCZM,iSFQY,sIPDZ,sJSJ,sMACDZ,sXZRY,sXZRYYHID,dXZSJ,sBZ) " +
                            "values('" + sPKey +
                            "','" + sBSM +
                            "','" + sFLBM +
                            "','" + sFLMC +
                            "','" + sFPKey +
                            "','" + sFFLBM +
                            "','" + sFFLMC +
                            "','" + sPYCZM +
                            "','" + iSFQY +
                            "','" + sIPDZ +
                            "','" + sJSJ +
                            "','" + sMACDZ +
                            "','" + sXZRY +
                            "','" + sXZRYYHID +
                            "','" + dXZSJ +
                            "','" + sBZ +
                            "')";
                            SqlConnection conn = OIMS_ConfigHelper.GetConnection(OIMS_ConfigHelper.GetConnString());
                            SqlCommand sqlcmd = new SqlCommand(cmdStr, conn);
                            conn.Open();

                            int count = sqlcmd.ExecuteNonQuery();
                            if (count > 0)
                            {
                                MessageBox.Show("添加成功");
                            }
                            else
                            {
                                MessageBox.Show("添加失败");
                            }
                            conn.Close();
                            //请空已录入的数据
                            txtBSM.Focus();
                            txtBSM.Clear();
                            txtFLBM.Clear();
                            txtFLMC.Clear();
                            txtFFLBM.Clear();
                            cmbFFLMC.SelectedIndex = -1;
                        }
                        else
                        {
                            MessageBox.Show(message);
                        }
                    }
                    else
                    {
                        MessageBox.Show(message);
                    }
                }    
                else
                {
                    MessageBox.Show(message);
                }
            }
        }

        private void TsrbTC_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void TxtBSM_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtFLBM.Focus();
            }
        }

        private void TxtFLBM_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtFLMC.Focus();
            }
        }

        private void TxtFLMC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                
                cmbFFLMC.Focus();
                
            }
        }
        private void CmbFFLMC_KeyPress(object sender, KeyPressEventArgs e)

        {
            if (e.KeyChar == '\r')
            {
                if (cmbFFLMC.Text.Trim().Length == 0)
                {
                    cmbSFQY.Focus();
                }
                else
                {
                    //MessageBox.Show(cmbFFLMC.SelectedItem.ToString());
                    //MessageBox.Show(cmbFFLMC.SelectedValue.ToString());
                    //MessageBox.Show(cmbFFLMC.SelectedText.ToString());
                    //sFFLMC = cmbFFLMC.SelectedText.ToString();
                    txtFFLBM.Text = cmbFFLMC.SelectedValue.ToString();
                    cmbSFQY.Focus();
                }     
            }
        }

        private void CmbSFQY_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(e.KeyChar == '\r')
            {
                txtBZ.Focus();
            }
        }

        private void CmbSFQY_SelectedIndexChanged(object sender, EventArgs e)
        {
            //获取下拉数据的项目名称
            if (cmbSFQY.SelectedItem.ToString() == "是")
            {
                iSFQY = true;
            }
            else
            {
                iSFQY = false;
            }
        }

        private void TsrbTC_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CmbFFLMC_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbFFLMC.Text.Trim().Length == 0)
            {
                cmbSFQY.Focus();
            }
            else
            {
                SJZDFL_Helper.SFFLMC = cmbFFLMC.Text;
                txtFFLBM.Text = cmbFFLMC.SelectedValue.ToString();
                cmbSFQY.Focus();
            }
        }
    }
}
