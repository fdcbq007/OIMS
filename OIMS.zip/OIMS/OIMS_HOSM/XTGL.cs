﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OIMS_HOSM
{
    public partial class XTGL : Form
    {
        public XTGL()
        {
            InitializeComponent();
        }
        SJZDFL sjzdfl;
        YHGL yhgl;
        SJZDMX sjzdmx;

        private void TsmiUserManage_Click(object sender, EventArgs e)
        {
            
            if (yhgl == null || yhgl.IsDisposed)
            {
                yhgl = new YHGL
                {
                    TopLevel = false
                };
                yhgl.BringToFront();
                pnlXTGL.BringToFront();
                pnlXTGL.Controls.Add(yhgl);
                yhgl.Show();
            }
            else
            {
                yhgl.Activate(); //已打开，获得焦点，置顶。
            }
        }

        private void TsmiWYZYHZ_Click(object sender, EventArgs e)
        {
            WY_ZYHZ wY_ZYHZ = new WY_ZYHZ();
            WY_ZYHZ wyzyhz = wY_ZYHZ;
            //wyzyhz.TopLevel = false;
            ////然后像添加普通控件一样加入到panel的controls里面就好
            //panelSystemManager.Controls.Add(wyzyhz);
            wyzyhz.MdiParent = this;
            wyzyhz.Show();
        }

        private void TsmiSJZD_Click(object sender, EventArgs e)
        {
            
            if (sjzdmx == null || sjzdmx.IsDisposed)
            {
                sjzdmx = new SJZDMX
                {
                    TopLevel = false
                };
                sjzdmx.BringToFront();
                pnlXTGL.BringToFront();
                
                pnlXTGL.Controls.Add(sjzdmx);
                sjzdmx.Show();
            }
            else
            {
                sjzdmx.Activate(); //已打开，获得焦点，置顶。
            }
        }

        
        private void TsmiSJZDFL_Click(object sender, EventArgs e)
        {
            //{
            //    //首先将要作为控件的窗体的 TOPLEVEL属性设置为False
            //    TopLevel = true
            //};
            //然后像添加普通控件一样加入到panel的controls里面就好
            //panelSystemManager.Controls.Add(sjzdfl);
            
            if (sjzdfl == null || sjzdfl.IsDisposed)
            {

                sjzdfl = new SJZDFL
                {
                    TopLevel = false
                };

                sjzdfl.BringToFront();
                pnlXTGL.BringToFront();
                pnlXTGL.Controls.Add(sjzdfl);
                sjzdfl.Show();
            }
            else
            {
                sjzdfl.Activate(); //已打开，获得焦点，置顶。
            }  
        }
    }
}
