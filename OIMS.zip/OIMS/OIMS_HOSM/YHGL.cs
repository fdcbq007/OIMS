﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using OIMS_BLL;
using OIMS_DAL;
using OIMS_HOSM_BLL;

namespace OIMS_HOSM
{
    public partial class YHGL : Form
    {
        public DateTime dSR;
        public string sNL;
        public string message = "";
        DataSet ds = new DataSet(); //定义一个数据集
        SqlConnection conn = OIMS_ConfigHelper.GetConnection(OIMS_ConfigHelper.GetConnString());
        public YHGL()
        {
            InitializeComponent();
            Display();
            dgvYHLB.AutoGenerateColumns = false;
            //设置单击选中整行，默认设置的是点击的单元格
            this.btnXGYH.Enabled = false;
            this.btnBCYH.Enabled = false;
            this.btnFH.Enabled = false;
            this.btnTC.Enabled = true;
        }

        private void BtnTJYH_Click(object sender, EventArgs e)
        {
            btnXGYH.Enabled = true;
            btnBCYH.Enabled = true;
            btnFH.Enabled = true;
            tabYHGL.SelectedIndex = 1;
            txtYHID.Focus();
            cmbXB.SelectedText = "男";
        }

        private void BtnXGYH_Click(object sender, EventArgs e)
        {
            tabYHGL.SelectedIndex = 1;
        }

        private void BtnBCYH_Click(object sender, EventArgs e)
        {
            DataTable dt = ds.Tables["Users"];

            string PKey = Guid.NewGuid().ToString();
            string sYHID = txtYHID.Text.Trim();
            string sDLZH = txtYHID.Text.Trim();
            string sDLMM = DesEncryption.EncryptDES("123456" + sDLZH, "201902231230");
            string sYHM = txtYHM.Text.Trim();
            string sPYSZM = txtPYSZM.Text.Trim();
            string sSJH = txtSJH.Text.Trim();
            string sXB = cmbXB.Text.Trim();


            if (YHGL_BLL.IsValidataInput(sDLZH) == false)
            {
                MessageBox.Show("账号不能为空，请注意！", "提示", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            }
            else
            {
                if (YHGL_BLL.IsValidataUserId(sDLZH, ref message))
                {
                    string cmdStr = "insert into Users(PKey,sYHID,sDLZH,sDLMM,sYHM,sPYSZM,sXB,dSR,sNL,sSJH) " +
                    "values('" + PKey +
                    "','" + sYHID +
                    "','" + sDLZH +
                    "','" + sDLMM +
                    "','" + sYHM +
                    "','" + sPYSZM +
                    "','" + sXB +
                    "','" + dSR +
                    "','" + sNL +
                    "','" + sSJH +
                    "')";
                    SqlConnection conn = OIMS_ConfigHelper.GetConnection(OIMS_ConfigHelper.GetConnString());
                    SqlCommand sqlcmd = new SqlCommand(cmdStr, conn);
                    conn.Open();

                    int count = sqlcmd.ExecuteNonQuery();
                    if (count > 0)
                    {
                        MessageBox.Show("添加成功");
                    }
                    else
                    {
                        MessageBox.Show("添加失败");
                    }

                    conn.Close();

                    ds.Clear();
                }
                else
                {
                    MessageBox.Show(message);
                }
            }
        }

        private void BtnFH_Click(object sender, EventArgs e)
        {
            tabYHGL.SelectedIndex = 0;
        }

        //显示全部信息
        public void Display()
        {
            tabYHGL.SelectedIndex = 0;
            string strSql = "select sYHID,sYHM,sPYSZM,dSR,sNL from Users";
            SqlDataAdapter sda = new SqlDataAdapter(strSql, conn);
            conn.Open();
            sda.Fill(ds, "users");
            dgvYHLB.DataSource = ds.Tables["users"];
            try
            {

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
            //如下这种方式适合用在报表设计。
            ////实例化适配器
            //SqlDataAdapter sda = new SqlDataAdapter();
            //SqlCommand cmd = new SqlCommand(strSql, conn);
            ////使用SqlDataAdapter的查询
            //sda.SelectCommand = cmd;
            ////用 DataSet 方式 
            //ds.Clear();

            ////映射
            ////DestTable为设定的ds中da填充的表名，为映射源表，DestTable为映射表名(有点像视图view)

            ////1、表映射
            ////语法：DataAdapter.TableMappings.Add(SourceTable,DestTable);
            //sda.TableMappings.Add("SourceTable", "DestTable");
            ////这一步不能省，否则在下面的列名映射时会提示找DestTable表
            //sda.TableMappings.Add("DestTable", "DestTable");

            ////填充源表，以上写好之后就可以进行获取绑定数据，但是无法绑定到具体的列名所以进行注释
            ////sda.Fill(ds,"DestTable");

            ////2、列映射
            ////语法：DataAdapter.TableMappings[DestTable].ColumnMappings.Add(sourceField,destField);
            ////注意：TableMapping是属性，故后面带方括号，注意不要使用成圆括号

            //sda.TableMappings["DestTable"].ColumnMappings.Add("sYHID", "用户ID");
            //sda.TableMappings["DestTable"].ColumnMappings.Add("sDLZH", "登录账号");
            //sda.TableMappings["DestTable"].ColumnMappings.Add("sYHM", "用户名");
            //sda.TableMappings["DestTable"].ColumnMappings.Add("sPYSZM", "拼音首字母");
            //sda.TableMappings["DestTable"].ColumnMappings.Add("dSR", "s生日");
            ////sda.TableMappings["DestTable"].ColumnMappings.Add("Secretkey", "用户密码");
            ////sda.TableMappings["DestTable"].ColumnMappings.Add("RealName", "真实姓名");

            ////填充表，注意1、该条语句只能在这个位置，放在前面，可显示内容，但不能映射列名；2、只能用sda.Fill(ds, "DestTable")，而不能用sda.Fill(ds, "SourceTable")
            //sda.Fill(ds, "DestTable");

            //try
            //{
            //    this.dgvYHLB.DataSource = ds;
            //    this.dgvYHLB.DataMember = "DestTable";

            //    //显示列宽
            //    dgvYHLB.Columns[0].Width = 90;
            //    dgvYHLB.Columns[1].Width = 90;
            //    dgvYHLB.Columns[2].Width = 100;
            //    dgvYHLB.Columns[3].Width = 100;
            //    dgvYHLB.Columns[4].Width = 100;
            //    //dgvUserList.Columns[5].Width = 180;
            //}
            //catch
            //{
            //    MessageBox.Show("error!");
            //}

            //if (Conn.State == ConnectionState.Open)
            //{
            //    Conn.Close();
            //}

            ////定义一个dataAdapter

            ////填充数据集
            //sda.Fill(ds, "Users");
            ////填充数据进控件
            //datagvUserList.DataSource = ds.Tables["Users"];  

        }

        //自动显示序号，需要触发如下的事件
        private void DatagvUserList_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            var grid = sender as DataGridView;
            var rowIdx = (e.RowIndex + 1).ToString();

            var centerFormat = new StringFormat()
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };

            var headerBounds = new Rectangle(e.RowBounds.Left, e.RowBounds.Top, grid.RowHeadersWidth, e.RowBounds.Height);
            e.Graphics.DrawString(rowIdx, this.Font, SystemBrushes.ControlText, headerBounds, centerFormat);
        }

        private void BtnCXYH_Click(object sender, EventArgs e)
        {
            //清空控件上的内容
            ds.Clear();
            Display();
        }

        private void BtnTC_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void YHGL_Load(object sender, EventArgs e)
        {
            //ds.Clear();
            //Display();
        }

        private void DgvYHLB_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            tabYHGL.SelectedIndex = 1;
            btnXGYH.Enabled = true;
            btnBCYH.Enabled = true;
            btnFH.Enabled = true;

            try
            {
                string sYHID = dgvYHLB.CurrentRow.Cells[0].Value.ToString();
                string strSql = "select sYHID,sYHM,sPYSZM,dSR,sNL from Users where sYHID = '" + sYHID + "'";
                SqlCommand cmd = new SqlCommand(strSql, conn);
                conn.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    txtYHID.Text = dr[0].ToString();
                    txtYHM.Text = dr[1].ToString();
                    txtPYSZM.Text = dr[2].ToString();
                    dtpSR.Value = Convert.ToDateTime(dr[3].ToString().Trim());
                    txtNL.Text = dr[4].ToString();

                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
        }

        private void TxtYHID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtYHM.Focus();
            }
        }

        private void TxtYHM_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtPYSZM.Focus();
            }
        }

        private void TxtPYSZM_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                cmbXB.Focus();
            }
        }

        private void CmbXB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                dtpSR.Focus();
            }
        }

        private void DtpSR_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtSJH.Focus();
                dSR = dtpSR.Value.Date;
                sNL = YHGL_BLL.GetAgeByBirthdate(dSR).ToString() + "岁";
                txtNL.Text = sNL; 
            }
        }

        private void TxtSJH_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                cmbZJLX.Focus();
            }
        }

        private void CmbZJLX_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtZJHM.Focus();
            }
        }

        private void TxtZJHM_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtDZYX.Focus();
            }
        }

        private void TxtDZYX_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtQQ.Focus();
            }
        }

        private void TxtQQ_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtWX.Focus();
            }
        }

        private void TxtWX_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                cmbSF.Focus();
            }
        }

        private void CmbSF_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                cmbCS.Focus();
            }
        }

        private void CmbCS_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                cmbQX.Focus();
            }
        }

        private void CmbQX_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtJZDZ.Focus();
            }
        }

        private void TxtJZDZ_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtYZBM.Focus();
            }
        }

        private void TxtYZBM_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtBZ.Focus();
            }
        }

        private void TxtBZ_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtYHJC.Focus();
            }
        }

        private void TxtYHJC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtGH.Focus();
            }
        }

        private void TxtGH_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtYWJS.Focus();
            }
        }

        private void TxtYWJS_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                cmbGS.Focus();
            }
        }

        private void CmbGS_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                cmbBM.Focus();
            }
        }

        private void CmbBM_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                cmbZW.Focus();
            }
        }

        private void CmbZW_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                cmbGYLX.Focus();
            }
        }

        private void CmbGYLX_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                dtpGYRQ.Focus();
            }
        }

        private void DtpGYRQ_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                dtpCJSJ.Focus();
            }
        }

        private void DtpCJSJ_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                cmbQSRLLX.Focus();
            }
        }

        private void CmbQSRLLX_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                cmbQSKB.Focus();
            }
        }

        private void CmbQSKB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                rdoQSSBBZ.Focus();
            }
        }

        private void RdoQSSBBZ_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                txtBZ1.Focus();
            }
        }
    }
}
