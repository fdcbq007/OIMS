﻿namespace OIMS_HOSM
{
    partial class XZSJZDFL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tsrXZSJZDFL = new System.Windows.Forms.ToolStrip();
            this.tsrsXZ = new System.Windows.Forms.ToolStripSeparator();
            this.tsrbXZ = new System.Windows.Forms.ToolStripButton();
            this.tsrsBC = new System.Windows.Forms.ToolStripSeparator();
            this.tsrbBC = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tsrbTC = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.lblFLBM = new System.Windows.Forms.Label();
            this.txtFLBM = new System.Windows.Forms.TextBox();
            this.txtFLMC = new System.Windows.Forms.TextBox();
            this.lblFLMC = new System.Windows.Forms.Label();
            this.lblXZSJ = new System.Windows.Forms.Label();
            this.lblMACDZ = new System.Windows.Forms.Label();
            this.txtMACDZ = new System.Windows.Forms.TextBox();
            this.txtJSJ = new System.Windows.Forms.TextBox();
            this.lblJSJ = new System.Windows.Forms.Label();
            this.lblXZRY = new System.Windows.Forms.Label();
            this.lblSFQY = new System.Windows.Forms.Label();
            this.cmbSFQY = new System.Windows.Forms.ComboBox();
            this.txtXZRY = new System.Windows.Forms.TextBox();
            this.dtpXZSJ = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblFFLMC = new System.Windows.Forms.Label();
            this.cmbFFLMC = new System.Windows.Forms.ComboBox();
            this.lblFFLBM = new System.Windows.Forms.Label();
            this.txtIPDZ = new System.Windows.Forms.TextBox();
            this.lblIPDZ = new System.Windows.Forms.Label();
            this.txtBZ = new System.Windows.Forms.TextBox();
            this.lblBZ = new System.Windows.Forms.Label();
            this.txtFFLBM = new System.Windows.Forms.TextBox();
            this.txtBSM = new System.Windows.Forms.TextBox();
            this.lblBSM = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tsrXZSJZDFL.SuspendLayout();
            this.SuspendLayout();
            // 
            // tsrXZSJZDFL
            // 
            this.tsrXZSJZDFL.BackColor = System.Drawing.SystemColors.MenuBar;
            this.tsrXZSJZDFL.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsrsXZ,
            this.tsrbXZ,
            this.tsrsBC,
            this.tsrbBC,
            this.toolStripSeparator3,
            this.tsrbTC,
            this.toolStripSeparator4});
            this.tsrXZSJZDFL.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.tsrXZSJZDFL.Location = new System.Drawing.Point(0, 0);
            this.tsrXZSJZDFL.Name = "tsrXZSJZDFL";
            this.tsrXZSJZDFL.Size = new System.Drawing.Size(542, 25);
            this.tsrXZSJZDFL.TabIndex = 0;
            this.tsrXZSJZDFL.Text = "新增数据字典分类工具条";
            // 
            // tsrsXZ
            // 
            this.tsrsXZ.Name = "tsrsXZ";
            this.tsrsXZ.Size = new System.Drawing.Size(6, 25);
            // 
            // tsrbXZ
            // 
            this.tsrbXZ.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsrbXZ.Name = "tsrbXZ";
            this.tsrbXZ.Size = new System.Drawing.Size(36, 22);
            this.tsrbXZ.Text = "新增";
            this.tsrbXZ.Click += new System.EventHandler(this.TsrbXZ_Click);
            // 
            // tsrsBC
            // 
            this.tsrsBC.Name = "tsrsBC";
            this.tsrsBC.Size = new System.Drawing.Size(6, 25);
            // 
            // tsrbBC
            // 
            this.tsrbBC.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsrbBC.Name = "tsrbBC";
            this.tsrbBC.Size = new System.Drawing.Size(36, 22);
            this.tsrbBC.Text = "保存";
            this.tsrbBC.Click += new System.EventHandler(this.TsrbBC_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // tsrbTC
            // 
            this.tsrbTC.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsrbTC.Name = "tsrbTC";
            this.tsrbTC.Size = new System.Drawing.Size(36, 22);
            this.tsrbTC.Text = "退出";
            this.tsrbTC.Click += new System.EventHandler(this.TsrbTC_Click_1);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // lblFLBM
            // 
            this.lblFLBM.AutoSize = true;
            this.lblFLBM.Location = new System.Drawing.Point(40, 88);
            this.lblFLBM.Name = "lblFLBM";
            this.lblFLBM.Size = new System.Drawing.Size(65, 12);
            this.lblFLBM.TabIndex = 14;
            this.lblFLBM.Text = "分类编码：";
            // 
            // txtFLBM
            // 
            this.txtFLBM.Location = new System.Drawing.Point(101, 84);
            this.txtFLBM.Name = "txtFLBM";
            this.txtFLBM.Size = new System.Drawing.Size(151, 21);
            this.txtFLBM.TabIndex = 2;
            this.txtFLBM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtFLBM_KeyPress);
            // 
            // txtFLMC
            // 
            this.txtFLMC.Location = new System.Drawing.Point(358, 84);
            this.txtFLMC.Name = "txtFLMC";
            this.txtFLMC.Size = new System.Drawing.Size(151, 21);
            this.txtFLMC.TabIndex = 3;
            this.txtFLMC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtFLMC_KeyPress);
            // 
            // lblFLMC
            // 
            this.lblFLMC.AutoSize = true;
            this.lblFLMC.Location = new System.Drawing.Point(297, 88);
            this.lblFLMC.Name = "lblFLMC";
            this.lblFLMC.Size = new System.Drawing.Size(65, 12);
            this.lblFLMC.TabIndex = 15;
            this.lblFLMC.Text = "分类名称：";
            // 
            // lblXZSJ
            // 
            this.lblXZSJ.AutoSize = true;
            this.lblXZSJ.Location = new System.Drawing.Point(297, 238);
            this.lblXZSJ.Name = "lblXZSJ";
            this.lblXZSJ.Size = new System.Drawing.Size(65, 12);
            this.lblXZSJ.TabIndex = 23;
            this.lblXZSJ.Text = "新增时间：";
            // 
            // lblMACDZ
            // 
            this.lblMACDZ.AutoSize = true;
            this.lblMACDZ.Location = new System.Drawing.Point(303, 200);
            this.lblMACDZ.Name = "lblMACDZ";
            this.lblMACDZ.Size = new System.Drawing.Size(59, 12);
            this.lblMACDZ.TabIndex = 21;
            this.lblMACDZ.Text = "MAC地址：";
            // 
            // txtMACDZ
            // 
            this.txtMACDZ.Enabled = false;
            this.txtMACDZ.Location = new System.Drawing.Point(358, 196);
            this.txtMACDZ.Name = "txtMACDZ";
            this.txtMACDZ.Size = new System.Drawing.Size(151, 21);
            this.txtMACDZ.TabIndex = 9;
            // 
            // txtJSJ
            // 
            this.txtJSJ.Enabled = false;
            this.txtJSJ.Location = new System.Drawing.Point(101, 196);
            this.txtJSJ.Name = "txtJSJ";
            this.txtJSJ.Size = new System.Drawing.Size(151, 21);
            this.txtJSJ.TabIndex = 8;
            // 
            // lblJSJ
            // 
            this.lblJSJ.AutoSize = true;
            this.lblJSJ.Location = new System.Drawing.Point(52, 200);
            this.lblJSJ.Name = "lblJSJ";
            this.lblJSJ.Size = new System.Drawing.Size(53, 12);
            this.lblJSJ.TabIndex = 20;
            this.lblJSJ.Text = "计算机：";
            // 
            // lblXZRY
            // 
            this.lblXZRY.AutoSize = true;
            this.lblXZRY.Location = new System.Drawing.Point(40, 238);
            this.lblXZRY.Name = "lblXZRY";
            this.lblXZRY.Size = new System.Drawing.Size(65, 12);
            this.lblXZRY.TabIndex = 22;
            this.lblXZRY.Text = "新增人员：";
            // 
            // lblSFQY
            // 
            this.lblSFQY.AutoSize = true;
            this.lblSFQY.Location = new System.Drawing.Point(40, 163);
            this.lblSFQY.Name = "lblSFQY";
            this.lblSFQY.Size = new System.Drawing.Size(65, 12);
            this.lblSFQY.TabIndex = 18;
            this.lblSFQY.Text = "是否启用：";
            // 
            // cmbSFQY
            // 
            this.cmbSFQY.FormattingEnabled = true;
            this.cmbSFQY.Items.AddRange(new object[] {
            "是",
            "否"});
            this.cmbSFQY.Location = new System.Drawing.Point(101, 159);
            this.cmbSFQY.Name = "cmbSFQY";
            this.cmbSFQY.Size = new System.Drawing.Size(151, 20);
            this.cmbSFQY.TabIndex = 6;
            this.cmbSFQY.SelectedIndexChanged += new System.EventHandler(this.CmbSFQY_SelectedIndexChanged);
            this.cmbSFQY.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CmbSFQY_KeyPress);
            // 
            // txtXZRY
            // 
            this.txtXZRY.Enabled = false;
            this.txtXZRY.Location = new System.Drawing.Point(101, 234);
            this.txtXZRY.Name = "txtXZRY";
            this.txtXZRY.Size = new System.Drawing.Size(151, 21);
            this.txtXZRY.TabIndex = 10;
            // 
            // dtpXZSJ
            // 
            this.dtpXZSJ.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.dtpXZSJ.Enabled = false;
            this.dtpXZSJ.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpXZSJ.Location = new System.Drawing.Point(358, 234);
            this.dtpXZSJ.Name = "dtpXZSJ";
            this.dtpXZSJ.Size = new System.Drawing.Size(151, 21);
            this.dtpXZSJ.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(258, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(11, 12);
            this.label1.TabIndex = 47;
            this.label1.Text = "*";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(515, 88);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(11, 12);
            this.label3.TabIndex = 49;
            this.label3.Text = "*";
            // 
            // lblFFLMC
            // 
            this.lblFFLMC.AutoSize = true;
            this.lblFFLMC.Location = new System.Drawing.Point(28, 126);
            this.lblFFLMC.Name = "lblFFLMC";
            this.lblFFLMC.Size = new System.Drawing.Size(77, 12);
            this.lblFFLMC.TabIndex = 16;
            this.lblFFLMC.Text = "父分类名称：";
            // 
            // cmbFFLMC
            // 
            this.cmbFFLMC.FormattingEnabled = true;
            this.cmbFFLMC.Location = new System.Drawing.Point(101, 122);
            this.cmbFFLMC.Name = "cmbFFLMC";
            this.cmbFFLMC.Size = new System.Drawing.Size(151, 20);
            this.cmbFFLMC.TabIndex = 4;
            this.cmbFFLMC.SelectedIndexChanged += new System.EventHandler(this.CmbFFLMC_SelectedIndexChanged);
            this.cmbFFLMC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CmbFFLMC_KeyPress);
            // 
            // lblFFLBM
            // 
            this.lblFFLBM.AutoSize = true;
            this.lblFFLBM.Location = new System.Drawing.Point(285, 126);
            this.lblFFLBM.Name = "lblFFLBM";
            this.lblFFLBM.Size = new System.Drawing.Size(77, 12);
            this.lblFFLBM.TabIndex = 17;
            this.lblFFLBM.Text = "父分类编码：";
            // 
            // txtIPDZ
            // 
            this.txtIPDZ.Enabled = false;
            this.txtIPDZ.Location = new System.Drawing.Point(358, 159);
            this.txtIPDZ.Name = "txtIPDZ";
            this.txtIPDZ.Size = new System.Drawing.Size(151, 21);
            this.txtIPDZ.TabIndex = 7;
            // 
            // lblIPDZ
            // 
            this.lblIPDZ.AutoSize = true;
            this.lblIPDZ.Location = new System.Drawing.Point(309, 163);
            this.lblIPDZ.Name = "lblIPDZ";
            this.lblIPDZ.Size = new System.Drawing.Size(53, 12);
            this.lblIPDZ.TabIndex = 19;
            this.lblIPDZ.Text = "IP地址：";
            // 
            // txtBZ
            // 
            this.txtBZ.Location = new System.Drawing.Point(101, 272);
            this.txtBZ.Name = "txtBZ";
            this.txtBZ.Size = new System.Drawing.Size(408, 21);
            this.txtBZ.TabIndex = 12;
            // 
            // lblBZ
            // 
            this.lblBZ.AutoSize = true;
            this.lblBZ.Location = new System.Drawing.Point(64, 276);
            this.lblBZ.Name = "lblBZ";
            this.lblBZ.Size = new System.Drawing.Size(41, 12);
            this.lblBZ.TabIndex = 24;
            this.lblBZ.Text = "备注：";
            // 
            // txtFFLBM
            // 
            this.txtFFLBM.Enabled = false;
            this.txtFFLBM.Location = new System.Drawing.Point(358, 122);
            this.txtFFLBM.Name = "txtFFLBM";
            this.txtFFLBM.Size = new System.Drawing.Size(151, 21);
            this.txtFFLBM.TabIndex = 5;
            // 
            // txtBSM
            // 
            this.txtBSM.Location = new System.Drawing.Point(101, 46);
            this.txtBSM.Name = "txtBSM";
            this.txtBSM.Size = new System.Drawing.Size(151, 21);
            this.txtBSM.TabIndex = 1;
            this.txtBSM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtBSM_KeyPress);
            // 
            // lblBSM
            // 
            this.lblBSM.AutoSize = true;
            this.lblBSM.Location = new System.Drawing.Point(52, 50);
            this.lblBSM.Name = "lblBSM";
            this.lblBSM.Size = new System.Drawing.Size(53, 12);
            this.lblBSM.TabIndex = 13;
            this.lblBSM.Text = "标识码：";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Location = new System.Drawing.Point(258, 50);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(11, 12);
            this.label4.TabIndex = 60;
            this.label4.Text = "*";
            // 
            // XZSJZDFL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(542, 311);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtBSM);
            this.Controls.Add(this.lblBSM);
            this.Controls.Add(this.txtFFLBM);
            this.Controls.Add(this.txtBZ);
            this.Controls.Add(this.lblBZ);
            this.Controls.Add(this.txtIPDZ);
            this.Controls.Add(this.lblIPDZ);
            this.Controls.Add(this.lblFFLBM);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtpXZSJ);
            this.Controls.Add(this.txtXZRY);
            this.Controls.Add(this.cmbSFQY);
            this.Controls.Add(this.cmbFFLMC);
            this.Controls.Add(this.lblXZRY);
            this.Controls.Add(this.lblSFQY);
            this.Controls.Add(this.txtJSJ);
            this.Controls.Add(this.lblJSJ);
            this.Controls.Add(this.txtMACDZ);
            this.Controls.Add(this.lblMACDZ);
            this.Controls.Add(this.lblFFLMC);
            this.Controls.Add(this.lblXZSJ);
            this.Controls.Add(this.txtFLMC);
            this.Controls.Add(this.lblFLMC);
            this.Controls.Add(this.txtFLBM);
            this.Controls.Add(this.lblFLBM);
            this.Controls.Add(this.tsrXZSJZDFL);
            this.Name = "XZSJZDFL";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "新增数据字典分类";
            this.tsrXZSJZDFL.ResumeLayout(false);
            this.tsrXZSJZDFL.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip tsrXZSJZDFL;
        private System.Windows.Forms.ToolStripSeparator tsrsXZ;
        private System.Windows.Forms.Label lblFLBM;
        private System.Windows.Forms.TextBox txtFLBM;
        private System.Windows.Forms.TextBox txtFLMC;
        private System.Windows.Forms.Label lblFLMC;
        private System.Windows.Forms.Label lblXZSJ;
        private System.Windows.Forms.Label lblMACDZ;
        private System.Windows.Forms.TextBox txtMACDZ;
        private System.Windows.Forms.TextBox txtJSJ;
        private System.Windows.Forms.Label lblJSJ;
        private System.Windows.Forms.ToolStripButton tsrbXZ;
        private System.Windows.Forms.ToolStripButton tsrbBC;
        private System.Windows.Forms.ToolStripButton tsrbTC;
        private System.Windows.Forms.Label lblXZRY;
        private System.Windows.Forms.Label lblSFQY;
        private System.Windows.Forms.ComboBox cmbSFQY;
        private System.Windows.Forms.TextBox txtXZRY;
        private System.Windows.Forms.DateTimePicker dtpXZSJ;
        private System.Windows.Forms.ToolStripSeparator tsrsBC;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblFFLMC;
        private System.Windows.Forms.ComboBox cmbFFLMC;
        private System.Windows.Forms.Label lblFFLBM;
        private System.Windows.Forms.TextBox txtIPDZ;
        private System.Windows.Forms.Label lblIPDZ;
        private System.Windows.Forms.TextBox txtBZ;
        private System.Windows.Forms.Label lblBZ;
        private System.Windows.Forms.TextBox txtFFLBM;
        private System.Windows.Forms.TextBox txtBSM;
        private System.Windows.Forms.Label lblBSM;
        private System.Windows.Forms.Label label4;
    }
}