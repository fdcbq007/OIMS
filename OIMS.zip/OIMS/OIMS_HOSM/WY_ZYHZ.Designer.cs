﻿namespace OIMS_HOSM
{
    partial class WY_ZYHZ
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.datagvWYZYHZ = new System.Windows.Forms.DataGridView();
            this.查询 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.datagvWYZYHZ)).BeginInit();
            this.SuspendLayout();
            // 
            // datagvWYZYHZ
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.datagvWYZYHZ.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.datagvWYZYHZ.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.ColumnHeader;
            this.datagvWYZYHZ.BackgroundColor = System.Drawing.Color.MistyRose;
            this.datagvWYZYHZ.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.datagvWYZYHZ.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.datagvWYZYHZ.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagvWYZYHZ.Location = new System.Drawing.Point(0, 1);
            this.datagvWYZYHZ.Name = "datagvWYZYHZ";
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.datagvWYZYHZ.RowHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.datagvWYZYHZ.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.datagvWYZYHZ.RowTemplate.Height = 23;
            this.datagvWYZYHZ.Size = new System.Drawing.Size(1572, 687);
            this.datagvWYZYHZ.TabIndex = 0;
            this.datagvWYZYHZ.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DatagvWYZYHZ_CellContentClick);
            this.datagvWYZYHZ.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.DatagvWYZYHZ_RowPostPaint);
            this.datagvWYZYHZ.RowStateChanged += new System.Windows.Forms.DataGridViewRowStateChangedEventHandler(this.DatagvWYZYHZ_RowStateChanged);
            // 
            // 查询
            // 
            this.查询.Location = new System.Drawing.Point(12, 703);
            this.查询.Name = "查询";
            this.查询.Size = new System.Drawing.Size(75, 23);
            this.查询.TabIndex = 1;
            this.查询.Text = "button1";
            this.查询.UseVisualStyleBackColor = true;
            // 
            // WY_ZYHZ
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1584, 861);
            this.Controls.Add(this.查询);
            this.Controls.Add(this.datagvWYZYHZ);
            this.Name = "WY_ZYHZ";
            this.Text = "温医住院汇总查询";
            this.Load += new System.EventHandler(this.WY_ZYHZ_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datagvWYZYHZ)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView datagvWYZYHZ;
        private System.Windows.Forms.Button 查询;
    }
}