﻿namespace OIMS_HOSM
{
    partial class BJSJZDFL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tsrXZSJZDFL = new System.Windows.Forms.ToolStrip();
            this.tsrsBC = new System.Windows.Forms.ToolStripSeparator();
            this.tsrbBC = new System.Windows.Forms.ToolStripButton();
            this.tsrsTC = new System.Windows.Forms.ToolStripSeparator();
            this.tsrbTC = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.lblFLBM = new System.Windows.Forms.Label();
            this.txtFLBM = new System.Windows.Forms.TextBox();
            this.txtFLMC = new System.Windows.Forms.TextBox();
            this.lblFLMC = new System.Windows.Forms.Label();
            this.lblBJSJ = new System.Windows.Forms.Label();
            this.lblBJMACDZ = new System.Windows.Forms.Label();
            this.txtBJMACDZ = new System.Windows.Forms.TextBox();
            this.txtBJJSJ = new System.Windows.Forms.TextBox();
            this.lblBJJSJ = new System.Windows.Forms.Label();
            this.lblBJRY = new System.Windows.Forms.Label();
            this.lblSFQY = new System.Windows.Forms.Label();
            this.cmbSFQY = new System.Windows.Forms.ComboBox();
            this.txtBJRY = new System.Windows.Forms.TextBox();
            this.dtpBJSJ = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblFFLMC = new System.Windows.Forms.Label();
            this.cmbFFLMC = new System.Windows.Forms.ComboBox();
            this.lblFFLBM = new System.Windows.Forms.Label();
            this.txtBJIPDZ = new System.Windows.Forms.TextBox();
            this.lblBJIPDZ = new System.Windows.Forms.Label();
            this.txtBJBZ = new System.Windows.Forms.TextBox();
            this.lblBZ = new System.Windows.Forms.Label();
            this.txtFFLBM = new System.Windows.Forms.TextBox();
            this.tsrXZSJZDFL.SuspendLayout();
            this.SuspendLayout();
            // 
            // tsrXZSJZDFL
            // 
            this.tsrXZSJZDFL.BackColor = System.Drawing.SystemColors.MenuBar;
            this.tsrXZSJZDFL.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsrsBC,
            this.tsrbBC,
            this.tsrsTC,
            this.tsrbTC,
            this.toolStripSeparator4});
            this.tsrXZSJZDFL.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.tsrXZSJZDFL.Location = new System.Drawing.Point(0, 0);
            this.tsrXZSJZDFL.Name = "tsrXZSJZDFL";
            this.tsrXZSJZDFL.Size = new System.Drawing.Size(542, 25);
            this.tsrXZSJZDFL.TabIndex = 0;
            this.tsrXZSJZDFL.Text = "新增数据字典分类工具条";
            // 
            // tsrsBC
            // 
            this.tsrsBC.Name = "tsrsBC";
            this.tsrsBC.Size = new System.Drawing.Size(6, 25);
            // 
            // tsrbBC
            // 
            this.tsrbBC.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsrbBC.Name = "tsrbBC";
            this.tsrbBC.Size = new System.Drawing.Size(36, 22);
            this.tsrbBC.Text = "保存";
            this.tsrbBC.Click += new System.EventHandler(this.TsrbBC_Click);
            // 
            // tsrsTC
            // 
            this.tsrsTC.Name = "tsrsTC";
            this.tsrsTC.Size = new System.Drawing.Size(6, 25);
            // 
            // tsrbTC
            // 
            this.tsrbTC.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsrbTC.Name = "tsrbTC";
            this.tsrbTC.Size = new System.Drawing.Size(36, 22);
            this.tsrbTC.Text = "退出";
            this.tsrbTC.Click += new System.EventHandler(this.TsrbTC_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // lblFLBM
            // 
            this.lblFLBM.AutoSize = true;
            this.lblFLBM.Location = new System.Drawing.Point(40, 44);
            this.lblFLBM.Name = "lblFLBM";
            this.lblFLBM.Size = new System.Drawing.Size(65, 12);
            this.lblFLBM.TabIndex = 1;
            this.lblFLBM.Text = "分类编码：";
            // 
            // txtFLBM
            // 
            this.txtFLBM.Enabled = false;
            this.txtFLBM.Location = new System.Drawing.Point(101, 40);
            this.txtFLBM.Name = "txtFLBM";
            this.txtFLBM.Size = new System.Drawing.Size(151, 21);
            this.txtFLBM.TabIndex = 2;
            // 
            // txtFLMC
            // 
            this.txtFLMC.Location = new System.Drawing.Point(358, 40);
            this.txtFLMC.Name = "txtFLMC";
            this.txtFLMC.Size = new System.Drawing.Size(151, 21);
            this.txtFLMC.TabIndex = 4;
            this.txtFLMC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtFLMC_KeyPress);
            // 
            // lblFLMC
            // 
            this.lblFLMC.AutoSize = true;
            this.lblFLMC.Location = new System.Drawing.Point(297, 44);
            this.lblFLMC.Name = "lblFLMC";
            this.lblFLMC.Size = new System.Drawing.Size(65, 12);
            this.lblFLMC.TabIndex = 3;
            this.lblFLMC.Text = "分类名称：";
            // 
            // lblBJSJ
            // 
            this.lblBJSJ.AutoSize = true;
            this.lblBJSJ.Location = new System.Drawing.Point(297, 195);
            this.lblBJSJ.Name = "lblBJSJ";
            this.lblBJSJ.Size = new System.Drawing.Size(65, 12);
            this.lblBJSJ.TabIndex = 5;
            this.lblBJSJ.Text = "编辑时间：";
            // 
            // lblBJMACDZ
            // 
            this.lblBJMACDZ.AutoSize = true;
            this.lblBJMACDZ.Location = new System.Drawing.Point(303, 156);
            this.lblBJMACDZ.Name = "lblBJMACDZ";
            this.lblBJMACDZ.Size = new System.Drawing.Size(59, 12);
            this.lblBJMACDZ.TabIndex = 11;
            this.lblBJMACDZ.Text = "MAC地址：";
            // 
            // txtBJMACDZ
            // 
            this.txtBJMACDZ.Enabled = false;
            this.txtBJMACDZ.Location = new System.Drawing.Point(358, 152);
            this.txtBJMACDZ.Name = "txtBJMACDZ";
            this.txtBJMACDZ.Size = new System.Drawing.Size(151, 21);
            this.txtBJMACDZ.TabIndex = 14;
            // 
            // txtBJJSJ
            // 
            this.txtBJJSJ.Enabled = false;
            this.txtBJJSJ.Location = new System.Drawing.Point(101, 152);
            this.txtBJJSJ.Name = "txtBJJSJ";
            this.txtBJJSJ.Size = new System.Drawing.Size(151, 21);
            this.txtBJJSJ.TabIndex = 16;
            // 
            // lblBJJSJ
            // 
            this.lblBJJSJ.AutoSize = true;
            this.lblBJJSJ.Location = new System.Drawing.Point(52, 156);
            this.lblBJJSJ.Name = "lblBJJSJ";
            this.lblBJJSJ.Size = new System.Drawing.Size(53, 12);
            this.lblBJJSJ.TabIndex = 15;
            this.lblBJJSJ.Text = "计算机：";
            // 
            // lblBJRY
            // 
            this.lblBJRY.AutoSize = true;
            this.lblBJRY.Location = new System.Drawing.Point(40, 195);
            this.lblBJRY.Name = "lblBJRY";
            this.lblBJRY.Size = new System.Drawing.Size(65, 12);
            this.lblBJRY.TabIndex = 20;
            this.lblBJRY.Text = "编辑人员：";
            // 
            // lblSFQY
            // 
            this.lblSFQY.AutoSize = true;
            this.lblSFQY.Location = new System.Drawing.Point(40, 119);
            this.lblSFQY.Name = "lblSFQY";
            this.lblSFQY.Size = new System.Drawing.Size(65, 12);
            this.lblSFQY.TabIndex = 17;
            this.lblSFQY.Text = "是否启用：";
            // 
            // cmbSFQY
            // 
            this.cmbSFQY.FormattingEnabled = true;
            this.cmbSFQY.Items.AddRange(new object[] {
            "是",
            "否"});
            this.cmbSFQY.Location = new System.Drawing.Point(101, 115);
            this.cmbSFQY.Name = "cmbSFQY";
            this.cmbSFQY.Size = new System.Drawing.Size(151, 20);
            this.cmbSFQY.TabIndex = 34;
            this.cmbSFQY.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CmbSFQY_KeyPress);
            // 
            // txtBJRY
            // 
            this.txtBJRY.Enabled = false;
            this.txtBJRY.Location = new System.Drawing.Point(101, 191);
            this.txtBJRY.Name = "txtBJRY";
            this.txtBJRY.Size = new System.Drawing.Size(151, 21);
            this.txtBJRY.TabIndex = 45;
            // 
            // dtpBJSJ
            // 
            this.dtpBJSJ.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.dtpBJSJ.Enabled = false;
            this.dtpBJSJ.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpBJSJ.Location = new System.Drawing.Point(358, 191);
            this.dtpBJSJ.Name = "dtpBJSJ";
            this.dtpBJSJ.Size = new System.Drawing.Size(151, 21);
            this.dtpBJSJ.TabIndex = 46;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(258, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(11, 12);
            this.label1.TabIndex = 47;
            this.label1.Text = "*";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(515, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(11, 12);
            this.label3.TabIndex = 49;
            this.label3.Text = "*";
            // 
            // lblFFLMC
            // 
            this.lblFFLMC.AutoSize = true;
            this.lblFFLMC.Location = new System.Drawing.Point(28, 83);
            this.lblFFLMC.Name = "lblFFLMC";
            this.lblFFLMC.Size = new System.Drawing.Size(77, 12);
            this.lblFFLMC.TabIndex = 7;
            this.lblFFLMC.Text = "父分类名称：";
            // 
            // cmbFFLMC
            // 
            this.cmbFFLMC.Enabled = false;
            this.cmbFFLMC.FormattingEnabled = true;
            this.cmbFFLMC.Location = new System.Drawing.Point(101, 79);
            this.cmbFFLMC.Name = "cmbFFLMC";
            this.cmbFFLMC.Size = new System.Drawing.Size(151, 20);
            this.cmbFFLMC.TabIndex = 32;
            this.cmbFFLMC.SelectedIndexChanged += new System.EventHandler(this.CmbFFLMC_SelectedIndexChanged);
            // 
            // lblFFLBM
            // 
            this.lblFFLBM.AutoSize = true;
            this.lblFFLBM.Location = new System.Drawing.Point(285, 83);
            this.lblFFLBM.Name = "lblFFLBM";
            this.lblFFLBM.Size = new System.Drawing.Size(77, 12);
            this.lblFFLBM.TabIndex = 50;
            this.lblFFLBM.Text = "父分类编码：";
            // 
            // txtBJIPDZ
            // 
            this.txtBJIPDZ.Enabled = false;
            this.txtBJIPDZ.Location = new System.Drawing.Point(358, 115);
            this.txtBJIPDZ.Name = "txtBJIPDZ";
            this.txtBJIPDZ.Size = new System.Drawing.Size(151, 21);
            this.txtBJIPDZ.TabIndex = 54;
            // 
            // lblBJIPDZ
            // 
            this.lblBJIPDZ.AutoSize = true;
            this.lblBJIPDZ.Location = new System.Drawing.Point(309, 119);
            this.lblBJIPDZ.Name = "lblBJIPDZ";
            this.lblBJIPDZ.Size = new System.Drawing.Size(53, 12);
            this.lblBJIPDZ.TabIndex = 53;
            this.lblBJIPDZ.Text = "IP地址：";
            // 
            // txtBJBZ
            // 
            this.txtBJBZ.Location = new System.Drawing.Point(101, 228);
            this.txtBJBZ.Name = "txtBJBZ";
            this.txtBJBZ.Size = new System.Drawing.Size(408, 21);
            this.txtBJBZ.TabIndex = 56;
            // 
            // lblBZ
            // 
            this.lblBZ.AutoSize = true;
            this.lblBZ.Location = new System.Drawing.Point(40, 232);
            this.lblBZ.Name = "lblBZ";
            this.lblBZ.Size = new System.Drawing.Size(65, 12);
            this.lblBZ.TabIndex = 55;
            this.lblBZ.Text = "编辑备注：";
            // 
            // txtFFLBM
            // 
            this.txtFFLBM.Enabled = false;
            this.txtFFLBM.Location = new System.Drawing.Point(358, 79);
            this.txtFFLBM.Name = "txtFFLBM";
            this.txtFFLBM.Size = new System.Drawing.Size(151, 21);
            this.txtFFLBM.TabIndex = 57;
            // 
            // BJSJZDFL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(542, 272);
            this.Controls.Add(this.txtFFLBM);
            this.Controls.Add(this.txtBJBZ);
            this.Controls.Add(this.lblBZ);
            this.Controls.Add(this.txtBJIPDZ);
            this.Controls.Add(this.lblBJIPDZ);
            this.Controls.Add(this.lblFFLBM);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtpBJSJ);
            this.Controls.Add(this.txtBJRY);
            this.Controls.Add(this.cmbSFQY);
            this.Controls.Add(this.cmbFFLMC);
            this.Controls.Add(this.lblBJRY);
            this.Controls.Add(this.lblSFQY);
            this.Controls.Add(this.txtBJJSJ);
            this.Controls.Add(this.lblBJJSJ);
            this.Controls.Add(this.txtBJMACDZ);
            this.Controls.Add(this.lblBJMACDZ);
            this.Controls.Add(this.lblFFLMC);
            this.Controls.Add(this.lblBJSJ);
            this.Controls.Add(this.txtFLMC);
            this.Controls.Add(this.lblFLMC);
            this.Controls.Add(this.txtFLBM);
            this.Controls.Add(this.lblFLBM);
            this.Controls.Add(this.tsrXZSJZDFL);
            this.Name = "BJSJZDFL";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "编辑数据字典分类";
            this.tsrXZSJZDFL.ResumeLayout(false);
            this.tsrXZSJZDFL.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip tsrXZSJZDFL;
        private System.Windows.Forms.Label lblFLBM;
        private System.Windows.Forms.TextBox txtFLBM;
        private System.Windows.Forms.TextBox txtFLMC;
        private System.Windows.Forms.Label lblFLMC;
        private System.Windows.Forms.Label lblBJSJ;
        private System.Windows.Forms.Label lblBJMACDZ;
        private System.Windows.Forms.TextBox txtBJMACDZ;
        private System.Windows.Forms.TextBox txtBJJSJ;
        private System.Windows.Forms.Label lblBJJSJ;
        private System.Windows.Forms.ToolStripButton tsrbBC;
        private System.Windows.Forms.ToolStripButton tsrbTC;
        private System.Windows.Forms.Label lblBJRY;
        private System.Windows.Forms.Label lblSFQY;
        private System.Windows.Forms.ComboBox cmbSFQY;
        private System.Windows.Forms.TextBox txtBJRY;
        private System.Windows.Forms.DateTimePicker dtpBJSJ;
        private System.Windows.Forms.ToolStripSeparator tsrsBC;
        private System.Windows.Forms.ToolStripSeparator tsrsTC;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblFFLMC;
        private System.Windows.Forms.ComboBox cmbFFLMC;
        private System.Windows.Forms.Label lblFFLBM;
        private System.Windows.Forms.TextBox txtBJIPDZ;
        private System.Windows.Forms.Label lblBJIPDZ;
        private System.Windows.Forms.TextBox txtBJBZ;
        private System.Windows.Forms.Label lblBZ;
        private System.Windows.Forms.TextBox txtFFLBM;
    }
}