﻿using OIMS_DAL;
using OIMS_HOSM_BLL;
using OIMS_HOSM_DAL;
using Sunisoft.IrisSkin;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Windows.Forms;
using OIMS_BLL;

namespace OIMS_HOSM
{
    public partial class SJZDMX : Form
    {
        SqlConnection conn = OIMS_ConfigHelper.GetConnection(OIMS_ConfigHelper.GetConnString());
        DataSet ds = new DataSet();
        DataSet ds1 = new DataSet();
        string message = "";
        public SJZDMX()
        {
            InitializeComponent();
            tsrbXZ.Enabled = false;
            dgvSJZDFL.AutoGenerateColumns = false;
            Display();
        }

        private void TsrbXZ_Click(object sender, EventArgs e)
        {
            XZSJZDMX xzsjzdmx = new XZSJZDMX();
            xzsjzdmx.ShowDialog();
        }

        private void TsrbBJ_Click(object sender, EventArgs e)
        {
            SJZDFL_Helper.SFLBM = dgvSJZDFL.CurrentRow.Cells[0].Value.ToString();
            SJZDFL_Helper.SFLMC = dgvSJZDFL.CurrentRow.Cells[1].Value.ToString();
            SJZDFL_Helper.SFFLBM = dgvSJZDFL.CurrentRow.Cells[2].Value.ToString();
            SJZDFL_Helper.SFFLMC = dgvSJZDFL.CurrentRow.Cells[3].Value.ToString();
            SJZDFL_Helper.ISFQY = Convert.ToBoolean(dgvSJZDFL.CurrentRow.Cells[5].Value.ToString()); ;
            BJSJZDFL bjsjzdfl = new BJSJZDFL();
            bjsjzdfl.ShowDialog();
        }

        private void TsrbTC_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        SkinEngine se = new SkinEngine();
        private void TsrbCX_Click(object sender, EventArgs e)
        {
            if (txtKSCZFL.Text != "")
            {
                if (rdoFLBM.Checked)
                {
                    ds.Clear();
                    string strSql = "select sFLBM,sFLMC,sFFLBM,sFFLMC,iSFQY,sIPDZ,sJSJ,sMACDZ,sXZRY,dXZSJ,sBZ " +
                "from SJZDFL where sFLBM like '%" + txtKSCZFL.Text.ToString().Trim() + "%' order by sFLBM";
                    SqlDataAdapter sda = new SqlDataAdapter(strSql, conn);
                    conn.Open();
                    sda.Fill(ds, "SJZDFL");
                    dgvSJZDFL.DataSource = ds.Tables["SJZDFL"];

                    ssrlTJ.Text = "共" + ds.Tables["SJZDFL"].Rows.Count.ToString() + "个分类";
                    try
                    {

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
                else
                {
                    ds.Clear();
                    string strSql = "select sFLBM,sFLMC,sFFLBM,sFFLMC,iSFQY,sIPDZ,sJSJ,sMACDZ,sXZRY,dXZSJ,sBZ " +
                "from SJZDFL where sFLMC like '%" + txtKSCZFL.Text.ToString().Trim() + "%' order by sFLBM";
                    SqlDataAdapter sda = new SqlDataAdapter(strSql, conn);
                    conn.Open();
                    sda.Fill(ds, "SJZDFL");
                    dgvSJZDFL.DataSource = ds.Tables["SJZDFL"];

                    ssrlTJ.Text = "共" + ds.Tables["SJZDFL"].Rows.Count.ToString() + "个分类";
                    try
                    {

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
            }
            else
            {
                ds.Clear();
                Display();
            }
        }

        public void Display()
        {
            string strSql = "select sMXBM,sMXMC,sFLBM,sFLMC,iSFQY,sIPDZ,sJSJ,sMACDZ,sXZRY,dXZSJ,sBZ,sPYCZM " +
                "from SJZDMX order by sFLBM,sMXBM";
            try
            {
                SqlDataAdapter sda = new SqlDataAdapter(strSql, conn);
                conn.Open();
                sda.Fill(ds, "SJZDMX");
                dgvSJZDFL.DataSource = ds.Tables["SJZDMX"];
                ssrlTJ.Text = "共" + ds.Tables["SJZDMX"].Rows.Count.ToString() + "个分类";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                conn.Close();
            }
        }

        //设置编号
        private void DgvSJZDFL_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            var grid = sender as DataGridView;
            var rowIdx = (e.RowIndex + 1).ToString();

            var centerFormat = new StringFormat()
            {
                Alignment = StringAlignment.Center,
                LineAlignment = StringAlignment.Center
            };

            var headerBounds = new Rectangle(e.RowBounds.Left, e.RowBounds.Top, grid.RowHeadersWidth, e.RowBounds.Height);
            e.Graphics.DrawString(rowIdx, this.Font, SystemBrushes.ControlText, headerBounds, centerFormat);
        }

        private void TsrbSX_Click(object sender, EventArgs e)
        {
            ds.Clear();
            Display();
        }

        private void BtnSJDC_Click(object sender, EventArgs e)
        {
            try
            {
                SJDC sjdc = new SJDC();
                sjdc.ExportDataGridview(dgvSJZDFL, true);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        //通过停用启用查询分类编码的数据
        private void CmbQYCX_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbQYCX.Text == "全部")
            {
                ds.Clear();
                Display();
            }
            else if (cmbQYCX.Text == "启用")
            {
                ds.Clear();
                string strSql = "select sFLBM,sFLMC,sFFLBM,sFFLMC,iSFQY,sIPDZ,sJSJ,sMACDZ,sXZRY,dXZSJ,sBZ " +
                "from SJZDFL where iSFQY = 1 order by sFLBM";
                try
                {
                    SqlDataAdapter sda = new SqlDataAdapter(strSql, conn);
                    conn.Open();
                    sda.Fill(ds, "SJZDFL");
                    dgvSJZDFL.DataSource = ds.Tables["SJZDFL"];
                    ssrlTJ.Text = "共" + ds.Tables["SJZDFL"].Rows.Count.ToString() + "个分类";
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                finally
                {
                    conn.Close();
                }
            }
            else
            {
                ds.Clear();
                string strSql = "select sFLBM,sFLMC,sFFLBM,sFFLMC,iSFQY,sIPDZ,sJSJ,sMACDZ,sXZRY,dXZSJ,sBZ " +
                "from SJZDFL where iSFQY = 0 order by sFLBM";
                try
                {
                    SqlDataAdapter sda = new SqlDataAdapter(strSql, conn);
                    conn.Open();
                    sda.Fill(ds, "SJZDFL");
                    dgvSJZDFL.DataSource = ds.Tables["SJZDFL"];
                    ssrlTJ.Text = "共" + ds.Tables["SJZDFL"].Rows.Count.ToString() + "个分类";
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
                finally
                {
                    conn.Close();
                }
            }
        }

        private void TxtKSCZFL_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                if (txtKSCZFL.Text != "")
                {
                    if (rdoFLBM.Checked)
                    {
                        ds.Clear();
                        string strSql = "select sFLBM,sFLMC,sFFLBM,sFFLMC,iSFQY,sIPDZ,sJSJ,sMACDZ,sXZRY,dXZSJ,sBZ " +
                    "from SJZDFL where sFLBM like '%" + txtKSCZFL.Text.ToString().Trim() + "%' order by sFLBM";
                        try
                        {
                            SqlDataAdapter sda = new SqlDataAdapter(strSql, conn);
                            conn.Open();
                            sda.Fill(ds, "SJZDFL");
                            dgvSJZDFL.DataSource = ds.Tables["SJZDFL"];

                            ssrlTJ.Text = "共" + ds.Tables["SJZDFL"].Rows.Count.ToString() + "个分类";
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                        finally
                        {
                            conn.Close();
                        }
                    }
                    else
                    {
                        ds.Clear();
                        string strSql = "select sFLBM,sFLMC,sFFLBM,sFFLMC,iSFQY,sIPDZ,sJSJ,sMACDZ,sXZRY,dXZSJ,sBZ " +
                    "from SJZDFL where sFLMC like '%" + txtKSCZFL.Text.ToString().Trim() + "%' order by sFLBM";
                        
                        try
                        {
                            SqlDataAdapter sda = new SqlDataAdapter(strSql, conn);
                            conn.Open();
                            sda.Fill(ds, "SJZDFL");
                            dgvSJZDFL.DataSource = ds.Tables["SJZDFL"];

                            ssrlTJ.Text = "共" + ds.Tables["SJZDFL"].Rows.Count.ToString() + "个分类";
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }
                        finally
                        {
                            conn.Close();
                        }
                    }
                }
                else
                {
                    ds.Clear();
                    Display();
                }
            }
        }

        private void SJZDMX_Load(object sender, EventArgs e)
        {
            string strSql = "select sFLBM,sFLMC,sFFLBM from SJZDFL";
            SqlDataAdapter sda = new SqlDataAdapter(strSql, conn);
            conn.Open();
            sda.Fill(ds1, "SJZDFL");
            DataTable dt = ds1.Tables["SJZDFL"];
            InitModuleTree(dt);
        }

        //绑定TrreView
        private void InitModuleTree(DataTable dt)
        {
            //清空treeview上所有节点
            this.tvwZDFL.Nodes.Clear();
            int[] gen = new int[dt.Rows.Count]; //用于存储父节点Tag
            int[] zi = new int[dt.Rows.Count];  //用于存储子节点Tag
            for (int i = 0; i < gen.Length; i++)
            {
                string zhi = dt.Rows[i][0].ToString();//获取节点Tag值
                if (zhi.Length > 2)   //表示是子节点
                {
                    gen[i] = int.Parse(zhi.ToString().Substring(0,2));//存取根节点的编码
                    //MessageBox.Show(gen[i].ToString());
                    zi[i] = int.Parse(zhi.ToString());   //存取子节点的编码
                    //MessageBox.Show(zi[i].ToString());
                }
                else    //表示是根节点   eg：2
                {
                    //将所有父节点加到treeview上
                    zi[i] = int.Parse(zhi);
                    TreeNode nodeParent = new TreeNode
                    {
                        Tag = (zi[i]).ToString(),
                        Text = dt.Rows[i][1].ToString()
                    };
                    //nodeParent.Tag = (zi[i]).ToString();
                    //nodeParent.Text = dt.Rows[i][1].ToString();

                    tvwZDFL.Nodes.Add(nodeParent);
                }
            }
            BindChildNote(dt, gen, zi);
        }

        //绑定子节点
        private void BindChildNote(DataTable dt, int[] gen, int[] zi)
        {
            for (int i = 0; i < gen.Length; i++)
            {
                if (gen[i] != 0 && zi[i] != 0)        //遍历所有节点，找到所有子节点
                {
                    TreeNode childNode = new TreeNode();
                    foreach (TreeNode item in tvwZDFL.Nodes)   //遍历treeview上所有父节点
                    {
                        //MessageBox.Show(gen[i].ToString());
                        //MessageBox.Show(item.Tag.ToString());
                        if (item.Tag.ToString() == gen[i].ToString())  //找到当前子节点的父节点
                        {
                            childNode.Tag = zi[i].ToString();
                            //MessageBox.Show(childNode.Tag.ToString());
                            childNode.Text = dt.Rows[i][1].ToString();
                            //MessageBox.Show(childNode.Text);
                            item.Nodes.Add(childNode);
                        }
                    }
                }
            }
            tvwZDFL.ExpandAll();      //展开整棵树
        }

        private void TvwZDFL_AfterSelect(object sender, TreeViewEventArgs e)
        {
            //获取节点的显示名称
            //MessageBox.Show(tvwZDFL.SelectedNode.Text);
            //获取节点的ID
            //MessageBox.Show(tvwZDFL.SelectedNode.Tag.ToString());
            SJZDFL_Helper.SFLBM = tvwZDFL.SelectedNode.Tag.ToString();
            SJZDFL_Helper.SFLMC = tvwZDFL.SelectedNode.Text.ToString();
            Display1(tvwZDFL.SelectedNode.Tag.ToString());
            tsrbXZ.Enabled = true;
        }

        public void Display1(string sFLBM)
        {
            ds.Clear();
            conn.Close();
            if (tvwZDFL.SelectedNode.Tag.ToString().Length > 2)
            {
                if (SJZD_BLL.IsValidataFLBMMX(sFLBM,ref message))
                {
                    string strSql = "select sMXBM,sMXMC,sFLBM,sFLMC,iSFQY,sIPDZ,sJSJ,sMACDZ,sXZRY,dXZSJ,sBZ,sPYCZM " + "from SJZDMX where sFLBM = '" + sFLBM + "' order by sFLBM,sMXBM";
                    
                    try
                    {
                        SqlDataAdapter sda = new SqlDataAdapter(strSql, conn);
                        conn.Open();
                        sda.Fill(ds, "SJZDMX");
                        dgvSJZDFL.DataSource = ds.Tables["SJZDMX"];

                        ssrlTJ.Text = "共" + ds.Tables["SJZDMX"].Rows.Count.ToString() + "个分类";
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.ToString());
                    }
                    finally
                    {
                        conn.Close();
                    }
                }
                else
                {
                    MessageBox.Show("该项目无明细", "提示",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                }
            }
            else
            {
                MessageBox.Show("您点击的是节点项目，无明细！，如需添加请同管理员联系", "提示",MessageBoxButtons.OK,MessageBoxIcon.Warning);
            }
        }
    }
}
