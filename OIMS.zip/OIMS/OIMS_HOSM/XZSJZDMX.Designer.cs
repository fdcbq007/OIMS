﻿namespace OIMS_HOSM
{
    partial class XZSJZDMX
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tsrXZSJZDFL = new System.Windows.Forms.ToolStrip();
            this.tsrsXZ = new System.Windows.Forms.ToolStripSeparator();
            this.tsrbXZ = new System.Windows.Forms.ToolStripButton();
            this.tsrsBC = new System.Windows.Forms.ToolStripSeparator();
            this.tsrbBC = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.tsrbTC = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.lblMXBM = new System.Windows.Forms.Label();
            this.txtMXBM = new System.Windows.Forms.TextBox();
            this.txtMXMC = new System.Windows.Forms.TextBox();
            this.lblMXMC = new System.Windows.Forms.Label();
            this.lblXZSJ = new System.Windows.Forms.Label();
            this.lblMACDZ = new System.Windows.Forms.Label();
            this.txtMACDZ = new System.Windows.Forms.TextBox();
            this.txtJSJ = new System.Windows.Forms.TextBox();
            this.lblJSJ = new System.Windows.Forms.Label();
            this.lblXZRY = new System.Windows.Forms.Label();
            this.lblSFQY = new System.Windows.Forms.Label();
            this.cmbSFQY = new System.Windows.Forms.ComboBox();
            this.txtXZRY = new System.Windows.Forms.TextBox();
            this.dtpXZSJ = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblFLMC = new System.Windows.Forms.Label();
            this.lblFLBM = new System.Windows.Forms.Label();
            this.txtIPDZ = new System.Windows.Forms.TextBox();
            this.lblIPDZ = new System.Windows.Forms.Label();
            this.txtBZ = new System.Windows.Forms.TextBox();
            this.lblBZ = new System.Windows.Forms.Label();
            this.txtFLBM = new System.Windows.Forms.TextBox();
            this.txtFLMC = new System.Windows.Forms.TextBox();
            this.tsrXZSJZDFL.SuspendLayout();
            this.SuspendLayout();
            // 
            // tsrXZSJZDFL
            // 
            this.tsrXZSJZDFL.BackColor = System.Drawing.SystemColors.MenuBar;
            this.tsrXZSJZDFL.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsrsXZ,
            this.tsrbXZ,
            this.tsrsBC,
            this.tsrbBC,
            this.toolStripSeparator3,
            this.tsrbTC,
            this.toolStripSeparator4});
            this.tsrXZSJZDFL.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.tsrXZSJZDFL.Location = new System.Drawing.Point(0, 0);
            this.tsrXZSJZDFL.Name = "tsrXZSJZDFL";
            this.tsrXZSJZDFL.Size = new System.Drawing.Size(542, 25);
            this.tsrXZSJZDFL.TabIndex = 0;
            this.tsrXZSJZDFL.Text = "新增数据字典分类工具条";
            // 
            // tsrsXZ
            // 
            this.tsrsXZ.Name = "tsrsXZ";
            this.tsrsXZ.Size = new System.Drawing.Size(6, 25);
            // 
            // tsrbXZ
            // 
            this.tsrbXZ.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsrbXZ.Name = "tsrbXZ";
            this.tsrbXZ.Size = new System.Drawing.Size(36, 22);
            this.tsrbXZ.Text = "新增";
            this.tsrbXZ.Click += new System.EventHandler(this.TsrbXZ_Click);
            // 
            // tsrsBC
            // 
            this.tsrsBC.Name = "tsrsBC";
            this.tsrsBC.Size = new System.Drawing.Size(6, 25);
            // 
            // tsrbBC
            // 
            this.tsrbBC.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsrbBC.Name = "tsrbBC";
            this.tsrbBC.Size = new System.Drawing.Size(36, 22);
            this.tsrbBC.Text = "保存";
            this.tsrbBC.Click += new System.EventHandler(this.TsrbBC_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // tsrbTC
            // 
            this.tsrbTC.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsrbTC.Name = "tsrbTC";
            this.tsrbTC.Size = new System.Drawing.Size(36, 22);
            this.tsrbTC.Text = "退出";
            this.tsrbTC.Click += new System.EventHandler(this.TsrbTC_Click_1);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // lblMXBM
            // 
            this.lblMXBM.AutoSize = true;
            this.lblMXBM.Location = new System.Drawing.Point(40, 44);
            this.lblMXBM.Name = "lblMXBM";
            this.lblMXBM.Size = new System.Drawing.Size(65, 12);
            this.lblMXBM.TabIndex = 1;
            this.lblMXBM.Text = "明细编码：";
            // 
            // txtMXBM
            // 
            this.txtMXBM.Location = new System.Drawing.Point(101, 40);
            this.txtMXBM.Name = "txtMXBM";
            this.txtMXBM.Size = new System.Drawing.Size(151, 21);
            this.txtMXBM.TabIndex = 2;
            this.txtMXBM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtFLBM_KeyPress);
            // 
            // txtMXMC
            // 
            this.txtMXMC.Location = new System.Drawing.Point(358, 40);
            this.txtMXMC.Name = "txtMXMC";
            this.txtMXMC.Size = new System.Drawing.Size(151, 21);
            this.txtMXMC.TabIndex = 4;
            this.txtMXMC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TxtFLMC_KeyPress);
            // 
            // lblMXMC
            // 
            this.lblMXMC.AutoSize = true;
            this.lblMXMC.Location = new System.Drawing.Point(297, 44);
            this.lblMXMC.Name = "lblMXMC";
            this.lblMXMC.Size = new System.Drawing.Size(65, 12);
            this.lblMXMC.TabIndex = 3;
            this.lblMXMC.Text = "明细名称：";
            // 
            // lblXZSJ
            // 
            this.lblXZSJ.AutoSize = true;
            this.lblXZSJ.Location = new System.Drawing.Point(297, 195);
            this.lblXZSJ.Name = "lblXZSJ";
            this.lblXZSJ.Size = new System.Drawing.Size(65, 12);
            this.lblXZSJ.TabIndex = 5;
            this.lblXZSJ.Text = "新增时间：";
            // 
            // lblMACDZ
            // 
            this.lblMACDZ.AutoSize = true;
            this.lblMACDZ.Location = new System.Drawing.Point(303, 156);
            this.lblMACDZ.Name = "lblMACDZ";
            this.lblMACDZ.Size = new System.Drawing.Size(59, 12);
            this.lblMACDZ.TabIndex = 11;
            this.lblMACDZ.Text = "MAC地址：";
            // 
            // txtMACDZ
            // 
            this.txtMACDZ.Enabled = false;
            this.txtMACDZ.Location = new System.Drawing.Point(358, 152);
            this.txtMACDZ.Name = "txtMACDZ";
            this.txtMACDZ.Size = new System.Drawing.Size(151, 21);
            this.txtMACDZ.TabIndex = 14;
            // 
            // txtJSJ
            // 
            this.txtJSJ.Enabled = false;
            this.txtJSJ.Location = new System.Drawing.Point(101, 152);
            this.txtJSJ.Name = "txtJSJ";
            this.txtJSJ.Size = new System.Drawing.Size(151, 21);
            this.txtJSJ.TabIndex = 16;
            // 
            // lblJSJ
            // 
            this.lblJSJ.AutoSize = true;
            this.lblJSJ.Location = new System.Drawing.Point(52, 156);
            this.lblJSJ.Name = "lblJSJ";
            this.lblJSJ.Size = new System.Drawing.Size(53, 12);
            this.lblJSJ.TabIndex = 15;
            this.lblJSJ.Text = "计算机：";
            // 
            // lblXZRY
            // 
            this.lblXZRY.AutoSize = true;
            this.lblXZRY.Location = new System.Drawing.Point(40, 195);
            this.lblXZRY.Name = "lblXZRY";
            this.lblXZRY.Size = new System.Drawing.Size(65, 12);
            this.lblXZRY.TabIndex = 20;
            this.lblXZRY.Text = "新增人员：";
            // 
            // lblSFQY
            // 
            this.lblSFQY.AutoSize = true;
            this.lblSFQY.Location = new System.Drawing.Point(40, 119);
            this.lblSFQY.Name = "lblSFQY";
            this.lblSFQY.Size = new System.Drawing.Size(65, 12);
            this.lblSFQY.TabIndex = 17;
            this.lblSFQY.Text = "是否启用：";
            // 
            // cmbSFQY
            // 
            this.cmbSFQY.FormattingEnabled = true;
            this.cmbSFQY.Items.AddRange(new object[] {
            "是",
            "否"});
            this.cmbSFQY.Location = new System.Drawing.Point(101, 115);
            this.cmbSFQY.Name = "cmbSFQY";
            this.cmbSFQY.Size = new System.Drawing.Size(151, 20);
            this.cmbSFQY.TabIndex = 34;
            this.cmbSFQY.SelectedIndexChanged += new System.EventHandler(this.CmbSFQY_SelectedIndexChanged);
            this.cmbSFQY.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CmbSFQY_KeyPress);
            // 
            // txtXZRY
            // 
            this.txtXZRY.Enabled = false;
            this.txtXZRY.Location = new System.Drawing.Point(101, 191);
            this.txtXZRY.Name = "txtXZRY";
            this.txtXZRY.Size = new System.Drawing.Size(151, 21);
            this.txtXZRY.TabIndex = 45;
            // 
            // dtpXZSJ
            // 
            this.dtpXZSJ.CustomFormat = "yyyy-MM-dd HH:mm:ss";
            this.dtpXZSJ.Enabled = false;
            this.dtpXZSJ.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpXZSJ.Location = new System.Drawing.Point(358, 191);
            this.dtpXZSJ.Name = "dtpXZSJ";
            this.dtpXZSJ.Size = new System.Drawing.Size(151, 21);
            this.dtpXZSJ.TabIndex = 46;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(258, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(11, 12);
            this.label1.TabIndex = 47;
            this.label1.Text = "*";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Red;
            this.label3.Location = new System.Drawing.Point(515, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(11, 12);
            this.label3.TabIndex = 49;
            this.label3.Text = "*";
            // 
            // lblFLMC
            // 
            this.lblFLMC.AutoSize = true;
            this.lblFLMC.Location = new System.Drawing.Point(40, 83);
            this.lblFLMC.Name = "lblFLMC";
            this.lblFLMC.Size = new System.Drawing.Size(65, 12);
            this.lblFLMC.TabIndex = 7;
            this.lblFLMC.Text = "分类名称：";
            // 
            // lblFLBM
            // 
            this.lblFLBM.AutoSize = true;
            this.lblFLBM.Location = new System.Drawing.Point(297, 83);
            this.lblFLBM.Name = "lblFLBM";
            this.lblFLBM.Size = new System.Drawing.Size(65, 12);
            this.lblFLBM.TabIndex = 50;
            this.lblFLBM.Text = "分类编码：";
            // 
            // txtIPDZ
            // 
            this.txtIPDZ.Enabled = false;
            this.txtIPDZ.Location = new System.Drawing.Point(358, 115);
            this.txtIPDZ.Name = "txtIPDZ";
            this.txtIPDZ.Size = new System.Drawing.Size(151, 21);
            this.txtIPDZ.TabIndex = 54;
            // 
            // lblIPDZ
            // 
            this.lblIPDZ.AutoSize = true;
            this.lblIPDZ.Location = new System.Drawing.Point(309, 119);
            this.lblIPDZ.Name = "lblIPDZ";
            this.lblIPDZ.Size = new System.Drawing.Size(53, 12);
            this.lblIPDZ.TabIndex = 53;
            this.lblIPDZ.Text = "IP地址：";
            // 
            // txtBZ
            // 
            this.txtBZ.Location = new System.Drawing.Point(101, 228);
            this.txtBZ.Name = "txtBZ";
            this.txtBZ.Size = new System.Drawing.Size(408, 21);
            this.txtBZ.TabIndex = 56;
            // 
            // lblBZ
            // 
            this.lblBZ.AutoSize = true;
            this.lblBZ.Location = new System.Drawing.Point(64, 232);
            this.lblBZ.Name = "lblBZ";
            this.lblBZ.Size = new System.Drawing.Size(41, 12);
            this.lblBZ.TabIndex = 55;
            this.lblBZ.Text = "备注：";
            // 
            // txtFLBM
            // 
            this.txtFLBM.Enabled = false;
            this.txtFLBM.Location = new System.Drawing.Point(358, 79);
            this.txtFLBM.Name = "txtFLBM";
            this.txtFLBM.Size = new System.Drawing.Size(151, 21);
            this.txtFLBM.TabIndex = 57;
            // 
            // txtFLMC
            // 
            this.txtFLMC.Enabled = false;
            this.txtFLMC.Location = new System.Drawing.Point(101, 79);
            this.txtFLMC.Name = "txtFLMC";
            this.txtFLMC.Size = new System.Drawing.Size(151, 21);
            this.txtFLMC.TabIndex = 58;
            // 
            // XZSJZDMX
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(542, 272);
            this.Controls.Add(this.txtFLMC);
            this.Controls.Add(this.txtFLBM);
            this.Controls.Add(this.txtBZ);
            this.Controls.Add(this.lblBZ);
            this.Controls.Add(this.txtIPDZ);
            this.Controls.Add(this.lblIPDZ);
            this.Controls.Add(this.lblFLBM);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtpXZSJ);
            this.Controls.Add(this.txtXZRY);
            this.Controls.Add(this.cmbSFQY);
            this.Controls.Add(this.lblXZRY);
            this.Controls.Add(this.lblSFQY);
            this.Controls.Add(this.txtJSJ);
            this.Controls.Add(this.lblJSJ);
            this.Controls.Add(this.txtMACDZ);
            this.Controls.Add(this.lblMACDZ);
            this.Controls.Add(this.lblFLMC);
            this.Controls.Add(this.lblXZSJ);
            this.Controls.Add(this.txtMXMC);
            this.Controls.Add(this.lblMXMC);
            this.Controls.Add(this.txtMXBM);
            this.Controls.Add(this.lblMXBM);
            this.Controls.Add(this.tsrXZSJZDFL);
            this.Name = "XZSJZDMX";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "新增数据字典明细";
            this.tsrXZSJZDFL.ResumeLayout(false);
            this.tsrXZSJZDFL.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip tsrXZSJZDFL;
        private System.Windows.Forms.ToolStripSeparator tsrsXZ;
        private System.Windows.Forms.Label lblMXBM;
        private System.Windows.Forms.TextBox txtMXBM;
        private System.Windows.Forms.TextBox txtMXMC;
        private System.Windows.Forms.Label lblMXMC;
        private System.Windows.Forms.Label lblXZSJ;
        private System.Windows.Forms.Label lblMACDZ;
        private System.Windows.Forms.TextBox txtMACDZ;
        private System.Windows.Forms.TextBox txtJSJ;
        private System.Windows.Forms.Label lblJSJ;
        private System.Windows.Forms.ToolStripButton tsrbXZ;
        private System.Windows.Forms.ToolStripButton tsrbBC;
        private System.Windows.Forms.ToolStripButton tsrbTC;
        private System.Windows.Forms.Label lblXZRY;
        private System.Windows.Forms.Label lblSFQY;
        private System.Windows.Forms.ComboBox cmbSFQY;
        private System.Windows.Forms.TextBox txtXZRY;
        private System.Windows.Forms.DateTimePicker dtpXZSJ;
        private System.Windows.Forms.ToolStripSeparator tsrsBC;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblFLMC;
        private System.Windows.Forms.Label lblFLBM;
        private System.Windows.Forms.TextBox txtIPDZ;
        private System.Windows.Forms.Label lblIPDZ;
        private System.Windows.Forms.TextBox txtBZ;
        private System.Windows.Forms.Label lblBZ;
        private System.Windows.Forms.TextBox txtFLBM;
        private System.Windows.Forms.TextBox txtFLMC;
    }
}