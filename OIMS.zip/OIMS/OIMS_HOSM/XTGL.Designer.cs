﻿namespace OIMS_HOSM
{
    partial class XTGL
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(XTGL));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiUserManage = new System.Windows.Forms.ToolStripMenuItem();
            this.分店设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.岗位设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.人事管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.验光师设置ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.客户机管理ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiWYZYHZ = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiSJZD = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiSJZDFL = new System.Windows.Forms.ToolStripMenuItem();
            this.系统维护ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.吉图数据ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.集团数据下载ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlXTGL = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.系统维护ToolStripMenuItem,
            this.吉图数据ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1111, 25);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiUserManage,
            this.分店设置ToolStripMenuItem,
            this.岗位设置ToolStripMenuItem,
            this.人事管理ToolStripMenuItem,
            this.验光师设置ToolStripMenuItem,
            this.客户机管理ToolStripMenuItem,
            this.tsmiWYZYHZ,
            this.tsmiSJZD,
            this.tsmiSJZDFL});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(68, 21);
            this.toolStripMenuItem1.Text = "基础维护";
            // 
            // tsmiUserManage
            // 
            this.tsmiUserManage.Name = "tsmiUserManage";
            this.tsmiUserManage.Size = new System.Drawing.Size(148, 22);
            this.tsmiUserManage.Text = "用户管理";
            this.tsmiUserManage.Click += new System.EventHandler(this.TsmiUserManage_Click);
            // 
            // 分店设置ToolStripMenuItem
            // 
            this.分店设置ToolStripMenuItem.Name = "分店设置ToolStripMenuItem";
            this.分店设置ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.分店设置ToolStripMenuItem.Text = "分店设置";
            // 
            // 岗位设置ToolStripMenuItem
            // 
            this.岗位设置ToolStripMenuItem.Name = "岗位设置ToolStripMenuItem";
            this.岗位设置ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.岗位设置ToolStripMenuItem.Text = "岗位设置";
            // 
            // 人事管理ToolStripMenuItem
            // 
            this.人事管理ToolStripMenuItem.Name = "人事管理ToolStripMenuItem";
            this.人事管理ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.人事管理ToolStripMenuItem.Text = "用户资料管理";
            // 
            // 验光师设置ToolStripMenuItem
            // 
            this.验光师设置ToolStripMenuItem.Name = "验光师设置ToolStripMenuItem";
            this.验光师设置ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.验光师设置ToolStripMenuItem.Text = "验光室设置";
            // 
            // 客户机管理ToolStripMenuItem
            // 
            this.客户机管理ToolStripMenuItem.Name = "客户机管理ToolStripMenuItem";
            this.客户机管理ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.客户机管理ToolStripMenuItem.Text = "客户机管理";
            // 
            // tsmiWYZYHZ
            // 
            this.tsmiWYZYHZ.Name = "tsmiWYZYHZ";
            this.tsmiWYZYHZ.Size = new System.Drawing.Size(148, 22);
            this.tsmiWYZYHZ.Text = "温医住院汇总";
            this.tsmiWYZYHZ.Click += new System.EventHandler(this.TsmiWYZYHZ_Click);
            // 
            // tsmiSJZD
            // 
            this.tsmiSJZD.Name = "tsmiSJZD";
            this.tsmiSJZD.Size = new System.Drawing.Size(148, 22);
            this.tsmiSJZD.Text = "数据字典";
            this.tsmiSJZD.Click += new System.EventHandler(this.TsmiSJZD_Click);
            // 
            // tsmiSJZDFL
            // 
            this.tsmiSJZDFL.Name = "tsmiSJZDFL";
            this.tsmiSJZDFL.Size = new System.Drawing.Size(148, 22);
            this.tsmiSJZDFL.Text = "数据字典分类";
            this.tsmiSJZDFL.Click += new System.EventHandler(this.TsmiSJZDFL_Click);
            // 
            // 系统维护ToolStripMenuItem
            // 
            this.系统维护ToolStripMenuItem.Name = "系统维护ToolStripMenuItem";
            this.系统维护ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.系统维护ToolStripMenuItem.Text = "系统维护";
            // 
            // 吉图数据ToolStripMenuItem
            // 
            this.吉图数据ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.集团数据下载ToolStripMenuItem});
            this.吉图数据ToolStripMenuItem.Name = "吉图数据ToolStripMenuItem";
            this.吉图数据ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
            this.吉图数据ToolStripMenuItem.Text = "数据下载";
            // 
            // 集团数据下载ToolStripMenuItem
            // 
            this.集团数据下载ToolStripMenuItem.Name = "集团数据下载ToolStripMenuItem";
            this.集团数据下载ToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.集团数据下载ToolStripMenuItem.Text = "集团数据下载";
            // 
            // pnlXTGL
            // 
            this.pnlXTGL.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlXTGL.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlXTGL.Location = new System.Drawing.Point(0, 25);
            this.pnlXTGL.Name = "pnlXTGL";
            this.pnlXTGL.Size = new System.Drawing.Size(1111, 643);
            this.pnlXTGL.TabIndex = 1;
            // 
            // XTGL
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::OIMS_HOSM.Properties.Resources.背景图;
            this.ClientSize = new System.Drawing.Size(1111, 668);
            this.Controls.Add(this.pnlXTGL);
            this.Controls.Add(this.menuStrip1);
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "XTGL";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "系统管理";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem 系统维护ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 吉图数据ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsmiUserManage;
        private System.Windows.Forms.ToolStripMenuItem 分店设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 岗位设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 人事管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 验光师设置ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 客户机管理ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 集团数据下载ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsmiWYZYHZ;
        private System.Windows.Forms.ToolStripMenuItem tsmiSJZD;
        private System.Windows.Forms.ToolStripMenuItem tsmiSJZDFL;
        private System.Windows.Forms.Panel pnlXTGL;
    }
}