﻿using OIMS_BLL;
using OIMS_DAL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OIMS_HOSM_BLL
{
    public class YHGL_BLL
    {
        /// <summary> 
        /// 1、校验输入的用户ID和密码是否完整
        /// 2、校验输入的用户ID和密码是否是数字和字母 
        public static bool IsValidataInput(string LoginUserId)
        {

            if (0 == LoginUserId.Length)
            {
                //MessageBox.Show(null, "请填写完整！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                
                return false;
            }
            else if (Validator.IsIntegerAndEnglishCharacter(LoginUserId) == false)
            {
                MessageBox.Show("账号格式输入有误，请重新输入！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            else
            {
                return true;
            }
        }
        /// <summary> 
        /// 1、判断输入的用户名和密码是否在数据库中存在
        public static bool IsValidataUserId(string LoginUserId, ref string message)
        {
            string sqlStr = String.Format("select count(*) from Users where sDLZH = '{0}'",
                LoginUserId);
            int i = LoginHelper.ShowSelect(sqlStr);
            if (i >= 1)
            {
                message = "用户已存在，请重新输入";
                return false;
            }
            else
            {
                return true;
            }
        }

        //通过生日获得年龄值
        public static int GetAgeByBirthdate(DateTime birthdate)
        {
            DateTime now = DateTime.Now;
            int age = now.Year - birthdate.Year;
            if (now.Month < birthdate.Month || (now.Month == birthdate.Month && now.Day < birthdate.Day))
            {
                age--;
            }
            return age < 0 ? 0 : age;
        }

        public static bool IsValidataSJZDMC(string sFLMC, ref string message)
        {
            string sqlStr = String.Format("select count(*) from SJZDFL where sFLMC = '{0}'",
                sFLMC);
            int i = LoginHelper.ShowSelect(sqlStr);
            if (i >= 1)
            {
                message = "用户已存在，请重新输入";
                return false;
            }
            else
            {
                return true;
            }
        }

        public static bool IsValidataInputSJZDMC(string sFLMC)
        {

            if (0 == sFLMC.Length)
            {
                //MessageBox.Show(null, "请填写完整！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                return false;
            }
            else
            {
                return true;
            }
        }
    }
}
