﻿using OIMS_DAL;
using OIMS_HOSM_DAL;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OIMS_HOSM_BLL
{
    public class SJZD_BLL
    {
        /// <summary> 
        /// 1、校验输入的用户ID和密码是否完整
        /// 2、校验输入的用户ID和密码是否是数字和字母   
        public static bool IsValidataFLBM(string sFLBM, ref string message)
        {
            string sqlStr = String.Format("select count(*) from SJZDFL where sFLBM = '{0}'",
                sFLBM);
            int i = LoginHelper.ShowSelect(sqlStr);
            if (i >= 1)
            {
                message = "分类编码已存在，请重新输入";
                return false;
            }
            else
            {
                return true;
            }
        }

        public static bool IsValidataFLMC(string sFLMC, ref string message)
        {
            string sqlStr = String.Format("select count(*) from SJZDFL where sFLMC = '{0}'",
                sFLMC);
            int i = LoginHelper.ShowSelect(sqlStr);
            if (i >= 1)
            {
                message = "分类名称已存在，请重新输入";
                return false;
            }
            else
            {
                return true;
            }
        }

        public static bool IsValidataBSM(string sBSM, ref string message)
        {
            string sqlStr = String.Format("select count(*) from SJZDFL where sBSM = '{0}'",
                sBSM);
            int i = LoginHelper.ShowSelect(sqlStr);
            if (i >= 1)
            {
                message = "标识码已存在，请重新输入";
                return false;
            }
            else
            {
                return true;
            }
        }

        public static bool IsValidataFLMC1(string sFLMC, ref string message)
        {
            string sqlStr = String.Format("select count(*) from SJZDFL where sFLMC = '{0}'",
                sFLMC);
            int i = LoginHelper.ShowSelect(sqlStr);
            if (i >= 1)
            {
                message = "分类名称已存在，请重新输入";
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool IsValidataFLBMMX(string sFLBM, ref string message)
        {
            string sqlStr = String.Format("select count(*) from SJZDMX where sFLBM = '{0}'",
                sFLBM);
            int i = LoginHelper.ShowSelect(sqlStr);
            if (i >= 1)
            {
                return true;
            }
            else
            {
                message = "此项目无对应的明细！";
                return false;
            }
        }

        public static bool IsValidataInputFLBM(string sFLBM)
        {

            if (0 == sFLBM.Length)
            {
                //MessageBox.Show(null, "请填写完整！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                return false;
            }
            else
            {
                return true;
            }
        }
        public static bool IsValidataInputFLMC(string sFLMC)
        {

            if (0 == sFLMC.Length)
            {
                //MessageBox.Show(null, "请填写完整！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                return false;
            }
            else
            {
                return true;
            }
        }

        public static bool IsValidataInputBSM(string sBSM)
        {

            if (0 == sBSM.Length)
            {
                //MessageBox.Show(null, "请填写完整！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                return false;
            }
            else
            {
                return true;
            }
        }
        public static List<SJZDFL_Helper> GetAllSJZDFL()
        {
            string strsql = "select sFLBM,sFLMC from sjzdfl where isnull(sFFLBM,'')=''";
            SqlDataReader sdr = OIMS_ConfigHelper.GetReader(strsql);
            List<SJZDFL_Helper> list = new List<SJZDFL_Helper>();
            while (sdr.Read())
            {
                list.Add(new SJZDFL_Helper()
                {
                    SFLBM1 = sdr["sFLBM"].ToString(),
                    SFLMC1 = sdr["sFLMC"].ToString()
                });
            }
            sdr.Close();
            return list;
        }

        public static string GetSPKey(string sFLBM)
        {
            string strsql1 = "select sPKey,sFLBM,sFLMC from SJZDFL where sFLBM = '" + sFLBM + "'";
            SqlDataReader sdr1 = OIMS_ConfigHelper.GetReader(strsql1);
            sdr1.Read();

            return sdr1.GetString(0);
        }
        public static string GetSBSM(string sFLBM)
        {
            string strsql1 = "select sBSM,sPKey,sFLBM,sFLMC from SJZDFL where sFLBM = '" + sFLBM + "'";
            SqlDataReader sdr1 = OIMS_ConfigHelper.GetReader(strsql1);
            sdr1.Read();

            return sdr1.GetString(0);
        }

        
    }
}
